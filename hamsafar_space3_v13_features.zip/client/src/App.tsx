import { useEffect, useRef, useState, type ChangeEvent, type FormEvent, type PointerEvent as ReactPointerEvent } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { fileToBase64 } from "@hatch/space-sdk/client";
import { Ban, BarChart3, Bell, BellOff, Calendar, Check, ChevronLeft, CircleDollarSign, Clock, Coins, Copy, Crown, Dice5, Download, Eye, Flag, Forward, Gamepad2, Gift, Heart, History, Home, Image, LockKeyhole, LogOut, Medal, Menu, MessageCircle, Mic, Moon, MoreVertical, Palette, Paperclip, PartyPopper, Pencil, Plus, Radio, Repeat, Reply, Search, Send, Settings, Shield, ShieldAlert, ShieldCheck, Smile, Sparkles, Star, Store, Sun, Trash2, Trophy, User, UserCog, Users, Volume2, Wallet, X, Zap } from "lucide-react";
import { api, type ApiResponse } from "./api";

type State = ApiResponse<typeof api, "getState">;
type GameSession = ApiResponse<typeof api, "startGameSession">;
const gameTypes = ["منچ", "مارپله", "مافیا", "حکم", "پوکر", "۲۱", "کوئیز"] as const;
type GameType = typeof gameTypes[number];
type GameRoomPage = "game-ludo" | "game-snakes" | "game-mafia" | "game-hokm" | "game-poker" | "game-21" | "game-quiz";
type Page = "home" | "discover" | "publicStories" | "chat" | "hangout" | "games" | GameRoomPage | "leaderboard" | "wallet" | "profile" | "admin" | "management" | "userSettings" | "gameStats" | "store" | "twoFactor" | "activity" | "deleteAccount";
const gamePageByType: Record<GameType, GameRoomPage> = { "منچ": "game-ludo", "مارپله": "game-snakes", "مافیا": "game-mafia", "حکم": "game-hokm", "پوکر": "game-poker", "۲۱": "game-21", "کوئیز": "game-quiz" };
const gameTypeByPage: Record<GameRoomPage, GameType> = { "game-ludo": "منچ", "game-snakes": "مارپله", "game-mafia": "مافیا", "game-hokm": "حکم", "game-poker": "پوکر", "game-21": "۲۱", "game-quiz": "کوئیز" };
const gameRoomPages = new Set<GameRoomPage>(Object.values(gamePageByType));
const validPages = new Set<Page>(["home", "discover", "publicStories", "chat", "hangout", "games", ...gameRoomPages, "leaderboard", "wallet", "profile", "admin", "management", "userSettings", "gameStats", "store", "twoFactor", "activity", "deleteAccount"]);
type Sheet = "none" | "profile" | "login" | "settings";
type ThemeMode = "neon" | "glass" | "auto" | "day" | "night";
type ResolvedTheme = "neon" | "glass" | "auto-day" | "auto-night";
type JobResult = { ok?: boolean; message?: string; conversationId?: number | null };
type Runner = { mutate: (job: () => Promise<JobResult>) => void; mutateAsync: (job: () => Promise<JobResult>) => Promise<JobResult> };
type BottomNavItem = { key: string; label: string; icon: React.ReactNode; active: boolean; badge?: number; onClick: () => void };

const fa = new Intl.NumberFormat("fa-IR");
const todayKey = () => new Date().toLocaleDateString("en-CA");
const avatarTone = ["#074b52", "#75143a", "#0d6570", "#a2194e"];
const messageEmojis = ["😀", "😂", "😍", "🥰", "😘", "😊", "😉", "😎", "🤝", "👏", "👍", "❤️", "🔥", "🎉", "🙏", "🌹", "✨", "💯"];
const messageReactionEmojis = ["❤️", "😂", "😍", "👍", "👏", "🔥"] as const;
const liveCheerEmojis = ["👏", "🔥", "❤️", "🎉"] as const;
const interestOptions = ["موسیقی", "ورزش", "سفر", "فیلم و سریال", "کتاب", "بازی", "آشپزی", "هنر", "تکنولوژی", "طبیعت‌گردی", "عکاسی", "مد و استایل", "قهوه و کافه", "حیوانات"] as const;
type Interest = typeof interestOptions[number];
const roleLabel = (role: string) => role === "owner" ? "مدیر و مؤسس" : role === "supervisor" ? "سرپرست" : role === "moderator" ? "ناظر" : role === "superadmin" ? "سوپر ادمین" : role === "admin" ? "ادمین" : "عضو";
type GameAvatarData = State["gameAvatars"][number];

function Avatar({ name, index = 0, large = false }: { name: string; index?: number; large?: boolean }) {
  return <div className={large ? "avatar avatarLarge" : "avatar"} style={{ background: avatarTone[index % avatarTone.length] }}>{name.trim().slice(0, 1)}</div>;
}

function AvatarEmblem({ emblem }: { emblem: GameAvatarData["emblem"] }) {
  if (emblem === "shield") return <Shield />;
  if (emblem === "bolt") return <Zap />;
  if (emblem === "crown") return <Crown />;
  return <Star />;
}

function PlayerAvatar({ avatar, name, index = 0, size = "small", mood = "focused" }: { avatar?: GameAvatarData | null; name: string; index?: number; size?: "small" | "medium" | "large"; mood?: "focused" | "celebrate" | "worried" }) {
  if (!avatar) return <Avatar name={name} index={index} large={size === "large"} />;
  return <div className={`playerAvatar ${size} accent-${avatar.accent} mood-${mood}`} role="img" aria-label={`آواتار مسابقه ${name} · ${mood === "celebrate" ? "خوشحال" : mood === "worried" ? "نگران" : "متمرکز"}`}>
    <div className={`avatarHair hair-${avatar.hair}`} />
    <div className={`avatarFace face-${avatar.face}`}><i /><i /><span /></div>
    <div className={`avatarOutfit outfit-${avatar.outfit}`} />
    <div className="avatarEmblem"><AvatarEmblem emblem={avatar.emblem} /></div>
  </div>;
}

function Empty({ text }: { text: string }) { return <div className="empty"><Sparkles size={18} />{text}</div>; }

export function App() {
  const qc = useQueryClient();
  const [userId, setUserId] = useState<number | null>(() => {
    sessionStorage.removeItem("hamsafar-user");
    const saved = Number(sessionStorage.getItem("hamsafar-auth-user-v11"));
    return Number.isInteger(saved) && saved > 0 ? saved : null;
  });
  const [page, setPage] = useState<Page>(() => {
    const savedPage = sessionStorage.getItem("hamsafar-page") as Page | null;
    return savedPage && validPages.has(savedPage) ? savedPage : "home";
  });
  const [sheet, setSheet] = useState<Sheet>("none");
  const [activeConv, setActiveConv] = useState<number | null>(null);
  const [chatKind, setChatKind] = useState<"private" | "group" | "channel">("private");
  const [toast, setToast] = useState("");
  const [adminUnlocked, setAdminUnlocked] = useState(false);
  const [stake, setStake] = useState(20);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [userDrawerOpen, setUserDrawerOpen] = useState(false);
  const [logoutSheetOpen, setLogoutSheetOpen] = useState(false);
  const pageStageRef = useRef<HTMLElement | null>(null);
  const pullGestureRef = useRef({
    startX: 0,
    startY: 0,
    distance: 0,
    phase: "idle" as "idle" | "armed" | "scroll-only",
    scrollElement: null as HTMLElement | null,
  });
  const pullRefreshRunningRef = useRef(false);
  const [pullDistance, setPullDistance] = useState(0);
  const [pullRefreshing, setPullRefreshing] = useState(false);
  const [themeMode, setThemeMode] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem("hamsafar-theme-v2");
    return saved === "glass" || saved === "auto" || saved === "neon" || saved === "day" || saved === "night" ? saved : "neon";
  });
  const [systemPrefersDark, setSystemPrefersDark] = useState(() => window.matchMedia("(prefers-color-scheme: dark)").matches);

  const activeGame = gameRoomPages.has(page as GameRoomPage) ? gameTypeByPage[page as GameRoomPage] : null;
  const stateQ = useQuery({
    queryKey: ["state", userId],
    queryFn: () => {
      if (userId === null) throw new Error("Authentication required");
      return api.getState({ userId });
    },
    enabled: userId !== null,
    refetchInterval: page === "games" || activeGame ? 2500 : 6000,
  });
  const data = stateQ.data;

  useEffect(() => {
    if ((page !== "admin" && page !== "management") || !data || adminUnlocked) return;
    const panel = page === "management" ? "management" as const : "admin" as const;
    if (data.current.accessRole !== panel) return;
    let active = true;
    void api.adminLogin({ userId: data.current.id, panel }).then((result) => {
      if (!active || !result.ok) return;
      setAdminUnlocked(true);
      void qc.invalidateQueries({ queryKey: ["state"] });
    });
    return () => { active = false; };
  }, [adminUnlocked, data, page, qc]);

  useEffect(() => {
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const syncSystemTheme = (event: MediaQueryListEvent) => setSystemPrefersDark(event.matches);
    setSystemPrefersDark(media.matches);
    media.addEventListener("change", syncSystemTheme);
    return () => media.removeEventListener("change", syncSystemTheme);
  }, []);

  useEffect(() => {
    sessionStorage.setItem("hamsafar-page", page);
  }, [page]);

  useEffect(() => {
    const stage = pageStageRef.current;
    if (!stage || !stateQ.isSuccess) return;

    const selector = "[data-pull-refresh-scroll]";
    const registered = new Map<HTMLElement, () => void>();

    const resetPull = () => {
      pullGestureRef.current.phase = "idle";
      pullGestureRef.current.distance = 0;
      pullGestureRef.current.scrollElement = null;
      if (!pullRefreshRunningRef.current) setPullDistance(0);
    };

    const bindContainer = (container: HTMLElement) => {
      if (registered.has(container)) return;
      container.dataset.pullRefreshBound = "per-page";
      container.dataset.pullRefreshScrollTopSource = "self";

      const onTouchStart = (event: TouchEvent) => {
        const target = event.target instanceof Element ? event.target : null;
        const touch = event.touches[0];
        // A nested registered scroll port owns its own gesture. Ancestors do not
        // observe or arm it, even though the event bubbles through them.
        if (!target || target.closest<HTMLElement>(selector) !== container) return;
        resetPull();
        if (!touch || event.touches.length !== 1 || pullRefreshRunningRef.current) return;

        // Arming invariant: read scrollTop from this exact registered element,
        // once, at touchstart. A non-zero start can never arm later.
        const scrollTopAtTouchStart = container.scrollTop;
        const phase = scrollTopAtTouchStart === 0 ? "armed" : "scroll-only";
        container.dataset.pullRefreshLastStartScrollTop = String(scrollTopAtTouchStart);
        container.dataset.pullRefreshLastStartPhase = phase;
        pullGestureRef.current = {
          startX: touch.clientX,
          startY: touch.clientY,
          distance: 0,
          phase,
          scrollElement: container,
        };
      };

      const onTouchMove = (event: TouchEvent) => {
        const gesture = pullGestureRef.current;
        const touch = event.touches[0];
        if (gesture.scrollElement !== container || gesture.phase === "idle" || !touch || pullRefreshRunningRef.current) return;
        if (event.touches.length !== 1) {
          gesture.phase = "scroll-only";
          gesture.distance = 0;
          setPullDistance(0);
          return;
        }

        const deltaX = touch.clientX - gesture.startX;
        const deltaY = touch.clientY - gesture.startY;
        const vertical = Math.abs(deltaY) > Math.abs(deltaX);

        if (gesture.phase === "armed") {
          if (!vertical || deltaY <= 0) {
            gesture.phase = "scroll-only";
            gesture.distance = 0;
            setPullDistance(0);
            return;
          }
          if (deltaY < 8) return;
          event.preventDefault();
          const distance = Math.min(84, deltaY * 0.46);
          gesture.distance = distance;
          setPullDistance(distance);
          return;
        }

        // Scroll-only is permanent for this gesture. Prevent the WebView's
        // native reload at the upper boundary without converting it to refresh.
        if (vertical && deltaY > 6 && container.scrollTop <= 0) event.preventDefault();
      };

      const onTouchEnd = () => {
        const gesture = pullGestureRef.current;
        if (gesture.scrollElement !== container) return;
        const shouldRefresh = gesture.phase === "armed" && gesture.distance >= 56;
        resetPull();
        if (!shouldRefresh || pullRefreshRunningRef.current) return;
        pullRefreshRunningRef.current = true;
        setPullRefreshing(true);
        setPullDistance(42);
        void qc.refetchQueries({ queryKey: ["state", userId], type: "active" }).finally(() => {
          pullRefreshRunningRef.current = false;
          setPullRefreshing(false);
          setPullDistance(0);
        });
      };

      const onTouchCancel = () => {
        if (pullGestureRef.current.scrollElement === container) resetPull();
      };

      container.addEventListener("touchstart", onTouchStart, { passive: true });
      container.addEventListener("touchmove", onTouchMove, { passive: false });
      container.addEventListener("touchend", onTouchEnd, { passive: true });
      container.addEventListener("touchcancel", onTouchCancel, { passive: true });
      registered.set(container, () => {
        container.removeEventListener("touchstart", onTouchStart);
        container.removeEventListener("touchmove", onTouchMove);
        container.removeEventListener("touchend", onTouchEnd);
        container.removeEventListener("touchcancel", onTouchCancel);
        delete container.dataset.pullRefreshBound;
        delete container.dataset.pullRefreshScrollTopSource;
      });
    };

    const bindTree = (root: ParentNode) => {
      if (root instanceof HTMLElement && root.matches(selector)) bindContainer(root);
      root.querySelectorAll<HTMLElement>(selector).forEach(bindContainer);
    };
    // Drawers are siblings of pageStage, so register from the app shell while
    // keeping every gesture listener attached to its own marked scroll port.
    const scrollRegistryRoot = stage.closest<HTMLElement>(".appShell") ?? stage;
    bindTree(scrollRegistryRoot);
    const observer = new MutationObserver((records) => {
      records.forEach((record) => record.addedNodes.forEach((node) => {
        if (node instanceof HTMLElement) bindTree(node);
      }));
    });
    observer.observe(scrollRegistryRoot, { childList: true, subtree: true });

    return () => {
      observer.disconnect();
      registered.forEach((unbind) => unbind());
      registered.clear();
      resetPull();
    };
  }, [page, qc, stateQ.isSuccess, userId]);

  const refresh = async () => { await qc.invalidateQueries({ queryKey: ["state"] }); };
  const notify = (message?: string) => { setToast(message || "ذخیره شد"); window.setTimeout(() => setToast(""), 2300); };
  const run = useMutation({ mutationFn: async (job: () => Promise<{ ok?: boolean; message?: string }>) => job(), onSuccess: async (r) => { notify(r.message); await refresh(); } });

  const startSession = (id: number) => { setUserId(id); sessionStorage.setItem("hamsafar-auth-user-v11", String(id)); setPage("home"); setActiveConv(null); setAdminUnlocked(false); setDrawerOpen(false); setUserDrawerOpen(false); };
  const logout = () => { sessionStorage.removeItem("hamsafar-auth-user-v11"); setUserId(null); setLogoutSheetOpen(false); setDrawerOpen(false); setUserDrawerOpen(false); setPage("home"); setActiveConv(null); setAdminUnlocked(false); qc.removeQueries({ queryKey: ["state"] }); };
  const gateTheme: ResolvedTheme = themeMode === "auto"
    ? (systemPrefersDark ? "auto-night" : "auto-day")
    : themeMode === "day" ? "auto-day" : themeMode === "night" ? "auto-night" : themeMode;

  if (userId === null) return <main className="appShell authShell" data-theme={gateTheme} dir="rtl"><LoginGate onAuthenticated={startSession} /></main>;
  if (stateQ.error) return <main className="loading" dir="rtl"><p>نشست معتبر نیست یا حساب غیرفعال شده است.</p><button className="primary" onClick={logout}>بازگشت به ورود</button></main>;
  if (stateQ.isPending || !data) return <main className="loading" dir="rtl"><div className="pulseMark"><Users /></div><p>در حال ورود به حساب…</p></main>;

  const active = data.conversations.find((c) => c.id === activeConv) ?? null;
  const incoming = data.requests.filter((r) => r.receiverId === data.current.id && r.status === "pending");
  const visibleChatKind = data.current.accessRole === "admin" && chatKind === "private" ? "group" : chatKind;

  const goChat = (kind: "private" | "group" | "channel", id?: number) => {
    const allowedKind = data.current.accessRole === "admin" && kind === "private" ? "group" : kind;
    setChatKind(allowedKind);
    setActiveConv(allowedKind === kind ? id ?? null : null);
    setPage("chat");
  };
  const goBack = () => {
    if (drawerOpen) { setDrawerOpen(false); return; }
    if (userDrawerOpen) { setUserDrawerOpen(false); return; }
    if (sheet !== "none") { setSheet("none"); return; }
    if (logoutSheetOpen) { setLogoutSheetOpen(false); return; }
    if (page === "chat" && activeConv !== null) { setActiveConv(null); return; }
    if (activeGame) { setPage("games"); return; }
    if (page === "leaderboard") { setPage("games"); return; }
    if (page === "admin" || page === "management") { setPage("profile"); return; }
    if (page === "userSettings" || page === "gameStats" || page === "store" || page === "twoFactor" || page === "activity" || page === "deleteAccount") { setUserDrawerOpen(true); return; }
    setPage("home");
  };
  const changeTheme = (mode: ThemeMode) => {
    setThemeMode(mode);
    localStorage.setItem("hamsafar-theme-v2", mode);
  };
  const resolvedTheme: ResolvedTheme = themeMode === "auto"
    ? (systemPrefersDark ? "auto-night" : "auto-day")
    : themeMode === "day" ? "auto-day" : themeMode === "night" ? "auto-night" : themeMode;
  const openChatSection = (kind: "private" | "group" | "channel") => {
    setChatKind(data.current.accessRole === "admin" && kind === "private" ? "group" : kind);
    setActiveConv(null);
    setPage("chat");
  };
  const profileAreaPages: Page[] = ["profile", "userSettings", "gameStats", "store", "twoFactor", "activity", "deleteAccount"];
  const navItem = (key: string, label: string, icon: React.ReactNode, active: boolean, onClick: () => void, badge?: number): BottomNavItem => ({ key, label, icon, active, onClick, badge });
  let navContext = "خانه";
  let navItems: BottomNavItem[] = [
    navItem("home", "خانه", <Home />, page === "home", () => setPage("home")),
    navItem("discover", "درخواست‌ها", <Heart />, page === "discover", () => setPage("discover"), incoming.length),
    navItem("chat", data.current.accessRole === "admin" ? "گروه‌ها" : "چت", data.current.accessRole === "admin" ? <Users /> : <MessageCircle />, page === "chat", () => openChatSection(data.current.accessRole === "admin" ? "group" : "private")),
    navItem("hangout", "دورهمی", <PartyPopper />, page === "hangout", () => setPage("hangout")),
    navItem("games", "بازی", <Gamepad2 />, page === "games" || page === "leaderboard" || !!activeGame, () => setPage("games")),
    navItem("profile", "پروفایل", <User />, profileAreaPages.includes(page), () => setPage("profile")),
  ];

  if (page === "discover") {
    navContext = "کشف و درخواست‌ها";
    navItems = [
      navItem("home", "خانه", <Home />, false, () => setPage("home")),
      navItem("discover", "درخواست‌ها", <Heart />, true, () => setPage("discover"), incoming.length),
      ...(data.current.accessRole === "admin" ? [] : [navItem("private", "چت خصوصی", <MessageCircle />, false, () => openChatSection("private"))]),
      navItem("publicStories", "استوری عمومی", <Image />, false, () => setPage("publicStories")),
      navItem("profile", "پروفایل", <User />, false, () => setPage("profile")),
    ];
  } else if (page === "publicStories") {
    navContext = "اتاق استوری عمومی";
    navItems = [
      navItem("home", "خانه", <Home />, false, () => setPage("home")),
      navItem("discover", "درخواست‌ها", <Heart />, false, () => setPage("discover"), incoming.length),
      navItem("publicStories", "استوری عمومی", <Image />, true, () => setPage("publicStories")),
      navItem("group", "گروه‌ها", <Users />, false, () => openChatSection("group")),
      navItem("profile", "پروفایل", <User />, false, () => setPage("profile")),
    ];
  } else if (page === "chat") {
    navContext = activeConv === null ? "مرکز چت" : `گفتگوی ${active?.name ?? "باز"}`;
    navItems = [
      navItem("home", "خانه", <Home />, false, () => setPage("home")),
      ...(data.current.accessRole === "admin" ? [] : [navItem("private", "خصوصی", <MessageCircle />, visibleChatKind === "private", () => openChatSection("private"))]),
      navItem("group", "گروه‌ها", <Users />, visibleChatKind === "group", () => openChatSection("group")),
      navItem("channel", "کانال‌ها", <Radio />, visibleChatKind === "channel", () => openChatSection("channel")),
      navItem("profile", "پروفایل", <User />, false, () => setPage("profile")),
    ];
  } else if (page === "hangout") {
    navContext = "دورهمی";
    navItems = [
      navItem("home", "خانه", <Home />, false, () => setPage("home")),
      navItem("hangout", "دورهمی", <PartyPopper />, true, () => setPage("hangout")),
      navItem("group", "گروه‌ها", <Users />, false, () => openChatSection("group")),
      navItem("games", "بازی‌ها", <Gamepad2 />, false, () => setPage("games")),
      navItem("profile", "پروفایل", <User />, false, () => setPage("profile")),
    ];
  } else if (page === "games" || page === "leaderboard" || activeGame) {
    navContext = page === "leaderboard" ? "جدول امتیاز بازی‌ها" : activeGame ? `اتاق ${activeGame}` : "سرگرمی و بازی";
    navItems = [
      navItem("home", "خانه", <Home />, false, () => setPage("home")),
      navItem("games", activeGame ? "اتاق‌ها" : "میز بازی", <Dice5 />, page === "games" || !!activeGame, () => setPage("games")),
      navItem("leaderboard", "امتیازها", <Trophy />, page === "leaderboard", () => setPage("leaderboard")),
      navItem("hangout", "دورهمی", <PartyPopper />, false, () => setPage("hangout")),
      navItem("profile", "پروفایل", <User />, false, () => setPage("profile")),
    ];
  } else if (profileAreaPages.includes(page) || page === "wallet") {
    navContext = page === "profile" ? "پروفایل و حساب" : "ابزارهای حساب";
    navItems = [
      navItem("home", "خانه", <Home />, false, () => setPage("home")),
      navItem("profile", "پروفایل", <User />, page === "profile", () => setPage("profile")),
      navItem("settings", "تنظیمات", <Settings />, page === "userSettings", () => setPage("userSettings")),
      navItem("stats", "آمار بازی", <BarChart3 />, page === "gameStats", () => setPage("gameStats")),
      navItem("store", "فروشگاه", <Store />, page === "store", () => setPage("store")),
      navItem("security", "امنیت", <ShieldCheck />, page === "twoFactor", () => setPage("twoFactor")),
    ];
  } else if (page === "admin" || page === "management") {
    navContext = page === "management" ? "مدیریت کل" : "پنل ادمین";
    navItems = [
      navItem("home", "خانه", <Home />, false, () => setPage("home")),
      navItem("profile", "پروفایل", <User />, false, () => setPage("profile")),
      navItem("panel", page === "management" ? "مدیریت" : "ادمین", <ShieldCheck />, true, () => setPage(page)),
      navItem("group", "گروه‌ها", <Users />, false, () => openChatSection("group")),
      navItem("channel", "کانال‌ها", <Radio />, false, () => openChatSection("channel")),
    ];
  }

  return (
    <div className="appShell" data-theme={resolvedTheme} dir="rtl">
      <header className="topbar">
        {page === "home" ? <button className="drawerTrigger" aria-label="باز کردن منوی کناری" aria-expanded={drawerOpen} onClick={() => setDrawerOpen(true)}><Menu /></button> : <button className="drawerTrigger backTrigger" aria-label="بازگشت" onClick={goBack}><ChevronLeft /></button>}
        <div className="accountBlock"><Avatar name={data.current.name} index={data.current.id} /><div><b>{data.current.name}</b><span>{data.current.accessRole === "management" ? "مدیریت کل" : data.current.accessRole === "admin" ? "ادمین" : "حساب کاربری"}</span></div></div>
        {data.current.accessRole !== "admin" && <div className="coinPill"><Coins size={15} />{fa.format(data.current.coins)}</div>}
        <button className="userDrawerTrigger" aria-label="باز کردن منوی کاربر" aria-expanded={userDrawerOpen} onClick={() => setUserDrawerOpen(true)}><User /></button>
      </header>

      {drawerOpen && <><button className="drawerBackdrop" aria-label="بستن منوی کناری" onClick={() => setDrawerOpen(false)} /><SideDrawer data={data} currentPage={page} themeMode={themeMode} systemPrefersDark={systemPrefersDark} changeTheme={changeTheme} close={() => setDrawerOpen(false)} go={(next) => { setPage(next); setDrawerOpen(false); }} openConversation={(kind, id) => { goChat(kind, id); setDrawerOpen(false); }} onLogout={() => { setDrawerOpen(false); setLogoutSheetOpen(true); }} /></>}
      {userDrawerOpen && <><button className="drawerBackdrop" aria-label="بستن منوی کاربر" onClick={() => setUserDrawerOpen(false)} /><UserDrawer data={data} currentPage={page} close={() => setUserDrawerOpen(false)} go={(next) => { setPage(next); setUserDrawerOpen(false); }} onLogout={() => { setUserDrawerOpen(false); setLogoutSheetOpen(true); }} /></>}

      <section className="pageStage" ref={pageStageRef}>
        <div
          className={`pullRefreshIndicator${pullDistance > 0 ? " visible" : ""}${pullRefreshing ? " refreshing" : ""}`}
          style={{ transform: `translate(-50%, ${Math.max(-46, pullDistance - 46)}px)` }}
          role="status"
          aria-live="polite"
        >
          <Repeat aria-hidden="true" />
          <span>{pullRefreshing ? "در حال تازه‌سازی…" : pullDistance >= 56 ? "رها کنید تا تازه شود" : "برای تازه‌سازی بکشید"}</span>
        </div>
        {page === "home" && <HomePage data={data} incoming={incoming} onGo={setPage} onChat={goChat} run={run} />}
        {page === "discover" && <DiscoverPage data={data} run={run} onChat={goChat} />}
        {page === "publicStories" && <PublicStoriesPage data={data} run={run} />}
        {page === "chat" && <ChatPage data={data} kind={visibleChatKind} active={active} setKind={setChatKind} setActive={setActiveConv} run={run} userId={data.current.id} />}
        {page === "hangout" && <HangoutPage data={data} run={run} openRoom={(id) => goChat("group", id)} />}
        {(page === "games" || activeGame) && <GamesPage data={data} selectedGame={activeGame} stake={stake} setStake={setStake} run={run} onRefresh={refresh} openGame={(game) => setPage(gamePageByType[game])} closeGame={() => setPage("games")} openLeaderboard={() => setPage("leaderboard")} />}
        {page === "leaderboard" && <LeaderboardPage data={data} back={() => setPage("games")} />}
        {page === "wallet" && <WalletPage data={data} run={run} />}
        {page === "profile" && <ProfilePage data={data} run={run} openEdit={() => setSheet("profile")} openAccess={(target) => { setPage(target); setAdminUnlocked(false); }} />}
        {page === "userSettings" && <UserSettingsPage themeMode={themeMode} systemPrefersDark={systemPrefersDark} changeTheme={changeTheme} />}
        {page === "gameStats" && <GameStatsPage data={data} />}
        {page === "store" && <StorePage data={data} run={run} />}
        {page === "twoFactor" && <TwoFactorPage data={data} run={run} />}
        {page === "activity" && <ActivityPage data={data} />}
        {page === "deleteAccount" && <DeleteAccountPage data={data} onDeleted={logout} />}
        {page === "admin" && <ModeratorPage data={data} unlocked={adminUnlocked} run={run} />}
        {page === "management" && <AdminPage data={data} unlocked={adminUnlocked} run={run} openSettings={() => setSheet("settings")} />}
      </section>

      <nav className="bottomNav" aria-label={`پیمایش مرتبط با ${navContext}`}>
        {navItems.map((item) => <NavButton key={item.key} active={item.active} label={item.label} icon={item.icon} badge={item.badge} onClick={item.onClick} />)}
      </nav>

      {sheet !== "none" && <Sheet title={sheet === "profile" ? "ویرایش پروفایل" : sheet === "settings" ? "تنظیمات عمومی" : "ورود مدیر"} close={() => setSheet("none")}>
        {sheet === "profile" && <ProfileForm data={data} done={() => { setSheet("none"); void refresh(); notify("پروفایل ذخیره شد"); }} />}
        {sheet === "login" && <AdminLogin userId={data.current.id} done={(ok, message) => { notify(message); if (ok) { setAdminUnlocked(true); setSheet("none"); } }} />}
        {sheet === "settings" && <SettingsForm data={data} done={() => { setSheet("none"); void refresh(); notify("تنظات ذخیره شد"); }} />}
      </Sheet>}
      {logoutSheetOpen && <Sheet title="خروج از حساب" close={() => setLogoutSheetOpen(false)}>
        <div className="logoutConfirm"><p>از حساب <b>{data.current.name}</b> خارج می‌شوی؟ نشست فعلی بسته می‌شود و برای ورود دوباره باید شماره موبایل و کد تأیید را وارد کنی.</p><div className="logoutActions"><button className="primary" onClick={logout}>خروج از حساب</button><button onClick={() => setLogoutSheetOpen(false)}>انصراف</button></div></div>
      </Sheet>}
      {toast && <div role="status" className="toast">{toast}</div>}
    </div>
  );
}

function NavButton({ active, label, icon, badge, onClick }: { active: boolean; label: string; icon: React.ReactNode; badge?: number; onClick: () => void }) { return <button className={active ? "navButton active" : "navButton"} aria-current={active ? "page" : undefined} onClick={onClick}>{badge ? <i>{fa.format(badge)}</i> : null}{icon}<span>{label}</span></button>; }

function SideDrawer({ data, currentPage, themeMode, systemPrefersDark, changeTheme, close, go, openConversation, onLogout }: { data: State; currentPage: Page; themeMode: ThemeMode; systemPrefersDark: boolean; changeTheme: (theme: ThemeMode) => void; close: () => void; go: (page: Page) => void; openConversation: (kind: "private" | "group" | "channel", id: number) => void; onLogout: () => void }) {
  const managed = data.conversations.filter((c) => c.ownerId === data.current.id && (c.kind === "group" || c.kind === "channel")).slice(0, 3);
  const accountItems: Array<{ page?: Page; action?: "logout"; label: string; icon: React.ReactNode; danger?: boolean }> = [
    { page: "userSettings", label: "تنظیمات", icon: <Settings /> },
    { page: "gameStats", label: "آمار بازی‌ها", icon: <BarChart3 /> },
    { page: "store", label: "فروشگاه", icon: <Store /> },
    { page: "twoFactor", label: "تأیید دومرحله‌ای", icon: <ShieldCheck /> },
    { page: "activity", label: "آخرین فعالیت", icon: <History /> },
    { page: "deleteAccount", label: "حذف حساب کاربری", icon: <Trash2 />, danger: true },
    { action: "logout", label: "خروج از حساب", icon: <LogOut /> },
  ];
  const appLinks: Array<{ page?: Page; label: string; icon: React.ReactNode; kind?: "private" | "group" | "channel" }> = [
    { page: "discover", label: "کشف و درخواست‌ها", icon: <Heart /> },
    { page: "publicStories", label: "اتاق استوری عمومی", icon: <Image /> },
    { page: "hangout", label: "دورهمی روزانه", icon: <PartyPopper /> },
    { page: "games", label: "بازی‌های قابل اجرا", icon: <Gamepad2 /> },
    { page: "leaderboard", label: "جدول امتیاز گروهی", icon: <Trophy /> },
    ...(data.current.accessRole === "admin" ? [] : [{ page: "wallet" as Page, label: "کیف پول", icon: <Wallet /> }, { label: "چت‌های خصوصی", icon: <MessageCircle />, kind: "private" as const }]),
    { label: "گروه‌ها", icon: <Users />, kind: "group" },
    { label: "کانال‌ها", icon: <Radio />, kind: "channel" },
  ];
  return <aside className="sideDrawer compactDrawer" aria-label="منوی کناری">
    <header><div className="drawerIdentity"><Avatar name={data.current.name} index={data.current.id} /><span><b>{data.current.name}</b><small>{data.current.accessRole === "management" ? "مدیریت کل" : data.current.accessRole === "admin" ? "ادمین" : "حساب کاربری"}</small></span></div><button aria-label="بستن منوی کناری" onClick={close}><X /></button></header>
    <div className="drawerBody" data-pull-refresh-scroll data-pull-refresh-page="side-menu">
      <nav className="drawerPrimaryNav" aria-label="منوی حساب">
        <button className={currentPage === "home" ? "current" : ""} onClick={() => go("home")}><Home /><span>خانه</span><ChevronLeft /></button>
        {accountItems.map((item) => <button className={`${currentPage === item.page ? "current" : ""}${item.danger ? " danger" : ""}`} key={item.label} onClick={() => { if (item.action === "logout") { onLogout(); return; } if (item.page) go(item.page); }}>{item.icon}<span>{item.label}</span><ChevronLeft /></button>)}
      </nav>
      <section className="themePicker compactThemePicker" aria-label="انتخاب پوسته">
        <header><Palette /><b>پوسته برنامه</b><small>{themeMode === "auto" ? `خودکار · ${systemPrefersDark ? "شب" : "روز"}` : "انتخاب سریع"}</small></header>
        <div>
          <button className={themeMode === "neon" ? "selected" : ""} aria-label="پوسته شب نئونی" aria-pressed={themeMode === "neon"} onClick={() => changeTheme("neon")}><Zap /><span>نئونی</span></button>
          <button className={themeMode === "glass" ? "selected" : ""} aria-label="پوسته شیشه‌ای" aria-pressed={themeMode === "glass"} onClick={() => changeTheme("glass")}><Sparkles /><span>شیشه‌ای</span></button>
          <button className={themeMode === "day" ? "selected" : ""} aria-label="پوسته روز" aria-pressed={themeMode === "day"} onClick={() => changeTheme("day")}><Sun /><span>روز</span></button>
          <button className={themeMode === "night" ? "selected" : ""} aria-label="پوسته شب" aria-pressed={themeMode === "night"} onClick={() => changeTheme("night")}><Moon /><span>شب</span></button>
          <button className={themeMode === "auto" ? "selected" : ""} aria-label={`پوسته خودکار، اکنون ${systemPrefersDark ? "شب" : "روز"}`} aria-pressed={themeMode === "auto"} onClick={() => changeTheme("auto")}><span className="autoThemeIcons"><Sun /><Moon /></span><span>خودکار</span></button>
        </div>
      </section>
      <details className="drawerMore">
        <summary><Menu /><span>بخش‌های برنامه</span><ChevronLeft /></summary>
        <nav aria-label="بخش‌های برنامه">{appLinks.map((item) => <button className={item.page && currentPage === item.page ? "current" : ""} key={item.label} onClick={() => { if (item.kind) openConversation(item.kind, 0); else if (item.page) go(item.page); }}>{item.icon}<span>{item.label}</span><ChevronLeft /></button>)}{data.current.accessRole === "admin" && <button className={currentPage === "admin" ? "current adminLink" : "adminLink"} onClick={() => go("admin")}><ShieldCheck /><span>پنل ادمین</span><ChevronLeft /></button>}{data.current.accessRole === "management" && <button className={currentPage === "management" ? "current adminLink" : "adminLink"} onClick={() => go("management")}><ShieldCheck /><span>پنل مدیریت</span><ChevronLeft /></button>}</nav>
      </details>
      <section className="managedSpaces"><h3>مدیریت فضاهای من</h3>{managed.map((space) => <button key={space.id} onClick={() => openConversation(space.kind as "group" | "channel", space.id)}>{space.imageUrl ? <img className="conversationImage drawerSpaceImage" src={space.imageUrl} alt={`عکس ${space.name}`} /> : <UserCog />}<span><b>{space.name}</b><small>{space.kind === "group" ? "پنل مدیر گروه" : "پنل مدیر کانال"}</small></span><ChevronLeft /></button>)}{!managed.length && <p>این حساب هنوز مدیر گروه یا کانالی نیست.</p>}</section>
    </div>
    <footer className="drawerFooter">
      <span className="drawerStatus">{data.current.accessRole === "admin" ? <><ShieldCheck />دسترسی مالی ادمین مسدود است</> : <><Coins />موجودی {fa.format(data.current.coins)} سکه</>}</span>
      <span className="versionStamp" aria-label="نسخه برنامه">نسخه ۱۲ — ۱۸ مهر ۱۴۰۵</span>
    </footer>
  </aside>;
}

function UserDrawer({ data, currentPage, close, go, onLogout }: { data: State; currentPage: Page; close: () => void; go: (page: Page) => void; onLogout: () => void }) {
  const items: Array<{ page?: Page; action?: "logout"; label: string; icon: React.ReactNode; danger?: boolean }> = [
    { page: "userSettings", label: "تنظیمات", icon: <Settings /> },
    { page: "gameStats", label: "آمار بازی‌ها", icon: <BarChart3 /> },
    { page: "store", label: "فروشگاه", icon: <Store /> },
    { page: "twoFactor", label: "تأیید دومرحله‌ای", icon: <ShieldCheck /> },
    { page: "activity", label: "آخرین فعالیت", icon: <History /> },
    { page: "deleteAccount", label: "حذف حساب کاربری", icon: <Trash2 />, danger: true },
    { action: "logout", label: "خروج از حساب", icon: <LogOut /> },
  ];
  return <aside className="userDrawer" aria-label="منوی کاربر">
    <header><div className="drawerIdentity"><Avatar name={data.current.name} index={data.current.id} /><span><b>{data.current.name}</b><small>منوی کاربر</small></span></div><button aria-label="بستن منوی کاربر" onClick={close}><X /></button></header>
    <nav data-pull-refresh-scroll data-pull-refresh-page="user-menu">{items.map((item) => <button className={`${currentPage === item.page ? "current" : ""}${item.danger ? " danger" : ""}`} key={item.label} onClick={() => { if (item.action === "logout") { onLogout(); return; } if (item.page) go(item.page); }}>{item.icon}<span>{item.label}</span><ChevronLeft /></button>)}</nav>
    <footer className="drawerFooter">
      <span className="drawerStatus">{data.current.accessRole === "admin" ? <><ShieldCheck />حریم مالی و کدهای محرمانه پنهان است</> : <><Coins />موجودی {fa.format(data.current.coins)} سکه</>}</span>
      <span className="versionStamp" aria-label="نسخه برنامه">نسخه ۱۲ — ۱۸ مهر ۱۴۰۵</span>
    </footer>
  </aside>;
}

type IncomingRequest = State["requests"][number];

function SwipeRequestCard({ request, userId, run, onAccept, compact = false }: { request: IncomingRequest; userId: number; run: Runner; onAccept: (conversationId: number) => void; compact?: boolean }) {
  const cardRef = useRef<HTMLElement>(null);
  const gestureRef = useRef<{ pointerId: number; x: number; y: number; axis: "pending" | "horizontal" | "vertical" } | null>(null);
  const draggedRef = useRef(false);
  const [offset, setOffset] = useState(0);
  const [phase, setPhase] = useState<"idle" | "responding" | "rejected">("idle");

  useEffect(() => { setOffset(0); setPhase("idle"); }, [request.id]);

  const respond = async (accept: boolean) => {
    if (phase !== "idle") return;
    setPhase("responding");
    if (!accept) setOffset(-(cardRef.current?.offsetWidth ?? 320) - 42);
    try {
      const result = await run.mutateAsync(() => api.respondRequest({ requestId: request.id, userId, accept }));
      if (accept && result.conversationId) onAccept(result.conversationId);
      if (!accept) setPhase("rejected");
    } catch {
      setOffset(0);
      setPhase("idle");
    }
  };
  const resetGesture = () => { gestureRef.current = null; window.setTimeout(() => { draggedRef.current = false; }, 0); };
  const endGesture = (event: ReactPointerEvent<HTMLElement>) => {
    const gesture = gestureRef.current;
    if (!gesture || gesture.pointerId !== event.pointerId) return;
    const threshold = Math.min(104, (cardRef.current?.offsetWidth ?? 320) * 0.3);
    resetGesture();
    if (gesture.axis === "horizontal" && offset <= -threshold) void respond(false);
    else setOffset(0);
  };

  if (phase === "rejected") return null;
  return <article
    ref={cardRef}
    className={`swipeRequestCard${compact ? " compact" : ""}${phase === "responding" && offset < 0 ? " leaving" : ""}`}
    role="button"
    tabIndex={0}
    aria-label={`درخواست ${request.senderName}؛ برای پذیرش لمس کنید یا برای رد به چپ بکشید`}
    onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); void respond(true); } }}
    onClick={(event) => { if (draggedRef.current || (event.target as HTMLElement).closest("button")) return; void respond(true); }}
    onDragStart={(event) => { event.preventDefault(); }}
    onPointerDown={(event) => {
      if (phase !== "idle" || (event.target as HTMLElement).closest("button")) return;
      gestureRef.current = { pointerId: event.pointerId, x: event.clientX, y: event.clientY, axis: "pending" };
      draggedRef.current = false;
      event.currentTarget.setPointerCapture(event.pointerId);
    }}
    onPointerMove={(event) => {
      const gesture = gestureRef.current;
      if (!gesture || gesture.pointerId !== event.pointerId || phase !== "idle") return;
      const dx = event.clientX - gesture.x;
      const dy = event.clientY - gesture.y;
      if (gesture.axis === "pending" && Math.max(Math.abs(dx), Math.abs(dy)) > 7) gesture.axis = Math.abs(dx) > Math.abs(dy) * 1.15 ? "horizontal" : "vertical";
      if (gesture.axis !== "horizontal") return;
      draggedRef.current = true;
      setOffset(Math.max(-(cardRef.current?.offsetWidth ?? 320), Math.min(0, dx)));
    }}
    onPointerUp={endGesture}
    onPointerCancel={() => { resetGesture(); setOffset(0); }}
  >
    <span className="rejectUnderlay" aria-hidden="true"><X />رد شد</span>
    <div className="requestCardContent" style={{ transform: `translate3d(${offset}px,0,0)` }}>
      <Avatar name={request.senderName} index={request.senderId} />
      <div className="requestSummary"><b>{request.senderName}</b><span>{request.message || "درخواست آشنایی فرستاده"}</span>{request.imageUrl && <img src={request.imageUrl} alt={`عکس همراه درخواست ${request.senderName}`} draggable={false} />}</div>
      <button aria-label={`پذیرفتن درخواست ${request.senderName} و ورود به چت خصوصی`} disabled={phase !== "idle"} onClick={() => { void respond(true); }}><Check /><span>قبول</span></button>
      <button aria-label={`رد درخواست ${request.senderName}`} className="rejectRequestButton" disabled={phase !== "idle"} onClick={() => { void respond(false); }}><X /></button>
    </div>
  </article>;
}

function RequestTrain({ requests, userId, run, onAccept, compact = false }: { requests: IncomingRequest[]; userId: number; run: Runner; onAccept: (conversationId: number) => void; compact?: boolean }) {
  if (!requests.length) return null;
  return <section className={`requestTrain${compact ? " compact" : ""}`} aria-label="درخواست‌های دریافتی">
    <header><div><Heart /><span><b>درخواست‌های تازه</b><small>کارت را برای رد به چپ بکشید</small></span></div><em>{fa.format(requests.length)}</em></header>
    <div className="requestRail">{requests.map((request) => <SwipeRequestCard key={request.id} request={request} userId={userId} run={run} onAccept={onAccept} compact={compact} />)}</div>
  </section>;
}

function HomePage({ data, incoming, onGo, onChat, run }: { data: State; incoming: IncomingRequest[]; onGo: (p: Page) => void; onChat: (k: "private" | "group" | "channel", id?: number) => void; run: Runner }) {
  const notice = data.notices.find((n) => n.active);
  return <div className="page homePage">
    <div className="homeScrollRegion" data-pull-refresh-scroll data-pull-refresh-page="home">
      <section className="heroPanel"><div><span className="eyebrow">وضعیت زنده سرور</span><h2>{incoming.length ? `${fa.format(incoming.length)} درخواست تازه داری` : "برای یک گفت‌وگوی تازه آماده‌ای؟"}</h2><p>{notice?.body ?? "همه تغییرات بین حساب‌های تست مشترک ذخیره می‌شود."}</p></div><button className="heroAction" onClick={() => onGo("discover")}><Heart /><span>کشف افراد</span><ChevronLeft /></button></section>
      {data.current.accessRole === "user" && <BattleCryPanel data={data} run={run} openDuel={() => onGo("games")} />}
      <RequestTrain requests={incoming} userId={data.current.id} run={run} compact onAccept={(conversationId) => onChat("private", conversationId)} />
      <ScheduledGamesPanel data={data} run={run} openGames={() => onGo("games")} />
      <div className="menuMatrix menuMatrixFive">
        <button className="hangoutTile" onClick={() => onGo("hangout")}><PartyPopper /><b>دورهمی</b><span>برنامه روزانه سر ساعت</span></button>
        {data.current.accessRole === "admin" ? <button onClick={() => onChat("group")}><Users /><b>گروه‌ها</b><span>نظارت فضای عمومی</span></button> : <button onClick={() => onChat("private")}><MessageCircle /><b>گفت‌وگوها</b><span>{data.conversations.filter((c) => c.kind === "private").length} چت خصوصی</span></button>}
        <button onClick={() => onChat("group")}><Users /><b>گروه‌ها</b><span>متن و رسانه</span></button>
        <button onClick={() => onChat("channel")}><Radio /><b>کانال‌ها</b><span>انتشار مدیر</span></button>
        <button onClick={() => onGo("publicStories")}><Image /><b>استوری عمومی</b><span>لایک، کامنت و دنبال‌کردن</span></button>
        <button onClick={() => onGo("games")}><Gamepad2 /><b>اتاق بازی</b><span>بازی، تماشا و شرط</span></button>
      </div>
      <section className="noticeLine"><Bell /><div><b>{notice?.title ?? "اطلاعیه‌ای نیست"}</b><p>{notice?.body ?? "مدیر می‌تواند اطلاعیه تازه منتشر کند."}</p></div></section>
    </div>
  </div>;
}

function BattleCryPanel({ data, run, openDuel }: { data: State; run: Runner; openDuel: () => void }) {
  const [composerOpen, setComposerOpen] = useState(false);
  const [text, setText] = useState("");
  const [speaking, setSpeaking] = useState(false);
  const [voiceMessage, setVoiceMessage] = useState("");
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);
  const cry = data.activeBattleCry;
  const seconds = cry ? Math.max(0, Math.ceil((new Date(cry.expiresAt).getTime() - now) / 1000)) : 0;
  useEffect(() => () => { window.speechSynthesis?.cancel(); }, []);
  const playVoice = () => {
    if (!cry) return;
    if (!("speechSynthesis" in window)) { setVoiceMessage("پخش صوتی روی این دستگاه پشتیبانی نمی‌شود"); return; }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(`${cry.userName} می‌گوید: ${cry.text}`);
    utterance.lang = "fa-IR";
    utterance.rate = 0.92;
    utterance.pitch = 0.86;
    utterance.onstart = () => { setSpeaking(true); setVoiceMessage("گزارش صوتی در حال پخش است"); };
    utterance.onend = () => { setSpeaking(false); setVoiceMessage(""); };
    utterance.onerror = () => { setSpeaking(false); setVoiceMessage("پخش صوتی انجام نشد؛ دوباره امتحان کن"); };
    window.speechSynthesis.speak(utterance);
  };
  const submit = () => {
    const value = text.trim();
    if (value.length < 3) return;
    run.mutate(() => api.createBattleCry({ userId: data.current.id, text: value }));
    setText("");
    setComposerOpen(false);
  };
  return <section className="battleCryPanel" aria-label="کری‌خوانی سه‌دقیقه‌ای">
    <div className="battleCryMain"><span className="battleSignal"><Radio /></span><div><small>{cry ? `${cry.userName} · ${fa.format(Math.ceil(seconds / 60))} دقیقه مانده` : "میدان رقابت خالی است"}</small><b>{cry ? `«${cry.text}»` : "یک کری کوتاه ثبت کن و حریف بطلب"}</b></div></div>
    <div className="battleCryActions"><button onClick={() => setComposerOpen((open) => !open)}><Plus />ثبت کری <small>۱۰ سکه</small></button><button className="voiceCry" disabled={!cry || speaking} onClick={playVoice}><Volume2 />{speaking ? "در حال پخش" : "پخش صوتی"}</button><button className="acceptCry" onClick={openDuel}><Zap />قبول چالش</button></div>
    {voiceMessage && <p className="battleVoiceStatus" role="status">{voiceMessage}</p>}
    {composerOpen && <div className="battleCryComposer"><label><span>متن کری؛ سه دقیقه نمایش داده می‌شود</span><input aria-label="متن کری‌خوانی" maxLength={100} value={text} onChange={(event) => setText(event.target.value)} placeholder="مثلاً: آماده‌ای رکورد منو بزنی؟" /></label><div><button disabled={text.trim().length < 3} onClick={submit}>انتشار</button><button onClick={() => setComposerOpen(false)}>انصراف</button></div></div>}
  </section>;
}

function ScheduledGamesPanel({ data, run, openGames }: { data: State; run: Runner; openGames: () => void }) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);
  const games = data.scheduledGames.filter((game) => game.status !== "finished");
  const timeLabel = (startsAt: string) => new Intl.DateTimeFormat("fa-IR", { weekday: "short", hour: "2-digit", minute: "2-digit" }).format(new Date(startsAt));
  const countdown = (startsAt: string) => {
    const difference = new Date(startsAt).getTime() - now;
    if (difference <= 0) return "زمان شروع رسیده";
    const totalSeconds = Math.floor(difference / 1000);
    const days = Math.floor(totalSeconds / 86_400);
    const hours = Math.floor((totalSeconds % 86_400) / 3_600);
    const minutes = Math.floor((totalSeconds % 3_600) / 60);
    const seconds = totalSeconds % 60;
    if (days > 0) return `${fa.format(days)} روز و ${fa.format(hours)} ساعت`;
    return `${fa.format(hours).padStart(2, "۰")}:${fa.format(minutes).padStart(2, "۰")}:${fa.format(seconds).padStart(2, "۰")}`;
  };
  const respond = (gameId: number, response: "play" | "watch") => run.mutate(() => api.respondToScheduledGame({ userId: data.current.id, scheduledGameId: gameId, response }));

  return <section className="scheduledGamesPanel" aria-label="برنامه بازی‌های گروهی">
    <header><div><span className="scheduleLiveDot" /><div><b>بازی‌های گروهی پیشِ رو</b><small>زمان شروع و حضور همه کاربران</small></div></div><button aria-label="رفتن به اتاق بازی" onClick={openGames}><Gamepad2 /><ChevronLeft /></button></header>
    {!games.length ? <Empty text="هنوز بازی گروهی زمان‌بندی نشده است" /> : <div className="scheduledGamesList">{games.map((game) => <article className={new Date(game.startsAt).getTime() <= now ? "starting" : ""} key={game.id}>
      <div className="scheduledGameMain"><span className="gameTypeMark"><Gamepad2 /></span><div><h3>{game.title}</h3><p>{game.groupName ? `${game.groupName} · ` : ""}میزبان: {game.hostName}</p></div></div>
      <div className="scheduledGameTime"><span><Calendar />{timeLabel(game.startsAt)}</span><strong><Clock />{countdown(game.startsAt)}</strong></div>
      <div className="scheduledGameCounts"><span><Users />{fa.format(game.playerCount)} بازیکن</span><span><Eye />{fa.format(game.watcherCount)} تماشاچی</span></div>
      <div className="scheduledGameActions"><button className={game.myResponse === "play" ? "selected play" : "play"} aria-pressed={game.myResponse === "play"} onClick={() => respond(game.id, "play")}><Gamepad2 />{game.myResponse === "play" ? "بازی می‌کنم ✓" : "بازی می‌کنم"}</button><button className={game.myResponse === "watch" ? "selected watch" : "watch"} aria-pressed={game.myResponse === "watch"} onClick={() => respond(game.id, "watch")}><Eye />{game.myResponse === "watch" ? "تماشا می‌کنم ✓" : "تماشا می‌کنم"}</button></div>
    </article>)}</div>}
  </section>;
}

const dailyHangoutPrograms = [
  { title: "پرسش صمیمی", detail: "یک سؤال کوتاه برای آشنایی بیشتر و شروع گفتگو" },
  { title: "بازی شناخت", detail: "انتخاب‌های سریع و مقایسه جواب‌های اعضا" },
  { title: "صندلی داغ", detail: "پرسش‌های کوتاه، محترمانه و نوبتی" },
  { title: "چالش دونفره", detail: "هم‌تیمی پیدا کن و یک مأموریت کوتاه انجام بده" },
  { title: "قصه و موسیقی", detail: "یک خاطره یا آهنگ محبوبت را با جمع قسمت کن" },
  { title: "شب مافیا", detail: "هماهنگی بازیکن‌ها و ورود گروهی به میز مافیا" },
  { title: "حال خوب", detail: "یک اتفاق خوب هفته را تعریف کن و به بقیه انرژی بده" },
] as const;

function HangoutPage({ data, run, openRoom }: { data: State; run: Runner; openRoom: (id: number) => void }) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 30_000);
    return () => window.clearInterval(timer);
  }, []);
  const hangout = data.conversations.find((conversation) => conversation.kind === "group" && conversation.name === "دورهمی");
  const current = new Date(now);
  const [hourPart = "21", minutePart = "00"] = data.settings.dailyHangoutTime.split(":");
  const hour = Number(hourPart);
  const minute = Number(minutePart);
  const start = new Date(current);
  start.setHours(Number.isFinite(hour) ? hour : 21, Number.isFinite(minute) ? minute : 0, 0, 0);
  const end = new Date(start.getTime() + 90 * 60_000);
  const phase = current < start ? "upcoming" : current < end ? "live" : "finished";
  const remainingMinutes = Math.max(0, Math.ceil((start.getTime() - current.getTime()) / 60_000));
  const program = dailyHangoutPrograms[current.getDay()] ?? dailyHangoutPrograms[0];
  const attendees = hangout?.memberCount ?? 0;
  const rsvp = () => {
    if (!hangout) return;
    run.mutate(() => api.sendMessage({ conversationId: hangout.id, senderId: data.current.id, type: "text", content: `برای برنامه «${program.title}» هستم 👋` }));
  };
  return <div className="page hangoutPage">
    <div className="pageTitle hangoutTitle"><div><h1>دورهمی</h1><p>هر روز یک بهانه تازه برای باهم‌بودن</p></div><button aria-label="گزینه‌های اتاق دورهمی" disabled={!hangout} onClick={() => hangout && openRoom(hangout.id)}><MoreVertical /></button></div>
    <section className={`hangoutHero ${phase}`}>
      <div className="hangoutStatus"><span className="livePulse" /><b>{phase === "live" ? "برنامه در حال اجراست" : phase === "upcoming" ? `شروع در ${fa.format(remainingMinutes)} دقیقه` : "برنامه امشب تمام شد"}</b></div>
      <PartyPopper />
      <div><span>برنامه امروز</span><h2>{program.title}</h2><p>{program.detail}</p></div>
      <div className="hangoutMeta"><span><Clock />ساعت {data.settings.dailyHangoutTime}</span><span><Users />{fa.format(attendees)} عضو</span><span><Calendar />۹۰ دقیقه</span></div>
      <div className="hangoutActions"><button className="primary" disabled={!hangout} onClick={() => hangout && openRoom(hangout.id)}><MessageCircle />ورود به اتاق دورهمی</button><button disabled={!hangout} onClick={rsvp}><Check />من میام</button></div>
    </section>
    <section className="weeklyProgram"><header><div><b>برنامه هفتگی</b><small>هر برنامه رأس ساعت تعیین‌شده خودکار فعال می‌شود</small></div><Clock /></header><div data-pull-refresh-scroll data-pull-refresh-page="hangout-schedule">{dailyHangoutPrograms.map((item, index) => <article className={index === current.getDay() ? "today" : ""} key={item.title}><span>{fa.format(index + 1)}</span><div><b>{item.title}</b><small>{item.detail}</small></div>{index === current.getDay() && <em>امروز</em>}</article>)}</div></section>
  </div>;
}

function DailyStoryStrip({ data, run }: { data: State; run: Runner }) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [caption, setCaption] = useState("");
  const [openId, setOpenId] = useState<number | null>(null);
  const stories = [...data.dailyStories].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  const active = stories.find((story) => story.id === openId) ?? null;
  const activeIndex = active ? stories.findIndex((story) => story.id === active.id) : -1;
  const mine = stories.find((story) => story.userId === data.current.id);

  useEffect(() => {
    if (!active) return;
    void api.viewDailyStory({ storyId: active.id, viewerId: data.current.id });
    const timer = window.setTimeout(() => setOpenId(stories[activeIndex + 1]?.id ?? null), 7000);
    return () => window.clearTimeout(timer);
  }, [active?.id, activeIndex, data.current.id]);

  const upload = () => {
    if (!file) return;
    const allowed = ["image/jpeg", "image/png", "image/webp", "video/mp4", "video/webm"] as const;
    if (!allowed.includes(file.type as typeof allowed[number])) { run.mutate(() => Promise.resolve({ ok: true, message: "فرمت فایل پشتیبانی نمی‌شود" })); return; }
    run.mutate(async () => {
      const encoded = await fileToBase64(file);
      const result = await api.createDailyStory({ userId: data.current.id, caption: caption.trim(), mediaType: file.type.startsWith("video/") ? "video" : "image", dataBase64: encoded.dataBase64, mimeType: file.type as typeof allowed[number], filename: file.name });
      setFile(null); setCaption(""); if (fileRef.current) fileRef.current.value = "";
      return result;
    });
  };

  return <>
    <section className="dailyStoryStrip" aria-label="استوری‌های روزانه امروز">
      <header><div><b>استوری روزانه</b><small>هر نفر، روزی یک استوری · نمایش در درخواست‌ها</small></div><span>{fa.format(stories.length)} امروز</span></header>
      <div className="dailyStoryRail">
        <button className={`storyOwner addStory ${mine ? "disabledStory" : ""}`} disabled={Boolean(mine)} onClick={() => fileRef.current?.click()} aria-label={mine ? "استوری روزانه امروز منتشر شده است" : "افزودن استوری روزانه امروز"}><span className="storyRing"><Avatar name={data.current.name} index={data.current.id} /><i>{mine ? <Check /> : <Plus />}</i></span><small>{mine ? "امروز منتشر شد" : "استوری امروز"}</small></button>
        {stories.map((story) => <button key={story.id} className={`storyOwner ${story.viewedByMe ? "viewed" : ""}`} onClick={() => setOpenId(story.id)} aria-label={`دیدن استوری روزانه ${story.userName}`}><span className="storyRing"><Avatar name={story.userName} index={story.userId} /></span><small>{story.isMine ? "استوری من" : story.userName}</small></button>)}
      </div>
      <input ref={fileRef} className="hiddenInput" type="file" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm" onChange={(event) => setFile(event.target.files?.[0] ?? null)} />
      {file && <div className="storyComposer"><div><Image /><span><b>{file.name}</b><small>فقط یک استوری برای امروز</small></span></div><textarea aria-label="متن اختیاری استوری روزانه" value={caption} maxLength={160} onChange={(event) => setCaption(event.target.value)} placeholder="متن کوتاه اختیاری…" /><div><button onClick={() => { setFile(null); setCaption(""); }}>انصراف</button><button className="primary" onClick={upload}>انتشار روزانه</button></div></div>}
    </section>
    {active && <div className="storyViewer" role="dialog" aria-modal="true" aria-label={`استوری روزانه ${active.userName}`}>
      <div className="storyProgress" aria-hidden="true">{stories.map((story, index) => <i key={story.id} className={index < activeIndex ? "done" : index === activeIndex ? "playing" : ""} />)}</div>
      <header><Avatar name={active.userName} index={active.userId} /><div><b>{active.userName}</b><small>استوری روزانه · {fa.format(active.viewCount)} بازدید</small></div>{active.isMine && <button aria-label="حذف استوری روزانه" onClick={() => { setOpenId(null); run.mutate(() => api.deleteDailyStory({ storyId: active.id, userId: data.current.id })); }}><Trash2 /></button>}<button aria-label="بستن استوری روزانه" onClick={() => setOpenId(null)}><X /></button></header>
      <div className="storyMedia">{active.mediaType === "image" ? <img src={active.mediaUrl} alt={`استوری روزانه ${active.userName}`} /> : <video src={active.mediaUrl} autoPlay muted playsInline controls aria-label={`استوری ویدیویی روزانه ${active.userName}`} />}</div>
      {active.caption && <p>{active.caption}</p>}
      <button className="storyPrev" aria-label="استوری روزانه قبلی" disabled={activeIndex <= 0} onClick={() => setOpenId(stories[activeIndex - 1]?.id ?? null)} />
      <button className="storyNext" aria-label="استوری روزانه بعدی" onClick={() => setOpenId(stories[activeIndex + 1]?.id ?? null)} />
    </div>}
  </>;
}

function PublicStoriesPage({ data, run }: { data: State; run: Runner }) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [caption, setCaption] = useState("");
  const [commenting, setCommenting] = useState<number | null>(null);
  const [comment, setComment] = useState("");
  const upload = () => {
    if (!file) { fileRef.current?.click(); return; }
    const allowed = ["image/jpeg", "image/png", "image/webp", "video/mp4", "video/webm"] as const;
    if (!allowed.includes(file.type as typeof allowed[number])) { run.mutate(() => Promise.resolve({ ok: true, message: "فرمت فایل پشتیبانی نمی‌شود" })); return; }
    run.mutate(async () => {
      const encoded = await fileToBase64(file);
      const result = await api.createPublicStory({ userId: data.current.id, caption: caption.trim(), mediaType: file.type.startsWith("video/") ? "video" : "image", dataBase64: encoded.dataBase64, mimeType: file.type as typeof allowed[number], filename: file.name });
      setFile(null); setCaption(""); if (fileRef.current) fileRef.current.value = "";
      return result;
    });
  };
  const sendComment = (storyId: number) => {
    const text = comment.trim();
    if (!text) return;
    run.mutate(async () => { const result = await api.commentPublicStory({ storyId, userId: data.current.id, text }); setComment(""); setCommenting(null); return result; });
  };
  return <div className="page publicStoriesPage">
    <PageTitle title="استوری عمومی" subtitle="اتاق حمایت اعضا با لایک، کامنت و فالو" />
    <section className="publicStoryComposer">
      <input ref={fileRef} className="hiddenInput" type="file" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm" onChange={(event) => setFile(event.target.files?.[0] ?? null)} />
      {!file ? <button className="publicUploadButton" onClick={() => fileRef.current?.click()}><Plus /><span><b>استوری عمومی تازه</b><small>عکس یا ویدیو · انقضا پس از ۲۴ ساعت</small></span></button> : <div className="storyComposer"><div><Image /><span><b>{file.name}</b><small>حداکثر ۸ مگابایت</small></span></div><textarea aria-label="متن اختیاری استوری عمومی" value={caption} maxLength={160} onChange={(event) => setCaption(event.target.value)} placeholder="متن کوتاه اختیاری…" /><div><button onClick={() => { setFile(null); setCaption(""); }}>انصراف</button><button className="primary" onClick={upload}>انتشار در اتاق</button></div></div>}
    </section>
    <section className="publicStoryFeed" data-pull-refresh-scroll data-pull-refresh-page="public-story-room story-comments" aria-label="استوری‌های عمومی فعال">
      {!data.publicStories.length ? <Empty text="هنوز استوری عمومی فعالی نیست؛ اولین استوری را منتشر کنید" /> : data.publicStories.map((story) => {
        const comments = data.publicStoryComments.filter((item) => item.storyId === story.id);
        return <article className="publicStoryCard" key={story.id}>
          <header><Avatar name={story.userName} index={story.userId} /><div><b>{story.userName}</b><small>{new Date(story.createdAt).toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" })} · تا ۲۴ ساعت</small></div>{story.isMine ? <button className="storyDelete" aria-label={`حذف استوری عمومی ${story.userName}`} onClick={() => run.mutate(() => api.deletePublicStory({ storyId: story.id, userId: data.current.id }))}><Trash2 /></button> : <button className={story.followedByMe ? "followAuthor active" : "followAuthor"} aria-pressed={story.followedByMe} onClick={() => run.mutate(() => api.toggleFollowUser({ followerId: data.current.id, followedId: story.userId }))}>{story.followedByMe ? "دنبال می‌کنید" : "دنبال کردن"}</button>}</header>
          <div className="publicStoryMedia">{story.mediaType === "image" ? <img src={story.mediaUrl} alt={`استوری عمومی ${story.userName}`} /> : <video src={story.mediaUrl} controls playsInline aria-label={`استوری عمومی ویدیویی ${story.userName}`} />}</div>
          {story.caption && <p>{story.caption}</p>}
          <div className="publicStoryActions"><button className={story.likedByMe ? "liked" : ""} aria-pressed={story.likedByMe} onClick={() => run.mutate(() => api.togglePublicStoryLike({ storyId: story.id, userId: data.current.id }))}><Heart />{fa.format(story.likeCount)} لایک</button><button onClick={() => setCommenting(commenting === story.id ? null : story.id)}><MessageCircle />{fa.format(story.commentCount)} کامنت</button></div>
          {comments.length > 0 && <div className="publicComments">{comments.slice(-3).map((item) => <p key={item.id}><b>{item.userName}</b> {item.text}</p>)}</div>}
          {commenting === story.id && <form className="publicCommentForm" onSubmit={(event) => { event.preventDefault(); sendComment(story.id); }}><input aria-label={`کامنت برای استوری ${story.userName}`} value={comment} maxLength={240} onChange={(event) => setComment(event.target.value)} placeholder="کامنت حمایتی بنویس…" /><button aria-label="ارسال کامنت" type="submit" disabled={!comment.trim()}><Send /></button></form>}
        </article>;
      })}
    </section>
  </div>;
}

function DiscoverPage({ data, run, onChat }: { data: State; run: Runner; onChat: (k: "private" | "group" | "channel", id?: number) => void }) {
  const [index, setIndex] = useState(0);
  const [requestMessage, setRequestMessage] = useState("");
  const [requestPhoto, setRequestPhoto] = useState<File | null>(null);
  const [sendingRequest, setSendingRequest] = useState(false);
  const requestPhotoRef = useRef<HTMLInputElement>(null);
  const pool = data.users.filter((u) => u.id !== data.current.id && !u.isAdmin && u.isActive);
  const candidate = pool[index % Math.max(pool.length, 1)];
  const incoming = data.requests.filter((r) => r.receiverId === data.current.id && r.status === "pending");
  const chooseRequestPhoto = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file || !["image/jpeg", "image/png", "image/webp"].includes(file.type) || file.size > 5 * 1024 * 1024) return;
    setRequestPhoto(file);
  };
  const submitRequest = async () => {
    if (!candidate || sendingRequest) return;
    setSendingRequest(true);
    try {
      if (requestPhoto) {
        const encoded = await fileToBase64(requestPhoto);
        await run.mutateAsync(() => api.sendRequest({
          senderId: data.current.id,
          receiverId: candidate.id,
          message: requestMessage,
          image: { dataBase64: encoded.dataBase64, mimeType: requestPhoto.type as "image/jpeg" | "image/png" | "image/webp", filename: requestPhoto.name },
        }));
      } else {
        await run.mutateAsync(() => api.sendRequest({ senderId: data.current.id, receiverId: candidate.id, message: requestMessage }));
      }
      setRequestMessage("");
      setRequestPhoto(null);
      setIndex((value) => value + 1);
    } finally {
      setSendingRequest(false);
    }
  };
  if (!candidate) return <div className="page"><PageTitle title="کشف و آشنایی" subtitle="کاربر دیگری فعال نیست" /><DailyStoryStrip data={data} run={run} /><Empty text="حساب تست دیگری برای کشف وجود ندارد" /></div>;
  return <div className="page discoverPage"><PageTitle title="کشف و آشنایی" subtitle={`${fa.format(incoming.length)} درخواست دریافتی`} />
    <DailyStoryStrip data={data} run={run} />
    <RequestTrain requests={incoming} userId={data.current.id} run={run} onAccept={(conversationId) => onChat("private", conversationId)} />
    <section className="profileDeck"><div className="profileArt"><Avatar large name={candidate.name} index={candidate.id} /><span className="testBadge">حساب تست</span></div><div className="profileCopy"><h3>{candidate.name}، {fa.format(candidate.age)}</h3><p>{candidate.city} · {candidate.gender}</p><blockquote>{candidate.bio}</blockquote></div><div className="swipeActions"><button className="skip" onClick={() => { setIndex((value) => value + 1); setRequestMessage(""); setRequestPhoto(null); }} aria-label="رد کردن"><X /></button></div></section>
    <section className="requestComposer" aria-label={`ارسال درخواست به ${candidate.name}`}>
      <input aria-label="پیام همراه درخواست" value={requestMessage} maxLength={240} onChange={(event) => setRequestMessage(event.target.value)} placeholder="یک پیام کوتاه بنویس…" />
      <input ref={requestPhotoRef} className="hiddenInput" type="file" accept="image/jpeg,image/png,image/webp" onChange={chooseRequestPhoto} />
      <button type="button" className={requestPhoto ? "photoButton selected" : "photoButton"} aria-label={requestPhoto ? "تغییر عکس درخواست" : "افزودن یک عکس به درخواست"} onClick={() => requestPhotoRef.current?.click()}><Image /><span>{requestPhoto ? "یک عکس انتخاب شد" : "یک عکس"}</span></button>
      {requestPhoto && <button type="button" className="removeRequestPhoto" aria-label="حذف عکس انتخاب‌شده" onClick={() => setRequestPhoto(null)}><X /></button>}
      <button type="button" className="sendRequestButton" disabled={sendingRequest} onClick={() => { void submitRequest(); }}><Send /><span>{sendingRequest ? "در حال ارسال…" : "ارسال درخواست"}</span></button>
    </section>
    {data.current.accessRole !== "admin" && <button className="subtleAction" onClick={() => onChat("private")}>مشاهده مچ‌ها و گفت‌وگوها <ChevronLeft /></button>}
  </div>;
}

function ChatPage({ data, kind, active, setKind, setActive, run, userId }: { data: State; kind: "private" | "group" | "channel"; active: State["conversations"][number] | null; setKind: (k: "private" | "group" | "channel") => void; setActive: (id: number | null) => void; run: Runner; userId: number }) {
  type ReplyTarget = { id: number; author: string; preview: string; kind: "message" | "post" };
  type ChatMessage = State["messages"][number];
  const [text, setText] = useState("");
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState("");
  const [newRules, setNewRules] = useState("");
  const [newAdmins, setNewAdmins] = useState<number[]>([]);
  const [newSuperAdmins, setNewSuperAdmins] = useState<number[]>([]);
  const [newChannelActivity, setNewChannelActivity] = useState("");
  const [newSupervisors, setNewSupervisors] = useState<number[]>([]);
  const [newModerators, setNewModerators] = useState<number[]>([]);
  const [menuOpen, setMenuOpen] = useState(false);
  const [spacePanel, setSpacePanel] = useState<"none" | "replies" | "search" | "help" | "leave">("none");
  const [spaceQuery, setSpaceQuery] = useState("");
  const [donationAmount, setDonationAmount] = useState(20);
  const [inviteeId, setInviteeId] = useState<number | null>(null);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [mediaOpen, setMediaOpen] = useState(false);
  const [manageOpen, setManageOpen] = useState(false);
  const [editName, setEditName] = useState("");
  const [rules, setRules] = useState("");
  const [channelActivity, setChannelActivity] = useState("");
  const [conversationEditOpen, setConversationEditOpen] = useState(false);
  const [conversationImage, setConversationImage] = useState<File | null>(null);
  const [savingConversation, setSavingConversation] = useState(false);
  const [commentingPost, setCommentingPost] = useState<number | null>(null);
  const [commentText, setCommentText] = useState("");
  const [replyTarget, setReplyTarget] = useState<ReplyTarget | null>(null);
  const [messageActions, setMessageActions] = useState<ChatMessage | null>(null);
  const [reactionTargetId, setReactionTargetId] = useState<number | null>(null);
  const [actionView, setActionView] = useState<"menu" | "forward">("menu");
  const [editingMessage, setEditingMessage] = useState<ChatMessage | null>(null);
  const [emojiOpen, setEmojiOpen] = useState(false);
  const [secretTimer, setSecretTimer] = useState<1 | 5 | 30 | 60>(5);
  const [privacyShield, setPrivacyShield] = useState(false);
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const mediaRef = useRef<HTMLInputElement>(null);
  const conversationImageRef = useRef<HTMLInputElement>(null);
  const composerInputRef = useRef<HTMLInputElement>(null);
  const longPressTimerRef = useRef<number | null>(null);
  const longPressOriginRef = useRef<{ x: number; y: number } | null>(null);
  const longPressTriggeredRef = useRef(false);
  const chatRecorderRef = useRef<MediaRecorder | null>(null);
  const chatVoiceStreamRef = useRef<MediaStream | null>(null);
  const chatVoiceChunksRef = useRef<Blob[]>([]);
  const list = data.conversations.filter((c) => c.kind === kind);
  const allMessages = active ? data.messages.filter((m) => m.conversationId === active.id) : [];
  const messages = allMessages;
  const scopedPosts = active?.kind === "channel" ? data.posts.filter((p) => p.conversationId === active.id) : [];
  const posts = scopedPosts;
  const conversationMedia = active ? allMessages.filter((m) => m.type === "image" || m.type === "video" || m.type === "voice") : [];
  const activeMembers = active ? data.members.filter((m) => m.conversationId === active.id) : [];
  const canManage = !!active && (active.ownerId === userId || (active.kind === "group" && active.role === "supervisor") || (active.kind === "channel" && active.role === "superadmin"));
  const canPublish = !!active && (active.kind !== "channel" || active.role === "owner" || active.role === "superadmin" || active.role === "admin");
  const canUploadMedia = !!active && (active.kind !== "channel" || active.role === "owner");
  const forwardTargets = data.conversations.filter((conversation) => conversation.id !== active?.id && !!conversation.role && conversation.kind !== "game" && (conversation.kind !== "channel" || conversation.role === "owner" || conversation.role === "superadmin" || conversation.role === "admin"));
  const myMessageIds = new Set(allMessages.filter((message) => message.senderId === userId).map((message) => message.id));
  const myPostIds = new Set(scopedPosts.filter((post) => post.authorId === userId).map((post) => post.id));
  const replyItems = active?.kind === "channel"
    ? scopedPosts.filter((post) => post.replyToId !== null && myPostIds.has(post.replyToId)).map((post) => ({ id: post.id, kind: "post" as const, author: post.authorName, text: post.text || (post.mediaType === "image" ? "تصویر" : post.mediaType === "video" ? "فیلم" : "ویس"), createdAt: post.createdAt }))
    : allMessages.filter((message) => message.replyToId !== null && myMessageIds.has(message.replyToId)).map((message) => ({ id: message.id, kind: "message" as const, author: message.senderName, text: message.type === "text" || message.type === "system" ? message.content : message.type === "image" ? "تصویر" : message.type === "video" ? "فیلم" : "ویس", createdAt: message.createdAt }));
  const normalizedQuery = spaceQuery.trim().toLocaleLowerCase("fa");
  const searchItems = !normalizedQuery ? [] : active?.kind === "channel"
    ? scopedPosts.filter((post) => `${post.text} ${post.mediaType ?? ""}`.toLocaleLowerCase("fa").includes(normalizedQuery)).map((post) => ({ id: post.id, kind: "post" as const, author: post.authorName, text: post.text || (post.mediaType === "image" ? "تصویر" : post.mediaType === "video" ? "فیلم" : "ویس") }))
    : allMessages.filter((message) => `${message.content} ${message.type}`.toLocaleLowerCase("fa").includes(normalizedQuery)).map((message) => ({ id: message.id, kind: "message" as const, author: message.senderName, text: message.type === "text" || message.type === "system" ? message.content : message.type === "image" ? "تصویر" : message.type === "video" ? "فیلم" : "ویس" }));
  const activeMemberIds = new Set(activeMembers.map((member) => member.userId));
  const inviteCandidates = data.users.filter((user) => user.id !== userId && !activeMemberIds.has(user.id));
  const jumpToItem = (kindValue: "message" | "post", id: number) => { setSpacePanel("none"); setMenuOpen(false); window.setTimeout(() => document.getElementById(`${kindValue}-${id}`)?.scrollIntoView({ behavior: "smooth", block: "center" }), 50); };

  useEffect(() => {
    const value = active?.secretTimerMinutes;
    setSecretTimer(value === 1 || value === 30 || value === 60 ? value : 5);
    setReplyTarget(null);
    setEditingMessage(null);
    setMessageActions(null);
    setReactionTargetId(null);
    setActionView("menu");
    setEmojiOpen(false);
    setMenuOpen(false);
    setSpacePanel("none");
    setSpaceQuery("");
    setInviteeId(null);
    setConversationEditOpen(false);
    setConversationImage(null);
  }, [active?.id, active?.secretTimerMinutes]);

  useEffect(() => {
    if (!active?.confidential) { setPrivacyShield(false); return; }
    const shield = () => setPrivacyShield(true);
    const reveal = () => setPrivacyShield(false);
    const visibility = () => setPrivacyShield(document.visibilityState !== "visible");
    window.addEventListener("blur", shield);
    window.addEventListener("focus", reveal);
    document.addEventListener("visibilitychange", visibility);
    return () => { window.removeEventListener("blur", shield); window.removeEventListener("focus", reveal); document.removeEventListener("visibilitychange", visibility); };
  }, [active?.confidential]);

  useEffect(() => () => {
    if (longPressTimerRef.current !== null) window.clearTimeout(longPressTimerRef.current);
    const recorder = chatRecorderRef.current;
    if (recorder?.state === "recording") {
      recorder.onstop = null;
      recorder.stop();
    }
    chatVoiceStreamRef.current?.getTracks().forEach((track) => track.stop());
  }, []);

  const clearPanels = () => { setMediaOpen(false); setHistoryOpen(false); setManageOpen(false); setConversationEditOpen(false); setConversationImage(null); setEmojiOpen(false); };
  const cancelLongPress = () => {
    if (longPressTimerRef.current !== null) window.clearTimeout(longPressTimerRef.current);
    longPressTimerRef.current = null;
    longPressOriginRef.current = null;
  };
  const openMessageActions = (message: ChatMessage) => {
    cancelLongPress();
    setReactionTargetId(null);
    setMessageActions(message);
    setActionView("menu");
    setEmojiOpen(false);
  };
  const beginLongPress = (event: ReactPointerEvent<HTMLElement>, message: ChatMessage) => {
    if ((event.target as HTMLElement).closest("button, a, input, audio, video")) return;
    cancelLongPress();
    longPressTriggeredRef.current = false;
    longPressOriginRef.current = { x: event.clientX, y: event.clientY };
    longPressTimerRef.current = window.setTimeout(() => {
      longPressTriggeredRef.current = true;
      if (navigator.vibrate) navigator.vibrate(18);
      openMessageActions(message);
    }, 520);
  };
  const tapMessage = (message: ChatMessage) => {
    if (longPressTriggeredRef.current) { longPressTriggeredRef.current = false; return; }
    if (message.type === "system") return;
    setReactionTargetId((current) => current === message.id ? null : message.id);
    setMessageActions(null);
  };
  const reactToMessage = (message: ChatMessage, emoji: typeof messageReactionEmojis[number]) => {
    run.mutate(() => api.reactMessage({ messageId: message.id, userId, emoji }));
    setReactionTargetId(null);
  };
  const moveLongPress = (event: ReactPointerEvent<HTMLElement>) => {
    const origin = longPressOriginRef.current;
    if (origin && Math.hypot(event.clientX - origin.x, event.clientY - origin.y) > 10) cancelLongPress();
  };
  const chooseReply = (message: ChatMessage) => {
    setReplyTarget({ id: message.id, author: message.senderName, preview: previewForMessage(message), kind: "message" });
    setEditingMessage(null);
    setMessageActions(null);
    window.setTimeout(() => composerInputRef.current?.focus(), 0);
  };
  const beginEdit = (message: ChatMessage) => {
    setText(message.content);
    setEditingMessage(message);
    setReplyTarget(null);
    setMessageActions(null);
    window.setTimeout(() => composerInputRef.current?.focus(), 0);
  };
  const send = () => {
    if (!active || !text.trim() || active.blocked) return;
    const value = text.trim();
    if (editingMessage) {
      run.mutate(() => api.editMessage({ messageId: editingMessage.id, userId, content: value }));
      setText(""); setEditingMessage(null); setEmojiOpen(false);
      return;
    }
    const replyToId = replyTarget?.kind === (active.kind === "channel" ? "post" : "message") ? replyTarget.id : undefined;
    setText(""); setReplyTarget(null); setEmojiOpen(false);
    if (active.kind === "channel") run.mutate(() => api.publishChannel({ userId, conversationId: active.id, text: value, replyToId }));
    else run.mutate(() => api.sendMessage({ conversationId: active.id, senderId: userId, type: "text", content: value, replyToId }));
  };
  const sendFile = async (file: File) => {
    if (!active) return;
    const rawType = file.type.startsWith("image/") ? "image" : file.type.startsWith("video/") ? "video" : "voice";
    const allowed = ["audio/webm", "audio/mp4", "audio/mpeg", "image/jpeg", "image/png", "image/webp", "video/mp4", "video/webm"] as const;
    if (!allowed.includes(file.type as typeof allowed[number])) { run.mutate(() => Promise.resolve({ ok: true, message: "فرمت فایل پشتیبانی نمی‌شود" })); return; }
    const encoded = await fileToBase64(file);
    const replyToId = replyTarget?.kind === (active.kind === "channel" ? "post" : "message") ? replyTarget.id : undefined;
    setReplyTarget(null);
    setEditingMessage(null);
    setEmojiOpen(false);
    run.mutate(() => api.sendMedia({ conversationId: active.id, senderId: userId, type: rawType, dataBase64: encoded.dataBase64, mimeType: file.type as typeof allowed[number], filename: file.name, replyToId }));
  };
  const upload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) await sendFile(file);
    e.target.value = "";
  };
  const stopVoiceRecording = () => {
    const recorder = chatRecorderRef.current;
    if (recorder?.state === "recording") recorder.stop();
  };
  const toggleVoiceRecording = async () => {
    if (isRecordingVoice) { stopVoiceRecording(); return; }
    if (!active || !navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
      run.mutate(() => Promise.resolve({ ok: true, message: "ضبط صدا در این مرورگر در دسترس نیست" }));
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      chatVoiceStreamRef.current = stream;
      const mimeType = MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "audio/mp4";
      const recorder = new MediaRecorder(stream, { mimeType });
      chatVoiceChunksRef.current = [];
      recorder.ondataavailable = (event) => { if (event.data.size) chatVoiceChunksRef.current.push(event.data); };
      recorder.onstop = () => {
        const blob = new Blob(chatVoiceChunksRef.current, { type: mimeType });
        chatVoiceChunksRef.current = [];
        stream.getTracks().forEach((track) => track.stop());
        chatVoiceStreamRef.current = null;
        chatRecorderRef.current = null;
        setIsRecordingVoice(false);
        if (blob.size > 0) void sendFile(new File([blob], `voice-${Date.now()}.${mimeType === "audio/webm" ? "webm" : "m4a"}`, { type: mimeType }));
      };
      chatRecorderRef.current = recorder;
      recorder.start();
      setIsRecordingVoice(true);
    } catch {
      chatVoiceStreamRef.current?.getTracks().forEach((track) => track.stop());
      chatVoiceStreamRef.current = null;
      chatRecorderRef.current = null;
      setIsRecordingVoice(false);
      run.mutate(() => Promise.resolve({ ok: true, message: "برای ضبط ویس، دسترسی میکروفون را فعال کنید" }));
    }
  };
  const manage = (action: "toggle_mute" | "toggle_block" | "clear_messages" | "clear_media") => { if (!active) return; run.mutate(() => api.manageConversation({ userId, conversationId: active.id, action })); setMenuOpen(false); };
  const setSecret = (enabled: boolean) => { if (!active) return; run.mutate(() => api.setSecretChat({ userId, conversationId: active.id, enabled, timerMinutes: secretTimer })); setMenuOpen(false); };
  const previewForMessage = (m: State["messages"][number]) => m.type === "text" || m.type === "system" ? m.content : m.type === "image" ? "تصویر" : m.type === "video" ? "فیلم" : "ویس";
  const previewForPost = (p: State["posts"][number]) => p.text || (p.mediaType === "image" ? "تصویر" : p.mediaType === "video" ? "فیلم" : "ویس");
  const downloadImage = (url: string, label: string) => <a className="downloadOnImage" href={url} download aria-label={label}><Download /></a>;
  const forensicWatermark = () => <span className="forensicWatermark" aria-hidden="true"><i>{`بیننده ${data.current.name} · ${userId}`}</i><i>{`V${userId} · C${active?.id ?? 0}`}</i><i>{`بیننده ${data.current.name} · ${userId}`}</i><i>{`V${userId} · C${active?.id ?? 0}`}</i></span>;
  const chooseConversationImage = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type) || file.size > 5 * 1024 * 1024) {
      run.mutate(() => Promise.resolve({ ok: true, message: "عکس باید JPG، PNG یا WebP و کمتر از ۵ مگابایت باشد" }));
      return;
    }
    setConversationImage(file);
  };
  const saveConversationEdit = async () => {
    if (!active || savingConversation || editName.trim().length < 2) return;
    setSavingConversation(true);
    try {
      if (conversationImage) {
        const encoded = await fileToBase64(conversationImage);
        await run.mutateAsync(() => api.updateConversation({ userId, conversationId: active.id, name: editName.trim(), rules: rules.trim(), channelActivity: active.kind === "channel" ? channelActivity.trim() : undefined, image: { dataBase64: encoded.dataBase64, mimeType: conversationImage.type as "image/jpeg" | "image/png" | "image/webp", filename: conversationImage.name } }));
      } else {
        await run.mutateAsync(() => api.updateConversation({ userId, conversationId: active.id, name: editName.trim(), rules: rules.trim(), channelActivity: active.kind === "channel" ? channelActivity.trim() : undefined }));
      }
      setConversationEditOpen(false);
      setConversationImage(null);
    } finally {
      setSavingConversation(false);
    }
  };

  return <div className="page chatPage"><PageTitle title="مرکز چت" subtitle="گفتگوی خصوصی پس از پذیرش درخواست؛ اتاق محرمانه در صورت نیاز" />
    <div className="segmented">{data.current.accessRole !== "admin" && <button className={kind === "private" ? "on" : ""} onClick={() => { setKind("private"); setActive(null); clearPanels(); }}>خصوصی</button>}<button className={kind === "group" ? "on" : ""} onClick={() => { setKind("group"); setActive(null); clearPanels(); }}>گروه‌ها</button><button className={kind === "channel" ? "on" : ""} onClick={() => { setKind("channel"); setActive(null); clearPanels(); }}>کانال‌ها</button></div>
    {!active ? <><div className="compactList" data-pull-refresh-scroll data-pull-refresh-page={`chat-list-${kind}`}>{list.slice(0, 4).map((c) => <button className="listRow" key={c.id} onClick={() => { if (c.role || c.kind === "private") setActive(c.id); else run.mutate(() => api.joinConversation({ userId, conversationId: c.id })); }}>{c.imageUrl ? <img className="conversationImage" src={c.imageUrl} alt={`عکس ${c.kind === "group" ? "گروه" : c.kind === "channel" ? "کانال" : "گفتگو"} ${c.name}`} /> : <Avatar name={c.name} index={c.id} />}<div><b>{c.name}</b><span>{c.memberCount} عضو · مدیر {c.ownerName}{c.kind === "private" ? (c.confidential ? " · اتاق محرمانه" : " · چت خصوصی") : ""}</span></div><em>{c.role || c.kind === "private" ? "باز کردن" : "عضویت"}</em></button>)}{!list.length && <Empty text="هنوز موردی نیست" />}</div>
      {kind !== "private" && (creating ? <section className="createPanel roleCreatePanel" data-pull-refresh-scroll>
        <header><b>{kind === "group" ? "ساخت گروه" : "مدیریت ویژه کانال"}</b><button aria-label="بستن پنل ساخت" onClick={() => setCreating(false)}><X /></button></header>
        <div className="createFields">
          <label>نام<input aria-label="نام فضای جدید" value={newName} onChange={(e) => setNewName(e.target.value)} placeholder={kind === "group" ? "نام گروه" : "نام کانال"} /></label>
          {kind === "channel" ? <label>حوزه فعالیت<input aria-label="حوزه فعالیت کانال" value={newChannelActivity} onChange={(e) => setNewChannelActivity(e.target.value)} placeholder="مثلاً سرگرمی و مسابقه" /></label> : <label>قوانین<input aria-label="قوانین فضای جدید" value={newRules} onChange={(e) => setNewRules(e.target.value)} placeholder="قوانین کوتاه" /></label>}
        </div>
        {kind === "group" ? <div className="roleBuilder"><div className="roleSummary"><span className="roleBadge owner">مدیر و مؤسس · ۱ نفر</span><b>{data.current.name}</b></div><fieldset className="roleSelect supervisor"><legend>سرپرست · حداکثر ۲ نفر <small>نظارت بر گروه و مدیران</small></legend>{data.users.filter((u) => u.id !== userId && !newModerators.includes(u.id)).map((u) => <label key={u.id}><input type="checkbox" aria-label={`انتخاب ${u.name} به‌عنوان سرپرست`} checked={newSupervisors.includes(u.id)} disabled={!newSupervisors.includes(u.id) && newSupervisors.length >= 2} onChange={() => setNewSupervisors((ids) => ids.includes(u.id) ? ids.filter((id) => id !== u.id) : [...ids, u.id].slice(0, 2))} />{u.name}</label>)}</fieldset><fieldset className="roleSelect moderator"><legend>ناظر · حداکثر ۵ نفر <small>رسیدگی به اعضا</small></legend>{data.users.filter((u) => u.id !== userId && !newSupervisors.includes(u.id)).map((u) => <label key={u.id}><input type="checkbox" aria-label={`انتخاب ${u.name} به‌عنوان ناظر`} checked={newModerators.includes(u.id)} disabled={!newModerators.includes(u.id) && newModerators.length >= 5} onChange={() => setNewModerators((ids) => ids.includes(u.id) ? ids.filter((id) => id !== u.id) : [...ids, u.id].slice(0, 5))} />{u.name}</label>)}</fieldset></div> : <div className="roleBuilder channelRoleBuilder">
          <div className="roleSummary"><span className="roleBadge owner">مدیر کانال · ۱ نفر</span><b>{data.current.name}</b></div>
          <fieldset className="roleSelect superadmin"><legend>سوپر ادمین · حداکثر ۲ نفر</legend>{data.users.filter((u) => u.id !== userId && !newAdmins.includes(u.id)).map((u) => <label key={u.id}><input type="checkbox" aria-label={`انتخاب ${u.name} به‌عنوان سوپر ادمین`} checked={newSuperAdmins.includes(u.id)} disabled={!newSuperAdmins.includes(u.id) && newSuperAdmins.length >= 2} onChange={() => setNewSuperAdmins((ids) => ids.includes(u.id) ? ids.filter((id) => id !== u.id) : [...ids, u.id].slice(0, 2))} />{u.name}</label>)}</fieldset>
          <fieldset className="roleSelect admin"><legend>ادمین · حداکثر ۶ نفر</legend>{data.users.filter((u) => u.id !== userId && !newSuperAdmins.includes(u.id)).map((u) => <label key={u.id}><input type="checkbox" aria-label={`انتخاب ${u.name} به‌عنوان ادمین`} checked={newAdmins.includes(u.id)} disabled={!newAdmins.includes(u.id) && newAdmins.length >= 6} onChange={() => setNewAdmins((ids) => ids.includes(u.id) ? ids.filter((id) => id !== u.id) : [...ids, u.id].slice(0, 6))} />{u.name}</label>)}</fieldset>
          <p className="channelPermissionNote"><Image /><span><b>انتشار عکس و فیلم فقط برای مدیر کانال</b><small>اعضا با کامنت، استیکر، لایک و دنبال‌کردن مشارکت می‌کنند.</small></span></p>
        </div>}
        <button className="primary" disabled={newName.trim().length < 2 || (kind === "channel" && newChannelActivity.trim().length < 2)} onClick={() => { if (newName.trim().length < 2 || (kind === "channel" && newChannelActivity.trim().length < 2)) return; run.mutate(() => api.createConversation({ ownerId: userId, kind, name: newName.trim(), rules: newRules.trim(), channelActivity: newChannelActivity.trim(), adminIds: newAdmins, superAdminIds: newSuperAdmins, supervisorIds: newSupervisors, moderatorIds: newModerators })); setNewName(""); setNewRules(""); setNewChannelActivity(""); setNewAdmins([]); setNewSuperAdmins([]); setNewSupervisors([]); setNewModerators([]); setCreating(false); }}><Check />ساخت با ساختار مدیریتی</button>
      </section> : <div className="createStrip"><button onClick={() => setCreating(true)}><Plus />ساخت {kind === "group" ? "گروه" : "کانال"} و تعیین مدیر</button></div>)}</> : <div className={active.confidential ? "conversationPane secretConversation" : "conversationPane"}>
      <div className="conversationHead"><button aria-label="بازگشت به فهرست" onClick={() => setActive(null)}><ChevronLeft /></button>{active.imageUrl && active.kind !== "private" ? <img className="conversationImage conversationHeadImage" src={active.imageUrl} alt={`عکس ${active.kind === "group" ? "گروه" : "کانال"} ${active.name}`} /> : null}<div className="conversationIdentity"><b>{active.name}</b><span>{active.kind === "private" ? (active.confidential ? `اتاق محرمانه · حذف خودکار ${fa.format(active.secretTimerMinutes)} دقیقه‌ای` : "گفتگوی خصوصی پس از پذیرش درخواست") : `${active.memberCount} عضو${active.kind === "channel" && active.channelActivity ? ` · ${active.channelActivity}` : active.description ? ` · ${active.description}` : ""}`}</span></div>{active.confidential && <LockKeyhole className="privacyMark" aria-label="اتاق چت محرمانه" />}{canManage && active.kind !== "private" && <button className="manageShortcut" aria-label="باز کردن پنل مدیریت" onClick={() => { setEditName(active.name); setRules(active.description); setChannelActivity(active.channelActivity); setConversationEditOpen(false); setConversationImage(null); setManageOpen(true); setMediaOpen(false); setHistoryOpen(false); }}><UserCog /><span>پنل مدیر</span></button>}<button aria-label={active.kind === "private" ? "گزینه‌های گفتگوی خصوصی" : `گزینه‌های ${active.kind === "channel" ? "کانال" : active.name === "دورهمی" ? "اتاق دورهمی" : "گروه"}`} onClick={() => setMenuOpen((v) => !v)}><MoreVertical /></button>
        {menuOpen && active.kind === "private" && <div className="chatMenu"><button onClick={() => { setMediaOpen(true); setHistoryOpen(false); setMenuOpen(false); }}><Image />مدیای گفتگو</button><button onClick={() => setSecret(!active.confidential)}><LockKeyhole />{active.confidential ? "خروج از اتاق محرمانه" : "شروع اتاق چت محرمانه"}</button><button onClick={() => { setHistoryOpen(true); setMediaOpen(false); setMenuOpen(false); }}><History />تاریخچه</button><button onClick={() => manage("clear_messages")}><Trash2 />پاک‌کردن پیام‌های من</button><button onClick={() => manage("toggle_mute")}><BellOff />{active.muted ? "روشن کردن اعلان" : "اعلان بی‌صدا"}</button><button onClick={() => manage("toggle_block")}><Ban />{active.blocked ? "رفع بلاک" : "بلاک"}</button><button onClick={() => { run.mutate(() => api.reportUser({ reporterId: userId, subject: `گزارش گفتگوی ${active.name}` })); setMenuOpen(false); }}><Flag />گزارش</button></div>}
        {menuOpen && active.kind !== "private" && <div className="chatMenu spaceMenu"><button onClick={() => { setSpacePanel("replies"); setMenuOpen(false); }}><Reply />پاسخ‌های کامنت من</button><button onClick={() => { setSpacePanel("search"); setMenuOpen(false); }}><Search />جستجو</button><button onClick={() => { setSpacePanel("help"); setMenuOpen(false); }}><Coins />کمک به گروه</button><button className="danger" onClick={() => { setSpacePanel("leave"); setMenuOpen(false); }}><LogOut />{active.kind === "channel" ? "ترک کانال" : active.name === "دورهمی" ? "ترک اتاق" : "ترک گروه"}</button></div>}
      </div>
      {spacePanel !== "none" && active.kind !== "private" && <section className="spaceUtilityPanel" aria-label={spacePanel === "replies" ? "پاسخ‌های کامنت من" : spacePanel === "search" ? "جستجو" : spacePanel === "help" ? "کمک به گروه" : "تأیید خروج"}><header><b>{spacePanel === "replies" ? "پاسخ‌های کامنت من" : spacePanel === "search" ? `جستجو در ${active.name}` : spacePanel === "help" ? "کمک به گروه" : active.kind === "channel" ? "ترک کانال؟" : active.name === "دورهمی" ? "ترک اتاق؟" : "ترک گروه؟"}</b><button aria-label="بستن پنل" onClick={() => setSpacePanel("none")}><X /></button></header>{spacePanel === "replies" ? <div className="spaceResultList" data-pull-refresh-scroll>{[...replyItems].sort((a,b) => a.createdAt < b.createdAt ? 1 : -1).map((item) => <button key={`${item.kind}-${item.id}`} onClick={() => jumpToItem(item.kind, item.id)}><Reply /><span><b>{item.author}</b><small>{item.text}</small></span><ChevronLeft /></button>)}{!replyItems.length && <Empty text="هنوز پاسخی به پیام‌های شما ثبت نشده" />}</div> : spacePanel === "search" ? <><label className="spaceSearch"><Search /><input autoFocus aria-label={`جستجو در ${active.name}`} value={spaceQuery} onChange={(event) => setSpaceQuery(event.target.value)} placeholder="کلیدواژه در پیام، پست یا کپشن…" /></label><div className="spaceResultList" data-pull-refresh-scroll>{searchItems.map((item) => <button key={`${item.kind}-${item.id}`} onClick={() => jumpToItem(item.kind, item.id)}><Search /><span><b>{item.author}</b><small>{item.text}</small></span><ChevronLeft /></button>)}{normalizedQuery && !searchItems.length && <Empty text="نتیجه‌ای در همین فضا پیدا نشد" />}</div></> : spacePanel === "help" ? <div className="spaceHelpGrid" data-pull-refresh-scroll><div><label>دعوت از فهرست کاربران<select aria-label="انتخاب کاربر برای دعوت" value={inviteeId ?? ""} onChange={(event) => setInviteeId(Number(event.target.value) || null)}><option value="">انتخاب دوست</option>{inviteCandidates.map((user) => <option key={user.id} value={user.id}>{user.name}</option>)}</select></label><button disabled={!inviteeId} onClick={() => inviteeId && run.mutate(() => api.inviteToConversation({ userId, conversationId: active.id, inviteeId }))}><Users />دعوت به این فضا</button></div><div><span className="fundBalance"><Coins />صندوق: <b>{fa.format(active.groupFund)} سکه</b></span><label>مبلغ کمک<input aria-label="مبلغ اهدای سکه" type="number" min={1} max={1000} value={donationAmount} onChange={(event) => setDonationAmount(Math.max(1, Math.min(1000, Number(event.target.value) || 1)))} /></label><button onClick={() => run.mutate(() => api.donateConversationFund({ userId, conversationId: active.id, amount: donationAmount }))}><Coins />اهدای {fa.format(donationAmount)} سکه</button></div></div> : <div className="leaveConfirm"><p>عضویت شما از این فضا حذف می‌شود. برای ورود دوباره باید دوباره عضو شوید.</p><div><button onClick={() => setSpacePanel("none")}>انصراف</button><button className="danger" onClick={() => { run.mutate(() => api.leaveConversation({ userId, conversationId: active.id })); setSpacePanel("none"); setActive(null); }}>{active.kind === "channel" ? "ترک کانال" : active.name === "دورهمی" ? "ترک اتاق" : "ترک گروه"}</button></div></div>}</section>}
      {active.kind === "channel" && <section className="channelStatus" aria-label="ساختار مدیریت کانال"><div><Radio /><span><b>{active.channelActivity || "حوزه فعالیت ثبت نشده"}</b><small>مدیر: {active.ownerName}</small></span></div><div className="channelRoleCounts"><span><Crown />{fa.format(activeMembers.filter((member) => member.role === "superadmin").length)} / ۲ سوپر ادمین</span><span><ShieldCheck />{fa.format(activeMembers.filter((member) => member.role === "admin").length)} / ۶ ادمین</span></div></section>}
      {active.confidential && <div className="secretBar"><LockKeyhole /><span><b>حذف خودکار روشن است</b><small>پیام‌های تازه پس از زمان انتخابی حذف می‌شوند. محافظ محو هنگام خروج از صفحه فعال است؛ جلوگیری کامل از اسکرین‌شات به پشتیبانی دستگاه وابسته است.</small></span><label>تایمر<select aria-label="زمان حذف خودکار پیام محرمانه" value={secretTimer} onChange={(e) => setSecretTimer(Number(e.target.value) as 1 | 5 | 30 | 60)}><option value={1}>۱ دقیقه</option><option value={5}>۵ دقیقه</option><option value={30}>۳۰ دقیقه</option><option value={60}>۱ ساعت</option></select></label><button onClick={() => setSecret(true)}>اعمال</button></div>}
      {privacyShield && <div className="privacyOverlay"><ShieldAlert /><b>نمای محرمانه پوشانده شد</b></div>}
      {mediaOpen ? <section className="mediaPanel" data-pull-refresh-scroll data-pull-refresh-page="media"><header><b>مدیای گفتگو</b><button aria-label="بستن مدیا" onClick={() => setMediaOpen(false)}><X /></button></header><div>{conversationMedia.map((m) => <article key={m.id}>{m.type === "image" ? <div className="mediaFrame"><img src={m.content} alt="تصویر گفتگو" />{forensicWatermark()}{downloadImage(m.content, "دانلود تصویر گفتگو")}</div> : m.type === "video" ? <div className="mediaFrame"><video src={m.content} controls aria-label="فیلم گفتگو" />{forensicWatermark()}</div> : <audio src={m.content} controls aria-label="ویس گفتگو" />}<small>{m.senderName}</small><button className="inlineReply" onClick={() => { setReplyTarget({ id: m.id, author: m.senderName, preview: previewForMessage(m), kind: "message" }); setMediaOpen(false); }}><Reply />پاسخ</button></article>)}{!conversationMedia.length && <Empty text="هنوز مدیایی در این گفتگو نیست" />}</div></section> : historyOpen ? <section className="historyPanel" data-pull-refresh-scroll data-pull-refresh-page="history"><header><b>تاریخچه گفتگو</b><button aria-label="بستن تاریخچه" onClick={() => setHistoryOpen(false)}><X /></button></header>{allMessages.map((m) => <button className="historyMessage" key={m.id} onClick={() => { setReplyTarget({ id: m.id, author: m.senderName, preview: previewForMessage(m), kind: "message" }); setHistoryOpen(false); }}><b>{m.senderName}:</b> {previewForMessage(m)} <Reply /></button>)}</section> : manageOpen && canManage ? <section className={active.kind === "channel" ? "managePanel channelManagePanel" : "managePanel"} data-pull-refresh-scroll data-pull-refresh-page={active.kind === "channel" ? "channel-management" : "group-management"}>
        <header><b>{active.kind === "group" ? "مدیریت گروه" : "مدیریت ویژه کانال"}</b><div className="manageHeaderActions"><button className="editConversationButton" aria-label={`ویرایش ${active.kind === "group" ? "گروه" : "کانال"}`} onClick={() => { setEditName(active.name); setRules(active.description); setChannelActivity(active.channelActivity); setConversationImage(null); setConversationEditOpen((value) => !value); }}><Pencil /><span>ویرایش</span></button><button aria-label="بستن پنل مدیریت" onClick={() => { setManageOpen(false); setConversationEditOpen(false); setConversationImage(null); }}><X /></button></div></header>
        {conversationEditOpen ? <section className="conversationEditForm" aria-label={`فرم ویرایش ${active.kind === "group" ? "گروه" : "کانال"}`}>
          <div className="conversationEditPhoto">{active.imageUrl ? <img src={active.imageUrl} alt={`عکس فعلی ${active.name}`} /> : <span><Image /><small>بدون عکس</small></span>}<div><button type="button" onClick={() => conversationImageRef.current?.click()}><Image />{conversationImage ? "تغییر انتخاب" : active.imageUrl ? "تغییر عکس" : "آپلود عکس"}</button>{conversationImage && <small>{conversationImage.name}</small>}</div></div>
          <label>نام<input aria-label={`نام ${active.kind === "group" ? "گروه" : "کانال"}`} value={editName} maxLength={50} onChange={(e) => setEditName(e.target.value)} /></label>
          <label>{active.kind === "group" ? "توضیح / قوانین" : "توضیح کانال"}<textarea aria-label={active.kind === "group" ? "توضیح و قوانین گروه" : "توضیح کانال"} value={rules} maxLength={300} onChange={(e) => setRules(e.target.value)} placeholder={active.kind === "group" ? "توضیح یا قوانین گروه…" : "درباره این کانال…"} /></label>
          {active.kind === "channel" && <label>حوزه فعالیت<input aria-label="حوزه فعالیت کانال" value={channelActivity} maxLength={80} onChange={(e) => setChannelActivity(e.target.value)} placeholder="حوزه فعالیت کانال" /></label>}
          <input ref={conversationImageRef} className="hiddenInput" type="file" accept="image/jpeg,image/png,image/webp" onChange={chooseConversationImage} />
          <div className="conversationEditActions"><button type="button" onClick={() => { setConversationEditOpen(false); setConversationImage(null); }}>انصراف</button><button type="button" className="primary" disabled={savingConversation || editName.trim().length < 2 || (active.kind === "channel" && channelActivity.trim().length < 2)} onClick={() => { void saveConversationEdit(); }}><Check />{savingConversation ? "در حال ذخیره…" : "ذخیره و نمایش فوری"}</button></div>
        </section> : <div className="conversationManageSummary">{active.imageUrl ? <img className="conversationImage" src={active.imageUrl} alt={`عکس ${active.name}`} /> : <span className="spaceImagePlaceholder"><Image /></span>}<div><b>{active.name}</b><small>{active.description || (active.kind === "group" ? "توضیح یا قانونی ثبت نشده" : "توضیحی ثبت نشده")}</small></div></div>}
        {active.kind === "channel" && <div className="channelPolicyGrid"><span><Image /><b>عکس و فیلم</b><small>فقط مدیر کانال</small></span><span><MessageCircle /><b>تعامل اعضا</b><small>کامنت و استیکر</small></span><span><Heart /><b>واکنش</b><small>لایک و دنبال‌کردن</small></span></div>}
        <div className="roleLegend"><span className="roleBadge owner">{active.kind === "channel" ? "مدیر کانال · ۱" : "مدیر و مؤسس"}</span>{active.kind === "group" ? <><span className="roleBadge supervisor">سرپرست · تا ۲</span><span className="roleBadge moderator">ناظر · تا ۵</span></> : <><span className="roleBadge superadmin">سوپر ادمین · تا ۲</span><span className="roleBadge admin">ادمین · تا ۶</span></>}</div>
        <div className="memberRoles">{activeMembers.map((m) => <div className={`memberRoleRow role-${m.role}`} key={m.userId}><span>{m.name}<small className={`roleText ${m.role}`}>{roleLabel(m.role)}</small></span>{m.role === "owner" ? <b>{active.kind === "channel" ? "مدیر کانال" : "مالک گروه"}</b> : <select aria-label={`نقش ${m.name}`} value={m.role} onChange={(e) => run.mutate(() => api.setMemberRole({ userId, conversationId: active.id, memberId: m.userId, role: e.target.value as "supervisor" | "moderator" | "superadmin" | "admin" | "member" }))}>{active.kind === "group" ? <><option value="member">عضو</option><option value="moderator">ناظر</option><option value="supervisor">سرپرست</option></> : <><option value="member">عضو</option><option value="admin">ادمین</option><option value="superadmin">سوپر ادمین</option></>}</select>}</div>)}</div>
      </section> : <div className="messageList" data-pull-refresh-scroll data-pull-refresh-page={active.kind === "private" ? "private-chat" : active.kind === "channel" ? "channel channel-comments" : active.name === "دورهمی" ? "hangout-room" : "group"}>{active.kind === "channel" ? <>{posts.map((p) => <article className="post" id={`post-${p.id}`} key={p.id}><b>{p.authorName}</b>{p.replyPreview && <blockquote className="replyQuote"><b>{p.replyAuthorName}</b><span>{p.replyPreview}</span></blockquote>}{p.text && <p>{p.text}</p>}{p.mediaUrl && (p.mediaType === "image" ? <div className="mediaFrame postImage"><img src={p.mediaUrl} alt="عکس منتشرشده در کانال" />{forensicWatermark()}{downloadImage(p.mediaUrl, "دانلود تصویر کانال")}</div> : p.mediaType === "video" ? <div className="mediaFrame"><video src={p.mediaUrl} controls aria-label="فیلم منتشرشده در کانال" />{forensicWatermark()}</div> : <audio src={p.mediaUrl} controls aria-label="ویس منتشرشده در کانال" />)}{data.comments.find((c) => c.postId === p.id) && <small>{data.comments.find((c) => c.postId === p.id)?.userName}: {data.comments.find((c) => c.postId === p.id)?.text}</small>}<footer><button aria-label={`پسندیدن پست ${p.id}`} onClick={() => run.mutate(() => api.reactChannel({ userId, postId: p.id, mode: "like" }))}><Heart />پسند {p.likes}</button><button aria-label={`پاسخ به پست ${p.id}`} onClick={() => { if (canPublish) setReplyTarget({ id: p.id, author: p.authorName, preview: previewForPost(p), kind: "post" }); else setCommentingPost(commentingPost === p.id ? null : p.id); }}><Reply />پاسخ</button><button aria-label={`نظر روی پست ${p.id}`} onClick={() => setCommentingPost(commentingPost === p.id ? null : p.id)}><MessageCircle />نظر {p.comments}</button></footer>{commentingPost === p.id && <div className="channelInteraction"><div className="stickerRow" aria-label="استیکرهای کانال">{["👏", "❤️", "🔥", "🎉"].map((sticker) => <button key={sticker} aria-label={`ارسال استیکر ${sticker}`} onClick={() => { run.mutate(() => api.addChannelComment({ userId, postId: p.id, text: sticker })); setCommentingPost(null); }}>{sticker}</button>)}</div><div className="commentComposer"><input aria-label="متن پاسخ یا نظر" value={commentText} onChange={(e) => setCommentText(e.target.value)} placeholder={`نظر برای ${p.authorName}…`} /><button aria-label="ارسال نظر" onClick={() => { if (!commentText.trim()) return; run.mutate(() => api.addChannelComment({ userId, postId: p.id, text: commentText.trim() })); setCommentText(""); setCommentingPost(null); }}><Send /></button></div></div>}</article>)}</> : messages.map((m) => <article className={`${m.senderId === userId ? "bubble mine" : "bubble"}${reactionTargetId === m.id ? " reactionOpen" : ""}`} id={`message-${m.id}`} key={m.id} onPointerDown={(event) => beginLongPress(event, m)} onPointerMove={moveLongPress} onPointerUp={cancelLongPress} onPointerCancel={cancelLongPress} onClick={(event) => { if ((event.target as HTMLElement).closest("button, a, audio, video")) return; tapMessage(m); }} onContextMenu={(event) => { event.preventDefault(); openMessageActions(m); }}>{reactionTargetId === m.id && <div className="messageReactionPicker" role="toolbar" aria-label={`واکنش به پیام ${m.senderName}`}>{messageReactionEmojis.map((emoji) => <button key={emoji} aria-label={`واکنش ${emoji}`} onClick={() => reactToMessage(m, emoji)}>{emoji}</button>)}<button className="moreReactionActions" aria-label={`گزینه‌های بیشتر پیام ${m.senderName}`} onClick={() => openMessageActions(m)}><MoreVertical /></button></div>}<small className="messageMeta"><span>{m.senderName}</span>{active.kind === "group" && <em className={`roleText ${m.senderRole}`}>{roleLabel(m.senderRole)}</em>}{m.editedAt ? " · ویرایش‌شده" : ""}{m.expiresAt ? ` · حذف ${new Date(m.expiresAt).toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" })}` : ""}</small>{m.replyPreview && <blockquote className="replyQuote"><b>{m.replySenderName}</b><span>{m.replyPreview}</span></blockquote>}{m.type === "text" || m.type === "system" ? <p>{m.content}</p> : m.type === "image" ? <div className="mediaFrame"><img src={m.content} alt="تصویر ارسال‌شده در گفتگو" draggable={false} />{forensicWatermark()}{downloadImage(m.content, "دانلود تصویر پیام")}</div> : m.type === "video" ? <div className="mediaFrame"><video src={m.content} controls aria-label="فیلم ارسال‌شده" />{forensicWatermark()}</div> : <audio src={m.content} controls aria-label="ویس ارسال‌شده" />}{m.reactions.length > 0 && <div className="messageReactions" aria-label="واکنش‌های پیام">{m.reactions.map((reaction) => <button className={reaction.reactedByMe ? "mine" : ""} key={reaction.emoji} aria-label={`${reaction.emoji}، ${reaction.count} واکنش`} onClick={() => reactToMessage(m, reaction.emoji)}><span>{reaction.emoji}</span><b>{fa.format(reaction.count)}</b></button>)}</div>}<button className="inlineReply" aria-label={`پاسخ به پیام ${m.senderName}`} onClick={() => chooseReply(m)}><Reply />پاسخ</button></article>)}</div>}
      {messageActions && <><button className="messageActionBackdrop" aria-label="بستن گزینه‌های پیام" onClick={() => setMessageActions(null)} /><section className="messageActionSheet" aria-label="گزینه‌های پیام"><header><div><b>{actionView === "forward" ? "ارسال پیام به…" : "گزینه‌های پیام"}</b><small>{messageActions.senderName} · {previewForMessage(messageActions)}</small></div><button aria-label="بستن گزینه‌های پیام" onClick={() => setMessageActions(null)}><X /></button></header>{actionView === "forward" ? <div className="forwardTargets" data-pull-refresh-scroll>{forwardTargets.map((conversation) => <button key={conversation.id} onClick={() => { run.mutate(() => api.forwardMessage({ messageId: messageActions.id, userId, targetConversationId: conversation.id })); setMessageActions(null); }}><MessageCircle /><span><b>{conversation.name}</b><small>{conversation.kind === "private" ? "گفتگوی خصوصی" : conversation.kind === "group" ? "گروه" : "کانال"}</small></span><Send /></button>)}{!forwardTargets.length && <Empty text="گفتگوی دیگری برای ارسال در دسترس نیست" />}<button className="backToActions" onClick={() => setActionView("menu")}><ChevronLeft />بازگشت به گزینه‌ها</button></div> : <div className="messageActionGrid"><button onClick={() => chooseReply(messageActions)}><Reply /><span>ریپلای</span></button><button disabled={messageActions.type === "system" || !forwardTargets.length} onClick={() => setActionView("forward")}><Forward /><span>ارسال به…</span></button>{messageActions.senderId === userId && messageActions.type === "text" && <button onClick={() => beginEdit(messageActions)}><Pencil /><span>ویرایش</span></button>}{messageActions.senderId === userId && messageActions.type !== "system" && <button className="danger" onClick={() => { run.mutate(() => api.deleteMessage({ messageId: messageActions.id, userId })); setMessageActions(null); if (editingMessage?.id === messageActions.id) { setEditingMessage(null); setText(""); } }}><Trash2 /><span>حذف پیام</span></button>}</div>}</section></>}
      {canPublish && !active.blocked && <div className="composerWrap">{editingMessage ? <div className="replyDraft editDraft"><Pencil /><span><b>ویرایش پیام</b><small>{editingMessage.content}</small></span><button aria-label="لغو ویرایش" onClick={() => { setEditingMessage(null); setText(""); }}><X /></button></div> : replyTarget && <div className="replyDraft"><Reply /><span><b>پاسخ به {replyTarget.author}</b><small>{replyTarget.preview}</small></span><button aria-label="لغو پاسخ" onClick={() => setReplyTarget(null)}><X /></button></div>}{emojiOpen && <div className="emojiPicker" role="group" aria-label="انتخاب ایموجی">{messageEmojis.map((emoji) => <button key={emoji} aria-label={`درج ایموجی ${emoji}`} onClick={() => { setText((value) => `${value}${emoji}`); composerInputRef.current?.focus(); }}>{emoji}</button>)}</div>}<div className="composer"><div className="composerField">{canUploadMedia && <button aria-label="آپلود عکس یا فیلم" onClick={() => mediaRef.current?.click()}><Paperclip /></button>}{active.kind !== "channel" && <button className={isRecordingVoice ? "recordingVoice" : ""} aria-label={isRecordingVoice ? "توقف و ارسال ویس" : "ضبط ویس"} aria-pressed={isRecordingVoice} onClick={() => { void toggleVoiceRecording(); }}><Mic /></button>}<button className={emojiOpen ? "emojiButton active" : "emojiButton"} aria-label="انتخاب ایموجی" aria-expanded={emojiOpen} onClick={() => setEmojiOpen((value) => !value)}><Smile /></button><input ref={composerInputRef} aria-label={editingMessage ? "ویرایش متن پیام" : "متن پیام"} value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") send(); }} placeholder={editingMessage ? "متن پیام را ویرایش کنید…" : isRecordingVoice ? "در حال ضبط… برای ارسال دوباره میکروفون را بزن" : active.kind === "channel" ? "متن مطلب کانال…" : active.confidential ? "پیام محرمانه…" : "پیام…"} /></div><button className="sendButton" aria-label={editingMessage ? "ارسال ویرایش پیام" : "ارسال پیام"} onClick={send}>{editingMessage ? <Check /> : <Send />}</button><input ref={mediaRef} className="hiddenInput" type="file" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm" onChange={(e) => { void upload(e); }} /></div></div>}
      {active.blocked && <div className="blockedLine"><Ban />این گفتگو بلاک است؛ از منوی بالا رفع بلاک کنید.</div>}
      {active.kind === "channel" && !canPublish && <button className={active.following ? "followButton following" : "followButton"} onClick={() => run.mutate(() => api.toggleFollow({ userId, conversationId: active.id }))}>{active.following ? "دنبال می‌کنید · لغو دنبال‌کردن" : "دنبال کردن کانال"}</button>}</div>}
  </div>;
}

const ludoPath: Array<[number, number]> = [[6,1],[6,2],[6,3],[6,4],[6,5],[5,6],[4,6],[3,6],[2,6],[1,6],[0,6],[0,7],[0,8],[1,8],[2,8],[3,8],[4,8],[5,8],[6,9],[6,10],[6,11],[6,12],[6,13],[6,14],[7,14],[8,14],[8,13],[8,12],[8,11],[8,10],[8,9],[9,8],[10,8],[11,8],[12,8],[13,8],[14,8],[14,7],[14,6],[13,6],[12,6],[11,6],[10,6],[9,6],[8,5],[8,4],[8,3],[8,2],[8,1],[8,0],[7,0],[6,0]];
const ludoHomeLanes: Array<Array<[number, number]>> = [
  [[7,1],[7,2],[7,3],[7,4],[7,5],[7,6]],
  [[1,7],[2,7],[3,7],[4,7],[5,7],[6,7]],
  [[7,13],[7,12],[7,11],[7,10],[7,9],[7,8]],
  [[13,7],[12,7],[11,7],[10,7],[9,7],[8,7]],
];
const boardColorLabel: Record<"red" | "blue" | "yellow" | "green", string> = { red: "قرمز", blue: "آبی", yellow: "زرد", green: "سبز" };

function LudoBoard({ session, busy, onPiece }: { session: GameSession; busy: boolean; onPiece: (pieceId: number) => void }) {
  const occupants = (row: number, col: number) => session.ludoPieces.filter((piece) => {
    if (piece.progress >= 0 && piece.progress < 52) {
      const absolute = (piece.progress + piece.playerIndex * 13) % 52;
      const cell = ludoPath[absolute];
      return cell?.[0] === row && cell[1] === col;
    }
    if (piece.progress >= 52 && piece.progress < 58) {
      const cell = ludoHomeLanes[piece.playerIndex]?.[piece.progress - 52];
      return cell?.[0] === row && cell[1] === col;
    }
    return false;
  });
  const trackByCoord = new Map(ludoPath.map((cell, index) => [`${cell[0]}-${cell[1]}`, index]));
  const laneByCoord = new Map<string, number>();
  ludoHomeLanes.forEach((lane, playerIndex) => lane.forEach((cell) => laneByCoord.set(`${cell[0]}-${cell[1]}`, playerIndex)));
  const pieceNode = (piece: GameSession["ludoPieces"][number]) => {
    const owner = session.players[piece.playerIndex];
    const movable = piece.playerIndex === 0 && session.movablePieceIds.includes(piece.id);
    const className = `boardToken ${owner?.color ?? "red"}${movable ? " movable" : ""}`;
    return movable ? <button key={`${piece.id}-${piece.progress}`} disabled={busy} className={className} aria-label={`حرکت مهره ${piece.id % 4 + 1} ${owner?.name ?? "شما"}`} onClick={() => onPiece(piece.id)}>{piece.id % 4 + 1}</button> : <span key={`${piece.id}-${piece.progress}`} className={className} aria-label={`مهره ${piece.id % 4 + 1} ${owner?.name ?? "بازیکن"}`}>{piece.id % 4 + 1}</span>;
  };
  return <div className="ludoBoard" role="grid" aria-label="تخته منچ">
    {Array.from({ length: 225 }, (_, index) => { const row = Math.floor(index / 15); const col = index % 15; const key = `${row}-${col}`; const track = trackByCoord.get(key); const lane = laneByCoord.get(key); const pieces = occupants(row, col); const safe = track !== undefined && session.safeCells.includes(track); return <div role="gridcell" key={key} className={`ludoCell${track !== undefined ? " track" : ""}${safe ? " safe" : ""}${lane !== undefined ? ` homeLane ${session.players[lane]?.color ?? "red"}` : ""}`} style={{ gridRow: row + 1, gridColumn: col + 1 }}>{safe && <Star aria-hidden="true" />}{pieces.map(pieceNode)}</div>; })}
    {session.players.map((player, playerIndex) => <div className={`ludoBase ${player.color}`} key={player.color}><b>{player.name}</b><span>{boardColorLabel[player.color]}</span><div>{session.ludoPieces.filter((piece) => piece.playerIndex === playerIndex && piece.progress < 0).map(pieceNode)}</div></div>)}
    <div className="ludoFinish" aria-label="خانه پایانی">{session.players.map((player, playerIndex) => <span className={player.color} key={player.color}>{session.ludoPieces.filter((piece) => piece.playerIndex === playerIndex && piece.progress === 58).length}</span>)}</div>
  </div>;
}

function SnakesBoard({ session }: { session: GameSession }) {
  const cells: number[] = [];
  for (let row = 9; row >= 0; row -= 1) {
    const values = Array.from({ length: 10 }, (_, index) => row * 10 + index + 1);
    cells.push(...(row % 2 === 1 ? values.reverse() : values));
  }
  const jumps: Record<number, number> = { 4: 25, 13: 46, 33: 49, 42: 63, 50: 69, 62: 81, 74: 92, 27: 5, 40: 3, 43: 18, 54: 31, 66: 45, 76: 58, 89: 53, 99: 41 };
  return <div className="snakesBoard" role="grid" aria-label="تخته مارپله از ۱ تا ۱۰۰">{cells.map((cell) => { const jump = jumps[cell]; const players = session.players.filter((_, index) => session.snakePositions[index] === cell); return <div role="gridcell" className={jump ? (jump > cell ? "ladderCell" : "snakeCell") : ""} key={cell}><small>{fa.format(cell)}</small>{jump && <i>{jump > cell ? `↑${fa.format(jump)}` : `↓${fa.format(jump)}`}</i>}<span>{players.map((player) => <b className={`boardToken ${player.color}`} key={player.color} aria-label={`${player.name} در خانه ${cell}`}>{player.name.slice(0,1)}</b>)}</span></div>; })}</div>;
}

function GamesPage({ data, selectedGame, stake, setStake, run, onRefresh, openGame, closeGame, openLeaderboard }: { data: State; selectedGame: GameType | null; stake: number; setStake: (n: number) => void; run: Runner; onRefresh: () => Promise<void>; openGame: (game: GameType) => void; closeGame: () => void; openLeaderboard: () => void }) {
  const game: GameType = selectedGame ?? "منچ";
  const [playerCount, setPlayerCount] = useState<2 | 3 | 4>(2);
  const [watching, setWatching] = useState(false);
  const [favoriteTeam, setFavoriteTeam] = useState<"تیم میزبان" | "تیم مهمان">("تیم میزبان");
  const [session, setSession] = useState<GameSession | null>(null);
  const [busy, setBusy] = useState(false);
  const [gameError, setGameError] = useState("");
  const [replaysOpen, setReplaysOpen] = useState(false);
  const [replayId, setReplayId] = useState<number | null>(null);
  const [replayStep, setReplayStep] = useState(0);
  const [replayPositions, setReplayPositions] = useState<number[]>([]);
  const [tournamentOpen, setTournamentOpen] = useState(false);
  const [avatarOpen, setAvatarOpen] = useState(false);
  const [voiceConnected, setVoiceConnected] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [giftAmount, setGiftAmount] = useState(50);
  const live = selectedGame ? data.games.find((g) => g.status === "live" && g.gameType === selectedGame) : undefined;
  const livePlayers = live?.playerNames.map((name, index) => {
    const player = data.users.find((user) => user.name === name);
    return { name, id: player?.id ?? index + 1, avatar: player ? data.gameAvatars.find((avatar) => avatar.userId === player.id) ?? null : null, virtual: false, personality: index === 0 ? "جسور و هجومی" : "آرام و حسابگر" };
  }) ?? [];
  const virtualPlayers: Array<{ name: string; id: number; avatar: GameAvatarData; virtual: true; personality: string }> = live ? [
    { name: "رُها", id: -11, virtual: true, personality: "بلوف‌زن و غیرقابل پیش‌بینی", avatar: { userId: -11, userName: "رُها", face: "soft", hair: "wave", outfit: "royal", accent: "cherry", emblem: "crown", updatedAt: "" } },
    { name: "سام", id: -12, virtual: true, personality: "صبور و تحلیل‌گر", avatar: { userId: -12, userName: "سام", face: "sharp", hair: "crest", outfit: "shadow", accent: "ocean", emblem: "shield", updatedAt: "" } },
  ] : [];
  const tablePlayers = [...livePlayers, ...virtualPlayers];
  const myAvatar = data.gameAvatars.find((avatar) => avatar.userId === data.current.id) ?? null;
  const myGift = live?.giftEntries.find((entry) => entry.spectatorId === data.current.id && entry.status === "escrow") ?? null;
  const voiceStreamRef = useRef<MediaStream | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const voiceChunksRef = useRef<Blob[]>([]);
  const voiceStartedAtRef = useRef(0);
  const voiceAudienceRef = useRef<"room" | "reward_announcement">("room");
  const voiceTimerRef = useRef<number | null>(null);
  const playedVoiceIdsRef = useRef<Set<number>>(new Set());
  const safeStake = Number.isFinite(stake) ? Math.max(0, Math.min(200, Math.round(stake))) : 0;
  const roomRecordings = selectedGame ? data.gameRecordings.filter((recording) => recording.gameType === selectedGame) : [];
  const selectedReplay = roomRecordings.find((recording) => recording.id === replayId) ?? null;
  const replayChannels = data.conversations.filter((conversation) => conversation.kind === "channel" && ["owner", "superadmin", "admin"].includes(conversation.role ?? ""));
  const advanceReplay = () => {
    if (!selectedReplay) return;
    const event = selectedReplay.events[replayStep];
    if (!event) { setReplayStep(0); setReplayPositions(Array.from({ length: selectedReplay.players.length }, () => 0)); return; }
    if (event.type === "move") setReplayPositions((positions) => positions.map((position, index) => index === event.playerIndex ? event.landing : position));
    setReplayStep((step) => step + 1);
  };
  useEffect(() => {
    setSession(null);
    setWatching(false);
    setVoiceConnected(false);
    setIsRecording(false);
    setGameError("");
    setReplayId(null);
    recorderRef.current?.stop();
    recorderRef.current = null;
    voiceStreamRef.current?.getTracks().forEach((track) => track.stop());
    voiceStreamRef.current = null;
  }, [data.current.id, selectedGame]);
  useEffect(() => () => {
    if (voiceTimerRef.current !== null) window.clearTimeout(voiceTimerRef.current);
    recorderRef.current?.stop();
    voiceStreamRef.current?.getTracks().forEach((track) => track.stop());
  }, []);
  useEffect(() => {
    if (!voiceConnected || !live?.voiceClips.length) return;
    const unseen = live.voiceClips.filter((clip) => clip.senderId !== data.current.id && !playedVoiceIdsRef.current.has(clip.id));
    live.voiceClips.forEach((clip) => playedVoiceIdsRef.current.add(clip.id));
    const newest = unseen.at(-1);
    if (newest) void new Audio(newest.url).play().catch(() => undefined);
  }, [data.current.id, live?.voiceClips, voiceConnected]);
  const connectVoice = async () => {
    if (!live?.currentRole) { setGameError("ابتدا با دکمه ورود، به اتاق زنده بپیوندید."); return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
      voiceStreamRef.current = stream;
      live.voiceClips.forEach((clip) => playedVoiceIdsRef.current.add(clip.id));
      setVoiceConnected(true);
      setGameError("");
    } catch { setGameError("اجازه میکروفن داده نشد؛ دسترسی میکروفن را فعال و دوباره اتصال را بزنید."); }
  };
  const stopVoice = () => {
    if (voiceTimerRef.current !== null) window.clearTimeout(voiceTimerRef.current);
    voiceTimerRef.current = null;
    if (recorderRef.current?.state === "recording") recorderRef.current.stop();
  };
  const startVoice = (audience: "room" | "reward_announcement") => {
    if (!live || !voiceConnected || !voiceStreamRef.current || isRecording) return;
    const mimeType = MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "audio/mp4";
    try {
      const recorder = new MediaRecorder(voiceStreamRef.current, { mimeType });
      recorderRef.current = recorder;
      voiceChunksRef.current = [];
      voiceAudienceRef.current = audience;
      voiceStartedAtRef.current = Date.now();
      recorder.ondataavailable = (event) => { if (event.data.size) voiceChunksRef.current.push(event.data); };
      recorder.onstop = () => {
        const durationMs = Math.min(20000, Date.now() - voiceStartedAtRef.current);
        const recordedAudience = voiceAudienceRef.current;
        setIsRecording(false);
        if (durationMs < 200 || !voiceChunksRef.current.length) return;
        const file = new File(voiceChunksRef.current, `live-${Date.now()}.${mimeType === "audio/webm" ? "webm" : "m4a"}`, { type: mimeType });
        run.mutate(async () => { const encoded = await fileToBase64(file); return api.sendLiveVoice({ gameRoomId: live.id, userId: data.current.id, audience: recordedAudience, dataBase64: encoded.dataBase64, mimeType, durationMs }); });
      };
      recorder.start();
      setIsRecording(true);
      voiceTimerRef.current = window.setTimeout(stopVoice, 20000);
    } catch { setGameError("ضبط ویس روی این دستگاه شروع نشد."); }
  };
  const start = async () => {
    if (busy) return;
    setBusy(true); setGameError("");
    try { const next = await api.startGameSession({ userId: data.current.id, gameType: game, stake: safeStake, playerCount }); setSession(next); await onRefresh(); }
    catch { setGameError("بازی شروع نشد. اتصال سرور را بررسی و دوباره تلاش کنید."); }
    finally { setBusy(false); }
  };
  const rollBoard = async () => {
    if (!session || session.status !== "active" || busy) return;
    setBusy(true); setGameError("");
    try {
      const next = await api.rollBoardGame({ userId: data.current.id, sessionId: session.sessionId });
      if (next.boardKind === "snakes" && next.eventQueue.length) {
        const initialPositions = [...next.snakePositions];
        for (const event of [...next.eventQueue].reverse()) if (event.type === "move") initialPositions[event.playerIndex] = event.from;
        let animated: GameSession = { ...next, snakePositions: initialPositions, die: null };
        setSession(animated);
        for (const event of next.eventQueue) {
          await new Promise((resolve) => window.setTimeout(resolve, 420));
          animated = event.type === "die"
            ? { ...animated, currentPlayerIndex: event.playerIndex, die: event.value }
            : { ...animated, snakePositions: animated.snakePositions.map((position, index) => index === event.playerIndex ? event.landing : position) };
          setSession(animated);
        }
        await new Promise((resolve) => window.setTimeout(resolve, 260));
      }
      setSession(next);
      await onRefresh();
    }
    catch { setGameError("تاس ثبت نشد؛ اگر منچ است ابتدا مهره روشن را حرکت بده."); }
    finally { setBusy(false); }
  };
  const moveLudoPiece = async (pieceId: number) => {
    if (!session || session.status !== "active" || busy) return;
    setBusy(true); setGameError("");
    try { const next = await api.moveLudoPiece({ userId: data.current.id, sessionId: session.sessionId, pieceId }); setSession(next); await onRefresh(); }
    catch { setGameError("این مهره با تاس فعلی قابل حرکت نیست."); }
    finally { setBusy(false); }
  };
  const move = async (index: number) => {
    if (!session || session.status !== "active" || busy) return;
    setBusy(true); setGameError("");
    try { const next = await api.gameMove({ userId: data.current.id, sessionId: session.sessionId, move: index }); setSession(next); await onRefresh(); }
    catch { setGameError("حرکت ثبت نشد. دوباره تلاش کنید."); }
    finally { setBusy(false); }
  };
  if (avatarOpen) return <AvatarStudio data={data} run={run} close={() => setAvatarOpen(false)} />;
  if (tournamentOpen) return <TournamentPanel data={data} run={run} close={() => setTournamentOpen(false)} openAvatar={() => { setTournamentOpen(false); setAvatarOpen(true); }} enterGame={(type) => { openGame(type); setSession(null); setTournamentOpen(false); }} />;
  if (!selectedGame) return <div className="page gamesPage gameLobbyPage" data-game-lobby="true">
    <div className="gamesHeading"><PageTitle title="اتاق‌های بازی" subtitle={`امتیاز ثبت‌شده ${fa.format(data.playerScores.find((player) => player.id === data.current.id)?.points ?? 0)} · ${fa.format(data.current.wins)} برد`} /><div className="gameHeadingActions"><button className={myAvatar ? "avatarShortcut ready" : "avatarShortcut"} onClick={() => setAvatarOpen(true)}><PlayerAvatar avatar={myAvatar} name={data.current.name} index={data.current.id} /><span>{myAvatar ? "آواتار من" : "ساخت آواتار"}</span></button><button className="tournamentShortcut" onClick={() => setTournamentOpen(true)}><Trophy /><span>تورنمنت</span></button><button className="scoreShortcut" onClick={openLeaderboard}><BarChart3 /><span>امتیاز</span></button></div></div>
    {!myAvatar && data.current.accessRole === "user" && <button className="avatarNudge" onClick={() => setAvatarOpen(true)}><Palette /><span><b>ورودی مسابقه با آواتار باز می‌شود</b><small>چهره بازی خودت را بساز و برای تورنمنت آماده شو.</small></span><ChevronLeft /></button>}
    {data.current.accessRole === "user" && <MiniArcadePanel data={data} onRefresh={onRefresh} />}
    <section className="gameRoomMenu" aria-label="انتخاب اتاق بازی" data-pull-refresh-scroll data-pull-refresh-page="game-room-menu">
      {gameTypes.map((type, index) => { const liveRoom = data.games.find((item) => item.status === "live" && item.gameType === type); const recordings = data.gameRecordings.filter((item) => item.gameType === type).length; return <button key={type} aria-label={`ورود به اتاق ${type}`} onClick={() => openGame(type)}><span className="gameRoomIcon">{type === "منچ" || type === "مارپله" ? <Dice5 /> : <Gamepad2 />}</span><span><b>اتاق {type}</b><small>{liveRoom ? `${fa.format(liveRoom.spectators)} تماشاچی · زنده` : recordings ? `${fa.format(recordings)} بازپخش ثبت‌شده` : "میز اختصاصی آماده"}</small></span><i>{fa.format(index + 1)}</i><ChevronLeft /></button>; })}
    </section>
    <div className="gameLobbyHint"><Radio /><span><b>هر بازی، اتاق خودش</b><small>با انتخاب بازی مستقیماً وارد میز، تماشاچیان، ویس، هدیه و بازپخش همان بازی می‌شوی.</small></span></div>
  </div>;
  return <div className={watching && live ? "page gamesPage gameRoomPage cinemaPage" : "page gamesPage gameRoomPage"} data-game-room={selectedGame} aria-label={`اتاق اختصاصی ${selectedGame}`}>{!(watching && live) && <div className="gameRoomHeading"><button aria-label="بازگشت به فهرست اتاق‌های بازی" onClick={closeGame}><ChevronLeft /></button><div><span>اتاق اختصاصی</span><h1>{selectedGame}</h1><small>{live ? "میز زنده این بازی فعال است" : "میز بازی و امکانات اختصاصی"}</small></div><div className="gameRoomTools"><button className={myAvatar ? "avatarShortcut ready" : "avatarShortcut"} aria-label="آواتار من" onClick={() => setAvatarOpen(true)}><PlayerAvatar avatar={myAvatar} name={data.current.name} index={data.current.id} /></button><button className="scoreShortcut" aria-label="جدول امتیازها" onClick={openLeaderboard}><BarChart3 /></button></div></div>}
    {watching && live ? <section className="spectatorRoom liveVoiceRoom cinemaRoom">
      <header><div><Radio /><span><b>{live.currentRole === "player" ? "ویس زنده بازیکنان" : "اتاق زنده تماشاچیان"}</b><small>{live.gameType} · بازیکنان {live.playerNames.join(" و ")}</small></span></div><button aria-label="بستن اتاق زنده" onClick={() => setWatching(false)}><X /></button></header>
      <div className="liveRoomGrid cinemaLayout">
        <section className="cinemaStage" aria-label={`نمای بزرگ پخش زنده ${live.gameType}`}>
          <div className="cinemaHud"><span className="onAir"><i />پخش زنده</span><span><Eye />{fa.format(live.spectators)} تماشاچی</span><span><Coins />ورودی {fa.format(live.stake)}</span></div>
          <div className="arenaScene">
            <div className="arenaGlow" />
            <div className="playerSeats">{tablePlayers.map((player, index) => { const isHostTeam = index === 0 || index === 2; const mood = isHostTeam ? live.hostMood : live.guestMood; const chance = isHostTeam ? live.hostChance : 100 - live.hostChance; return <article className={`playerSeat seat-${index + 1} ${player.virtual ? "virtualSeat" : ""}`} key={`${player.name}-${index}`}><div className="avatarReaction">{mood === "celebrate" ? "برد نزدیکه!" : mood === "worried" ? "تمرکز…" : "آماده"}</div><PlayerAvatar avatar={player.avatar} name={player.name} index={player.id} size="large" mood={mood} /><span><b>{player.name}</b><small>{player.virtual ? `یار مجازی · ${player.personality}` : index === 0 ? "میزبان · جسور" : "بازیکن · حسابگر"}</small></span><div className="chanceMeter" aria-label={`شانس زنده ${player.name} ${chance} درصد`}><i style={{ width: `${chance}%` }} /><b>{fa.format(chance)}٪</b></div></article>; })}</div>
            <div className="gameTable"><div><Gamepad2 /><span>دور {fa.format(live.turnNumber)}</span><strong>{live.gameType}</strong><small>{live.lastEvent}</small></div></div>
            <div className="commentatorOverlay"><Radio /><span><b>گزارشگر مجازی</b><small>{live.commentary}</small></span></div>
            <div className="floatingCheers" aria-live="polite">{live.recentCheers.slice(0, 4).map((cheer, index) => <span style={{ animationDelay: `${index * 110}ms` }} key={cheer.id}>{cheer.reaction}<small>{cheer.senderName}</small></span>)}</div>
          </div>
          <footer><div className="cinemaNow"><span className="livePulse" /><b>داور هوشمند · دور {fa.format(live.turnNumber)}</b></div>{live.hostId === data.current.id ? <button className="directorButton" onClick={() => run.mutate(() => api.advanceLiveDirector({ gameRoomId: live.id, userId: data.current.id }))}><Sparkles />اجرای دور بعد</button> : <span>گزارش و درصد برد با هر دور به‌روز می‌شود</span>}</footer>
        </section>
        <aside className="cinemaSidecar" aria-label="ابزار تماشاچی">
        <section className="voicePanel">
          <div className="voiceStatus"><div className={voiceConnected ? "voiceDot connected" : "voiceDot"} /><span><b>{voiceConnected ? "ویس متصل است" : "ویس هنوز متصل نیست"}</b><small>{live.currentRole === "player" ? "فقط بازیکنان را می‌شنوید؛ صدای تماشاچی فقط هنگام اعلام هدیه وارد میز می‌شود." : "صدای بازیکنان و همه تماشاچیان را می‌شنوید؛ صدای عادی شما وارد میز بازیکنان نمی‌شود."}</small></span></div>
          {!live.currentRole ? <div className="joinVoice"><label>تیم مورد علاقه<select aria-label="انتخاب تیم مورد علاقه" value={favoriteTeam} onChange={(e) => setFavoriteTeam(e.target.value as "تیم میزبان" | "تیم مهمان")}><option>تیم میزبان</option><option>تیم مهمان</option></select></label><button className="primary" onClick={() => run.mutate(() => api.watchGame({ gameRoomId: live.id, userId: data.current.id, favoriteTeam }))}><Eye />ورود به اتاق زنده</button></div> : !voiceConnected ? <button className="connectVoice" onClick={() => { void connectVoice(); }}><Mic />اتصال به ویس</button> : <div className="voiceControls"><button className={isRecording && voiceAudienceRef.current === "room" ? "pushToTalk recording" : "pushToTalk"} disabled={isRecording && voiceAudienceRef.current !== "room"} aria-label={live.currentRole === "player" ? "برای صحبت با بازیکنان نگه دارید" : "برای صحبت در اتاق تماشاچیان نگه دارید"} onPointerDown={() => startVoice("room")} onPointerUp={stopVoice} onPointerCancel={stopVoice} onPointerLeave={stopVoice} onKeyDown={(e) => { if ((e.key === " " || e.key === "Enter") && !e.repeat) startVoice("room"); }} onKeyUp={(e) => { if (e.key === " " || e.key === "Enter") stopVoice(); }}><Mic /><span>{isRecording && voiceAudienceRef.current === "room" ? "رها کن تا ارسال شود" : live.currentRole === "player" ? "برای صحبت با بازیکنان نگه دار" : "صحبت زنده با تماشاچیان"}</span><small>{live.currentRole === "player" ? "صدای میز برای تماشاچیان هم شنیده می‌شود" : "فقط در اتاق تماشاچیان"}</small></button>{live.currentRole === "spectator" && <button className={isRecording && voiceAudienceRef.current === "reward_announcement" ? "rewardVoiceButton recording" : "rewardVoiceButton"} disabled={!myGift || (isRecording && voiceAudienceRef.current !== "reward_announcement")} aria-label="برای اعلام هدیه به بازیکنان نگه دارید" onPointerDown={() => startVoice("reward_announcement")} onPointerUp={stopVoice} onPointerCancel={stopVoice} onPointerLeave={stopVoice} onKeyDown={(e) => { if ((e.key === " " || e.key === "Enter") && !e.repeat) startVoice("reward_announcement"); }} onKeyUp={(e) => { if (e.key === " " || e.key === "Enter") stopVoice(); }}><Gift /><span>{isRecording && voiceAudienceRef.current === "reward_announcement" ? "رها کن تا به بازیکنان برسد" : `اعلام هدیه ${fa.format(myGift?.amount ?? 0)} سکه‌ای`}</span><small>{myGift ? "فقط این صدا وارد اتاق بازیکنان می‌شود" : "اول هدیه را به امانت بسپار"}</small></button>}</div>}
          <div className="voiceFeed" data-pull-refresh-scroll aria-live="polite">{live.voiceClips.slice(-4).map((clip) => <article className={clip.audience === "reward_announcement" ? "rewardAnnouncement" : ""} key={clip.id}><Avatar name={clip.senderName} index={clip.senderId} /><span><b>{clip.senderName}</b><small>{clip.senderRole === "player" ? "بازیکن · اتاق بازی و تماشاچیان" : clip.audience === "reward_announcement" ? "اعلام هدیه · شنیدنی برای بازیکنان" : "تماشاچی · فقط اتاق تماشاچیان"}</small></span><audio src={clip.url} controls preload="none" aria-label={`ویس زنده ${clip.senderName}`} /></article>)}{!live.voiceClips.length && <p>{live.currentRole === "player" ? "هنوز صدایی در اتاق بازی نیست." : "اتاق تماشاچیان آماده گفت‌وگوی زنده است."}</p>}</div>
        </section>
        <section className="cheerPanel" aria-label="تشویق زنده"><header><Sparkles /><span><b>تشویق زنده</b><small>با یک ضربه روی تصویر مسابقه ظاهر می‌شود</small></span></header><div>{liveCheerEmojis.map((reaction) => { const count = live.cheers.find((item) => item.reaction === reaction)?.count ?? 0; return <button key={reaction} aria-label={`ارسال تشویق ${reaction}`} onClick={() => run.mutate(() => api.cheerLiveGame({ gameRoomId: live.id, userId: data.current.id, reaction }))}><span>{reaction}</span><b>{fa.format(count)}</b></button>; })}</div></section>
        <section className="giftEscrow">
          <header><Gift /><span><b>هدیه امانی تماشاچیان</b><small>پس از نتیجه: ۳۰٪ کارمزد، ۷۰٪ برای برنده</small></span><strong>{fa.format(live.giftPool)} سکه</strong></header>
          <div className="escrowTotals"><span>در امانت <b>{fa.format(live.giftPool)}</b></span><span>سهم برنده <b>{fa.format(live.giftPayout)}</b></span><span>کارمزد <b>{fa.format(live.giftFee)}</b></span></div>
          <div className="giftLedger" data-pull-refresh-scroll>{live.giftEntries.map((entry) => <div key={entry.spectatorId}><span><Avatar name={entry.spectatorName} index={entry.spectatorId} /><b>{entry.spectatorName}</b></span><strong>{fa.format(entry.amount)}</strong><small>{entry.status === "escrow" ? "در امانت" : entry.status === "released" ? `پرداخت ${fa.format(entry.paidAmount)}` : "برگشت‌شده"}</small></div>)}{!live.giftEntries.length && <p>هنوز هدیه‌ای برای این میز سپرده نشده است.</p>}</div>
          {live.currentRole === "spectator" && <div className="giftComposer"><label>افزایش هدیه من<input aria-label="مبلغ افزایش هدیه" type="number" min={1} max={500} value={giftAmount} onChange={(e) => setGiftAmount(Math.max(1, Math.min(500, Number(e.target.value) || 1)))} /></label><button onClick={() => run.mutate(() => api.addSpectatorGift({ gameRoomId: live.id, userId: data.current.id, amount: giftAmount }))}><Coins />سپردن {fa.format(giftAmount)} سکه</button></div>}
        </section>
        </aside>
      </div>
      {gameError && <p role="alert" className="gameError roomError">{gameError}</p>}
      <div className="roomActions"><button onClick={() => run.mutate(() => api.placeBet({ gameRoomId: live.id, userId: data.current.id, favoriteTeam, amount: 10 }))} disabled={live.currentRole !== "spectator"}><CircleDollarSign />شرط ۱۰ سکه روی {favoriteTeam}</button>{live.hostId === data.current.id && <div className="settleControls"><span>ثبت نتیجه و آزادسازی هدیه امانی</span><button onClick={() => run.mutate(() => api.settleLiveGame({ gameRoomId: live.id, userId: data.current.id, winnerTeam: "تیم میزبان" }))}>برد میزبان</button><button onClick={() => run.mutate(() => api.settleLiveGame({ gameRoomId: live.id, userId: data.current.id, winnerTeam: "تیم مهمان" }))}>برد مهمان</button></div>}</div>
    </section> : <>
      <section className={`gameConsole interactiveConsole${session ? " hasGameSession" : " gameStartConsole"}${session?.boardKind === "ludo" || session?.boardKind === "snakes" ? " boardGameConsole" : ""}`} data-pull-refresh-scroll data-pull-refresh-page={`game-${game}`}>
        {!session ? <><div className="gameGlyph">{game === "منچ" || game === "مارپله" ? <Dice5 /> : <Gamepad2 />}</div><div className="gameIntro"><span>بازی قابل اجرا</span><h3>{game}</h3><p>{game === "منچ" ? "چهار مهره، خانه‌های امن و گرفتن حریف؛ تاس و حرکت‌ها روی سرور کنترل می‌شوند." : game === "مارپله" ? "با تاس سروری و چیدمان ثابت مارها و نردبان‌ها دقیقاً به خانه ۱۰۰ برس." : game === "۲۱" ? "کارت بگیر یا بایست و با حریف سروری بازی کن." : game === "حکم" ? "سه دست کارت را انتخاب و با حریف بازی کن." : game === "پوکر" ? "یک کارت را عوض کن و دستت را با حریف مقایسه کن." : game === "کوئیز" ? "به پرسش دانستنی پاسخ بده." : "سرنخ‌ها را بخوان و مافیا را پیدا کن."}</p></div><div className="gameSetup"><label className="stakeField">ورودی<input aria-label="مبلغ ورودی بازی" type="number" min={0} max={200} value={stake} onChange={(e) => setStake(Number(e.target.value))} /></label>{(game === "منچ" || game === "مارپله") && <label className="playerCountField">بازیکن<select aria-label="تعداد بازیکنان" value={playerCount} onChange={(e) => setPlayerCount(Number(e.target.value) as 2 | 3 | 4)}><option value={2}>۲ نفر</option><option value={3}>۳ نفر</option><option value={4}>۴ نفر</option></select></label>}</div><button className="primary startGameButton" aria-label={`شروع بازی ${game}`} disabled={busy} onClick={() => { void start(); }}>{busy ? "در حال شروع بازی…" : `شروع بازی ${game}`}</button></> : <div className={`interactiveBoard${session.boardKind !== "classic" ? " boardSession" : ""}`} aria-live="polite">
          <header><div><span>میز شماره {fa.format(session.sessionId)} · {session.players.length ? `${fa.format(session.players.length)} بازیکن` : "سرور معتبر"}</span><h3>{session.gameType}</h3></div><div className="sessionBalance"><Coins />{fa.format(session.coins)}</div></header>
          <p className="gamePrompt">{session.prompt}</p>
          {session.boardKind === "ludo" ? <LudoBoard session={session} busy={busy} onPiece={(pieceId) => { void moveLudoPiece(pieceId); }} /> : session.boardKind === "snakes" ? <SnakesBoard session={session} /> : <div className="boardLines">{session.board.map((line, index) => <div key={`${line}-${index}`}>{line}</div>)}</div>}
          {session.result && <output className={session.status === "finished" ? (session.won ? "gameResult won" : "gameResult lost") : "gameResult"}>{session.result}</output>}
          {session.status === "active" ? session.boardKind !== "classic" ? <div className="boardControls"><div className="turnStrip">{session.players.map((player, index) => <span className={`${player.color}${session.currentPlayerIndex === index ? " active" : ""}`} key={player.color}>{player.name}{player.bot ? " · مجازی" : " · شما"}</span>)}</div><button className="diceButton" disabled={busy || session.currentPlayerIndex !== 0 || (session.boardKind === "ludo" && session.die !== null)} aria-label="ریختن تاس" onClick={() => { void rollBoard(); }}><Dice5 /><b>{session.die ? fa.format(session.die) : busy ? "…" : "تاس بریز"}</b></button></div> : <div className="moveGrid">{session.options.map((option, index) => <button disabled={busy} key={option} onClick={() => { void move(index); }}>{busy ? "…" : option}</button>)}</div> : <button className="primary replayButton" onClick={() => { setSession(null); setGameError(""); }}>بازی تازه</button>}
        </div>}
        {session?.boardKind === "snakes" && session.eventQueue.length > 0 && <div className="turnEventRail" aria-live="polite">{session.eventQueue.map((event, index) => <span key={`${event.type}-${index}`} className={event.type}>{event.type === "die" ? `تاس ${session.players[event.playerIndex]?.name ?? "بازیکن"}: ${fa.format(event.value)}` : `${session.players[event.playerIndex]?.name ?? "بازیکن"}: ${fa.format(event.from)} ← ${fa.format(event.landing)}${event.jump === "ladder" ? " · نردبان" : event.jump === "snake" ? " · مار" : ""}`}</span>)}</div>}
        {gameError && <p role="alert" className="gameError">{gameError}</p>}
      </section>
      <section className="replayShelf"><header><div><Repeat /><span><b>بازپخش {game}</b><small>{fa.format(roomRecordings.length)} ضبط رویدادمحور این اتاق</small></span></div><button onClick={() => setReplaysOpen((open) => !open)}>{replaysOpen ? "بستن" : "نمایش ضبط‌ها"}</button></header>{replaysOpen && <div className="replayBody"><div className="replayList" data-pull-refresh-scroll data-pull-refresh-page={`replay-list-${game}`}>{roomRecordings.map((recording) => <button className={replayId === recording.id ? "selected" : ""} key={recording.id} onClick={() => { setReplayId(recording.id); setReplayStep(0); setReplayPositions(Array.from({ length: recording.players.length }, () => 0)); }}><b>{recording.gameType} · میز {fa.format(recording.id)}</b><small>{fa.format(Math.floor(recording.events.length / 2))} حرکت · {recording.status === "finished" ? "پایان‌یافته" : "در حال ضبط"}</small></button>)}{!roomRecordings.length && <Empty text={`هنوز بازپخشی برای ${game} ثبت نشده است`} />}</div>{selectedReplay && <section className="replayPlayer" data-pull-refresh-scroll data-pull-refresh-page="replay-player"><header><b>{selectedReplay.gameType} · گام {fa.format(replayStep)} از {fa.format(selectedReplay.events.length)}</b><small>{selectedReplay.result || "ثبت رویدادهای بازی"}</small></header><div className="replayPositions">{selectedReplay.players.map((player,index) => <span key={`${player.name}-${index}`}><i className={player.color} />{player.name}<b>خانه {fa.format(replayPositions[index] ?? 0)}</b></span>)}</div><button className="primary" onClick={advanceReplay}><Repeat />{replayStep >= selectedReplay.events.length ? "شروع دوباره" : "گام بعد"}</button><div className="publishRecording"><span>انتشار در کانال</span>{replayChannels.map((channel) => <button key={channel.id} onClick={() => run.mutate(() => api.publishGameRecording({ userId: data.current.id, sessionId: selectedReplay.id, conversationId: channel.id }))}>{channel.name}</button>)}{!replayChannels.length && <small>برای انتشار باید مدیر یا ادمین یک کانال باشید.</small>}</div></section>}</div>}</section>
      <section className="liveBar"><div className="livePulse" /><div><b>{live ? `${live.gameType} زنده با میزبانی ${live.hostName}` : "بازی زنده‌ای نیست"}</b><span>{live ? `${live.spectators} تماشاچی · ورودی ${live.stake} سکه` : "یک اتاق زنده بسازید"}</span></div>{live ? <button onClick={() => { setFavoriteTeam(live.favoriteTeam === "تیم مهمان" ? "تیم مهمان" : "تیم میزبان"); setWatching(true); }}><Mic />{live.currentRole === "player" ? "ویس بازی" : "تماشا و ویس"}</button> : <button onClick={() => run.mutate(() => api.createLiveGame({ userId: data.current.id, gameType: game, stake: safeStake }))}><Plus />ساخت</button>}</section></>}
  </div>;
}

function MiniArcadePanel({ data, onRefresh }: { data: State; onRefresh: () => Promise<void> }) {
  const [duel, setDuel] = useState<{ duelId: number; question: string; options: string[]; expiresAt: string } | null>(null);
  const [seconds, setSeconds] = useState(0);
  const [duelMessage, setDuelMessage] = useState("");
  const [assistantMessage, setAssistantMessage] = useState(data.detectiveSolved ? "پرونده را حل کردی؛ نشان کارآگاه دقیق برایت محفوظ است." : "بدون عجله سرنخ‌ها را کنار هم بگذار؛ اگر اشتباه کنی، دوباره بررسی می‌کنیم.");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (!duel) return;
    const update = () => setSeconds(Math.max(0, Math.ceil((new Date(duel.expiresAt).getTime() - Date.now()) / 1000)));
    update();
    const timer = window.setInterval(update, 200);
    return () => window.clearInterval(timer);
  }, [duel]);
  const startDuel = async () => {
    if (busy) return;
    setBusy(true); setDuelMessage("");
    try { const result = await api.startQuickDuel({ userId: data.current.id }); setDuel(result); }
    catch { setDuelMessage("دوئل شروع نشد؛ دوباره تلاش کن."); }
    finally { setBusy(false); }
  };
  const answerDuel = async (option: number) => {
    if (!duel || busy) return;
    setBusy(true);
    try { const result = await api.answerQuickDuel({ userId: data.current.id, duelId: duel.duelId, option }); setDuelMessage(result.message); setDuel(null); await onRefresh(); }
    catch { setDuelMessage("پاسخ ثبت نشد؛ اتصال را بررسی کن."); }
    finally { setBusy(false); }
  };
  const spin = async () => {
    if (busy || data.wheelSpunToday) return;
    setBusy(true);
    try { const result = await api.spinDailyWheel({ userId: data.current.id }); setDuelMessage(result.message); await onRefresh(); }
    catch { setDuelMessage("گردانه نچرخید؛ دوباره تلاش کن."); }
    finally { setBusy(false); }
  };
  const accuse = async (accused: "ahmad" | "reza" | "sohrab") => {
    if (busy || data.detectiveSolved) return;
    setBusy(true);
    try { const result = await api.solveDetectiveCase({ userId: data.current.id, accused }); setAssistantMessage(result.correct ? `آفرین کارآگاه! ${result.message}` : `اشکالی ندارد؛ ${result.message}`); await onRefresh(); }
    catch { setAssistantMessage("پرونده فعلاً پاسخ نداد؛ چند لحظه دیگر امتحان کن."); }
    finally { setBusy(false); }
  };
  return <section className="miniArcade" aria-label="چالش‌های سریع">
    <header><div><Zap /><span><b>چالش‌های سریع</b><small>سه بازی کوتاه با نتیجه ثبت‌شده روی سرور</small></span></div><button disabled={busy || data.wheelSpunToday} onClick={() => { void spin(); }}><Gift />{data.wheelSpunToday ? "گردانه امروز انجام شد" : "گردانه روزانه"}</button></header>
    <div className="quickDuelCard"><div><span className="duelTimer">{duel ? fa.format(seconds) : "۵"}</span><p><b>دوئل پنج‌ثانیه‌ای</b><small>پاسخ درست: ۵۰ سکه</small></p></div>{duel ? <div className="duelQuestion" aria-live="assertive"><strong>{duel.question}</strong><div>{duel.options.map((option, index) => <button disabled={busy || seconds === 0} key={option} onClick={() => { void answerDuel(index); }}>{option}</button>)}</div></div> : <button className="startDuel" disabled={busy} onClick={() => { void startDuel(); }}><Zap />شروع دوئل</button>}</div>
    <details className="detectiveCase"><summary><span><Shield /><b>پرونده کارآگاهی: صندوق باشگاه</b><small>ورودی ۲۰ · جایزه ۲۰۰ سکه</small></span><ChevronLeft /></summary><div className="detectiveBody"><aside><Heart /><p><b>دستیار حامی</b><span>{assistantMessage}</span></p></aside><p>ساعت ۲ بامداد صندوق باشگاه باز شده. احمد می‌گوید خواب بوده اما کفش‌هایش خیس است؛ رضا می‌گوید آنجا نبوده اما ساعتش کنار صندوق مانده؛ سهراب کلید یدک داشته اما مرخصی‌اش ثبت شده است.</p><div>{([['ahmad','احمد'],['reza','رضا'],['sohrab','سهراب']] as const).map(([id, name]) => <button key={id} disabled={busy || data.detectiveSolved} onClick={() => { void accuse(id); }}>{data.detectiveSolved ? "حل شد" : `اتهام به ${name}`}</button>)}</div></div></details>
    {duelMessage && <p className="miniArcadeMessage" role="status">{duelMessage}</p>}
  </section>;
}

function AvatarStudio({ data, run, close }: { data: State; run: Runner; close: () => void }) {
  const existing = data.gameAvatars.find((avatar) => avatar.userId === data.current.id) ?? null;
  const [face, setFace] = useState<GameAvatarData["face"]>(existing?.face ?? "round");
  const [hair, setHair] = useState<GameAvatarData["hair"]>(existing?.hair ?? "short");
  const [outfit, setOutfit] = useState<GameAvatarData["outfit"]>(existing?.outfit ?? "ranger");
  const [accent, setAccent] = useState<GameAvatarData["accent"]>(existing?.accent ?? "emerald");
  const [emblem, setEmblem] = useState<GameAvatarData["emblem"]>(existing?.emblem ?? "star");
  const preview: GameAvatarData = { userId: data.current.id, userName: data.current.name, face, hair, outfit, accent, emblem, updatedAt: existing?.updatedAt ?? new Date().toISOString() };
  const isPlayer = data.current.accessRole === "user";
  const faceOptions: Array<{ value: GameAvatarData["face"]; label: string }> = [{ value: "round", label: "گرد" }, { value: "sharp", label: "زاویه‌دار" }, { value: "soft", label: "ملایم" }];
  const hairOptions: Array<{ value: GameAvatarData["hair"]; label: string }> = [{ value: "short", label: "کوتاه" }, { value: "wave", label: "موج‌دار" }, { value: "crest", label: "تاجی" }, { value: "hood", label: "هود" }];
  const outfitOptions: Array<{ value: GameAvatarData["outfit"]; label: string }> = [{ value: "ranger", label: "رنجر" }, { value: "royal", label: "سلطنتی" }, { value: "shadow", label: "سایه" }, { value: "sport", label: "ورزشی" }];
  const accentOptions: Array<{ value: GameAvatarData["accent"]; label: string }> = [{ value: "emerald", label: "زمردی" }, { value: "cherry", label: "آلبالویی" }, { value: "gold", label: "طلایی" }, { value: "ocean", label: "اقیانوسی" }];
  const emblemOptions: Array<{ value: GameAvatarData["emblem"]; label: string }> = [{ value: "star", label: "ستاره" }, { value: "shield", label: "سپر" }, { value: "bolt", label: "آذرخش" }, { value: "crown", label: "تاج" }];
  const choiceGroup = <T extends string,>(title: string, options: Array<{ value: T; label: string }>, value: T, choose: (next: T) => void) => <fieldset className="avatarChoices"><legend>{title}</legend><div>{options.map((option) => <button type="button" className={option.value === value ? "selected" : ""} aria-pressed={option.value === value} key={option.value} onClick={() => choose(option.value)}>{option.label}</button>)}</div></fieldset>;
  return <div className="page avatarStudioPage">
    <div className="avatarStudioHead"><button aria-label="بازگشت به اتاق سرگرمی" onClick={close}><ChevronLeft /></button><PageTitle title="کارگاه آواتار بازیکن" subtitle="نشان اختصاصی شما در میزها و مسابقات" /><div className="avatarStudioMark"><Palette /></div></div>
    <div className="avatarStudioLayout">
      <section className="avatarPreviewCard"><span>پیش‌نمایش بازیکن</span><PlayerAvatar avatar={preview} name={data.current.name} size="large" /><h2>{data.current.name}</h2><p>{existing ? "آواتار ذخیره‌شده را می‌توانی هر زمان تغییر بدهی." : "برای ثبت‌نام در تورنمنت، اول این آواتار را ذخیره کن."}</p><div className="avatarReadiness"><ShieldCheck /><span><b>{existing ? "آماده مسابقه" : "هنوز ذخیره نشده"}</b><small>{existing ? "ورودی تورنمنت برای این بازیکن باز است" : "پس از ذخیره، ثبت‌نام فعال می‌شود"}</small></span></div></section>
      {isPlayer ? <section className="avatarWorkbench">
        {choiceGroup("فرم چهره", faceOptions, face, setFace)}
        {choiceGroup("مدل مو و پوشش", hairOptions, hair, setHair)}
        {choiceGroup("لباس بازی", outfitOptions, outfit, setOutfit)}
        {choiceGroup("رنگ اصلی", accentOptions, accent, setAccent)}
        {choiceGroup("نشان بازیکن", emblemOptions, emblem, setEmblem)}
        <button className="primary avatarSave" onClick={() => { run.mutate(() => api.saveGameAvatar({ userId: data.current.id, face, hair, outfit, accent, emblem })); close(); }}><Check />{existing ? "ذخیره تغییرات آواتار" : "ساخت آواتار و آماده‌شدن"}</button>
      </section> : <section className="avatarWorkbench avatarViewOnly"><ShieldAlert /><h3>حساب مدیریتی بازیکن نیست</h3><p>ساخت آواتار فقط برای حساب‌های بازیکن فعال است. از نوار بالای صفحه یکی از حساب‌های بازیکن را انتخاب کنید.</p></section>}
      <section className="avatarRoster"><header><Users /><span><b>بازیکنان آماده</b><small>{fa.format(data.gameAvatars.length)} آواتار ذخیره‌شده</small></span></header><div>{data.gameAvatars.map((avatar) => <article key={avatar.userId}><PlayerAvatar avatar={avatar} name={avatar.userName} size="medium" /><span><b>{avatar.userName}</b><small>آماده ورود به مسابقات</small></span><AvatarEmblem emblem={avatar.emblem} /></article>)}{!data.gameAvatars.length && <Empty text="هنوز بازیکنی آواتار مسابقه نساخته است" />}</div></section>
    </div>
  </div>;
}

function TournamentPanel({ data, run, close, openAvatar, enterGame }: { data: State; run: Runner; close: () => void; openAvatar: () => void; enterGame: (game: "مافیا" | "حکم" | "پوکر" | "۲۱" | "کوئیز" | "منچ" | "مارپله") => void }) {
  const [gameType, setGameType] = useState<"مافیا" | "حکم" | "پوکر" | "۲۱" | "کوئیز" | "منچ" | "مارپله">("منچ");
  const [entryFee, setEntryFee] = useState(50);
  const [favoriteTeam, setFavoriteTeam] = useState<"تیم میزبان" | "تیم مهمان">("تیم میزبان");
  const tournament = data.tournament;
  const myAvatar = data.gameAvatars.find((avatar) => avatar.userId === data.current.id) ?? null;
  const isRegistered = !!tournament?.registrations.some((registration) => registration.groupId === data.currentGroupId);
  const pointsFor = (groupId: number) => (tournament?.matches.filter((match) => match.status === "finished" && match.winnerGroupId === groupId).length ?? 0) * 3;
  const ranked = [...(tournament?.registrations ?? [])].sort((a, b) => pointsFor(b.groupId) - pointsFor(a.groupId) || a.groupId - b.groupId);
  const avatarForGroup = (groupId: number) => { const registration = tournament?.registrations.find((item) => item.groupId === groupId); return data.gameAvatars.find((item) => registration?.memberNames.includes(item.userName)); };
  const liveMatch = tournament?.matches.find((match) => match.status === "live") ?? null;
  const nextMatch = tournament?.matches.find((match) => match.status === "scheduled") ?? null;
  const allFinished = !!tournament?.matches.length && tournament.matches.every((match) => match.status === "finished");
  const defaultChampion = ranked[0]?.groupId ?? 0;
  const [championId, setChampionId] = useState(defaultChampion);
  useEffect(() => { if (!championId && defaultChampion) setChampionId(defaultChampion); }, [championId, defaultChampion]);
  const createForm = <section className="tournamentCreate"><div><Trophy /><span><b>{tournament?.status === "finished" ? "دوره بعدی" : "نخستین دوره"}</b><small>بازی و ورودی را مدیر تعیین می‌کند.</small></span></div><label>بازی<select aria-label="بازی تورنمنت" value={gameType} onChange={(e) => setGameType(e.target.value as typeof gameType)}>{(["منچ", "مارپله", "حکم", "مافیا", "پوکر", "۲۱", "کوئیز"] as const).map((name) => <option key={name}>{name}</option>) }</select></label><label>ورودی گروه<input aria-label="ورودی سکه‌ای هر گروه" type="number" min={0} max={500} value={entryFee} onChange={(e) => setEntryFee(Math.max(0, Math.min(500, Number(e.target.value) || 0)))} /></label><button className="primary" onClick={() => run.mutate(() => api.adminCreateTournament({ userId: data.current.id, gameType, entryFee }))}>باز کردن ثبت‌نام</button></section>;
  return <div className="page tournamentPage">
    <div className="tournamentHead"><button aria-label="بازگشت به سرگرمی" onClick={close}><ChevronLeft /></button><PageTitle title="تورنمنت هفتگی گروه‌ها" subtitle="مسابقه دوره‌ای، تماشا، شرط تیمی و جایزه مشترک" /><div className="tournamentCup"><Trophy /></div></div>
    {!tournament ? (data.current.isAdmin ? createForm : <div className="tournamentEmpty"><Trophy /><h3>دوره‌ای باز نشده است</h3><p>مدیر بازی و ورودی دوره بعد را تعیین می‌کند.</p></div>) : <>
      <section className="tournamentStatus"><div><span>{tournament.status === "registration" ? "ثبت‌نام باز" : tournament.status === "live" ? "در حال برگزاری" : "پایان‌یافته"}</span><h2>{tournament.title}</h2><p>ورودی هر گروه {fa.format(tournament.entryFee)} سکه · جایزه فعلی {fa.format(tournament.prizePool)} سکه</p></div><div className="prizeCoin"><Coins /><b>{fa.format(tournament.prizePool)}</b><small>جایزه</small></div></section>
      {tournament.status === "finished" && <section className="championBanner"><Trophy /><div><span>قهرمان هفته</span><b>{tournament.championGroupName ?? "گروه قهرمان"}</b><small>جایزه بین اعضای گروه تقسیم شد</small></div></section>}
      <div className="tournamentBody">
        {tournament.status === "registration" && <div className="registrationPanel"><header><div><b>{fa.format(tournament.registrations.length)} گروه ثبت‌نام‌شده</b><span>ورودی از حساب نماینده گروه کم می‌شود و مستقیم به جایزه می‌رود.</span></div>{!data.current.isAdmin && data.currentGroupId && (myAvatar ? <button disabled={isRegistered} onClick={() => run.mutate(() => api.registerTournament({ userId: data.current.id, tournamentId: tournament.id }))}>{isRegistered ? <Check /> : <Plus />}{isRegistered ? "گروه شما ثبت شده" : "ثبت‌نام گروه من"}</button> : <button className="needsAvatar" onClick={openAvatar}><Palette />اول آواتار بساز</button>)}</header><div className="registeredGroups" data-pull-refresh-scroll>{tournament.registrations.map((registration) => { const avatar = data.gameAvatars.find((item) => registration.memberNames.includes(item.userName)); const avatarName = avatar?.userName ?? registration.memberNames[0] ?? registration.groupName; return <article key={registration.groupId}><PlayerAvatar avatar={avatar} name={avatarName} index={registration.groupId} size="medium" /><span><b>{registration.groupName}</b><small>{registration.memberNames.join("، ")}</small></span><strong>{fa.format(tournament.entryFee)}</strong></article>; })}{!tournament.registrations.length && <Empty text="هنوز گروهی ثبت‌نام نکرده است" />}</div>{data.current.isAdmin && <button className="primary tournamentAdminButton" disabled={tournament.registrations.length < 2} onClick={() => run.mutate(() => api.adminStartTournament({ userId: data.current.id, tournamentId: tournament.id }))}>ساخت برنامه دوره‌ای و شروع</button>}</div>}
        {tournament.status === "live" && <div className="liveTournament"><section className="tournamentStandings"><header><b>جدول دوره</b><span>هر برد ۳ امتیاز</span></header>{ranked.map((registration, index) => <article key={registration.groupId}><i>{fa.format(index + 1)}</i><span><b>{registration.groupName}</b><small>{fa.format(pointsFor(registration.groupId))} امتیاز</small></span></article>)}</section><section className="matchCenter">{liveMatch ? <><header><Radio /><span><b>مسابقه زنده</b><small>{liveMatch.homeGroupName} × {liveMatch.awayGroupName}</small></span></header><div className="teamDuel"><div><PlayerAvatar avatar={avatarForGroup(liveMatch.homeGroupId)} name={liveMatch.homeGroupName} index={liveMatch.homeGroupId} size="medium" /><b>{liveMatch.homeGroupName}</b></div><span>در برابر</span><div><PlayerAvatar avatar={avatarForGroup(liveMatch.awayGroupId)} name={liveMatch.awayGroupName} index={liveMatch.awayGroupId} size="medium" /><b>{liveMatch.awayGroupName}</b></div></div>{data.currentGroupId && (data.currentGroupId === liveMatch.homeGroupId || data.currentGroupId === liveMatch.awayGroupId) && <button className="primary" onClick={() => enterGame(tournament.gameType)}><Gamepad2 />ورود بازیکن به میز {tournament.gameType}</button>}{liveMatch.gameRoomId && <div className="tournamentWatch"><label>تیم مورد علاقه<select aria-label="تیم مورد علاقه در مسابقه تورنمنت" value={favoriteTeam} onChange={(e) => setFavoriteTeam(e.target.value as typeof favoriteTeam)}><option>تیم میزبان</option><option>تیم مهمان</option></select></label><button onClick={() => run.mutate(() => api.watchGame({ gameRoomId: liveMatch.gameRoomId ?? 0, userId: data.current.id, favoriteTeam }))}><Eye />تماشا</button><button onClick={() => run.mutate(() => api.placeBet({ gameRoomId: liveMatch.gameRoomId ?? 0, userId: data.current.id, favoriteTeam, amount: 10 }))}><CircleDollarSign />شرط ۱۰ سکه</button></div>}{data.current.isAdmin && <div className="matchResultButtons"><span>اعلام برنده مسابقه</span><button onClick={() => run.mutate(() => api.adminFinishTournamentMatch({ userId: data.current.id, matchId: liveMatch.id, winnerGroupId: liveMatch.homeGroupId }))}>{liveMatch.homeGroupName}</button><button onClick={() => run.mutate(() => api.adminFinishTournamentMatch({ userId: data.current.id, matchId: liveMatch.id, winnerGroupId: liveMatch.awayGroupId }))}>{liveMatch.awayGroupName}</button></div>}</> : nextMatch ? <><header><Gamepad2 /><span><b>مسابقه بعدی</b><small>{nextMatch.homeGroupName} × {nextMatch.awayGroupName}</small></span></header>{data.current.isAdmin ? <button className="primary" onClick={() => run.mutate(() => api.adminStartTournamentMatch({ userId: data.current.id, matchId: nextMatch.id }))}>شروع مسابقه و اتاق تماشاچی</button> : <p>منتظر شروع مسابقه توسط مدیر</p>}</> : <><Check /><p>همه مسابقات انجام شده‌اند.</p></>}</section>{data.current.isAdmin && allFinished && <div className="finishTournament"><label>قهرمان دوره<select aria-label="انتخاب قهرمان تورنمنت" value={championId || defaultChampion} onChange={(e) => setChampionId(Number(e.target.value))}>{ranked.map((registration) => <option key={registration.groupId} value={registration.groupId}>{registration.groupName} · {fa.format(pointsFor(registration.groupId))} امتیاز</option>)}</select></label><button className="primary" disabled={!championId && !defaultChampion} onClick={() => run.mutate(() => api.adminFinishTournament({ userId: data.current.id, tournamentId: tournament.id, championGroupId: championId || defaultChampion }))}><Trophy />پایان دوره و تقسیم جایزه</button></div>}</div>}
        {tournament.status === "finished" && <div className="finishedTournament"><div className="finalStandings" data-pull-refresh-scroll>{ranked.map((registration, index) => <article key={registration.groupId} className={registration.groupId === tournament.championGroupId ? "champion" : ""}><span>{fa.format(index + 1)}</span><b>{registration.groupName}</b><strong>{fa.format(pointsFor(registration.groupId))} امتیاز</strong></article>)}</div>{data.current.isAdmin && createForm}</div>}
      </div>
    </>}
  </div>;
}

function LeaderboardPage({ data, back }: { data: State; back: () => void }) {
  const groupRows = data.groupScores.slice(0, 4);
  const playerRows = data.playerScores.slice(0, 4);
  return <div className="page leaderboardPage">
    <div className="leaderboardHead"><button aria-label="بازگشت به بازی‌ها" onClick={back}><ChevronLeft /></button><PageTitle title="جدول امتیاز گروهی" subtitle={`${fa.format(data.scoreEventCount)} نتیجه ثبت‌شده روی سرور`} /><div className="leaderboardMark"><Trophy /></div></div>
    <section className="scoreSummary"><div><b>{fa.format(groupRows.length)}</b><span>گروه</span></div><div><b>{fa.format(playerRows.length)}</b><span>بازیکن</span></div><div><b>{fa.format(data.scoreEventCount)}</b><span>نتیجه قطعی</span></div></section>
    <div className="scoreColumns">
      <section className="scoreTable groupTable"><header><Trophy /><div><h2>رتبه گروه‌ها</h2><p>جمع امتیاز اعضا</p></div></header><div className="scoreRows">{groupRows.map((row, index) => <article key={row.id} className={index === 0 ? "leader" : ""}><span className="rank">{fa.format(index + 1)}</span><div className="scoreIdentity"><b>{row.name}{data.tournament?.status === "finished" && data.tournament.championGroupId === row.id ? <em className="weekChampion"><Trophy />قهرمان هفته</em> : null}</b><small>{row.memberNames.join("، ") || "بدون عضو"}</small></div><div className="scoreBreakdown"><strong>{fa.format(row.points)}</strong><small>بازی {fa.format(row.gamePoints)} · برد شرط {fa.format(row.betPoints)}</small></div><span className="record">{fa.format(row.wins)} برد / {fa.format(row.losses)} باخت</span></article>)}{!groupRows.length && <Empty text="گروهی برای جدول ثبت نشده" />}</div></section>
      <section className="scoreTable playerTable"><header><Medal /><div><h2>رتبه بازیکنان</h2><p>نتیجه بازی و شرط قطعی</p></div></header><div className="scoreRows">{playerRows.map((row, index) => <article key={row.id} className={row.id === data.current.id ? "currentPlayer" : ""}><span className="rank">{fa.format(index + 1)}</span><PlayerAvatar avatar={data.gameAvatars.find((avatar) => avatar.userId === row.id)} name={row.name} index={row.id} /><div className="scoreIdentity"><b>{row.name}</b><small>{row.groupName ?? "بدون گروه"}</small></div><div className="scoreBreakdown"><strong>{fa.format(row.points)}</strong><small>بازی {fa.format(row.gamePoints)} · برد شرط {fa.format(row.betPoints)}</small></div><span className="record">{fa.format(row.wins)} برد / {fa.format(row.losses)} باخت</span></article>)}</div></section>
    </div>
    <p className="scoreFootnote">امتیاز بازی پس از پایان دست و امتیاز شرط پس از ثبت نتیجه میز به‌روز می‌شود.</p>
  </div>;
}

function WalletPage({ data, run }: { data: State; run: Runner }) {
  const giftTaken = data.current.lastGiftDay === todayKey();
  const incoming = data.transactions.filter((item) => item.amount > 0).reduce((sum, item) => sum + item.amount, 0);
  const outgoing = Math.abs(data.transactions.filter((item) => item.amount < 0).reduce((sum, item) => sum + item.amount, 0));
  const [safeUnlocked, setSafeUnlocked] = useState(false);
  const [pin, setPin] = useState("");
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [changingPin, setChangingPin] = useState(false);
  const [safeMessage, setSafeMessage] = useState("");
  const [safeBusy, setSafeBusy] = useState(false);
  const lockedUntil = data.financialSafe.lockedUntil ? new Date(data.financialSafe.lockedUntil) : null;
  const locked = !!lockedUntil && lockedUntil.getTime() > Date.now();
  const unlock = async () => {
    if (!/^\d{4,6}$/.test(pin) || safeBusy) return;
    setSafeBusy(true);
    try {
      const result = await api.unlockFinancialSafe({ userId: data.current.id, pin });
      setSafeUnlocked(result.unlocked);
      setSafeMessage(result.message);
      if (result.unlocked) setPin("");
    } catch { setSafeMessage("ارتباط با گاوصندوق برقرار نشد"); }
    finally { setSafeBusy(false); }
  };
  const savePin = async () => {
    if (!/^\d{4,6}$/.test(newPin) || newPin !== confirmPin || safeBusy) return;
    setSafeBusy(true);
    try {
      const result = await run.mutateAsync(() => api.setFinancialSafePin({ userId: data.current.id, newPin, ...(data.financialSafe.configured ? { currentPin: pin } : {}) }));
      setSafeMessage(result.message ?? "پین ذخیره شد");
      if (result.message?.includes("پین گاوصندوق")) { setNewPin(""); setConfirmPin(""); setPin(""); setChangingPin(false); setSafeUnlocked(false); }
    } catch { setSafeMessage("پین ذخیره نشد"); }
    finally { setSafeBusy(false); }
  };
  return <div className="page walletPage"><PageTitle title="کیف پول" subtitle="سکه‌های آزمایشی؛ بدون پرداخت واقعی" /><div className="walletScroll" data-pull-refresh-scroll data-pull-refresh-page="wallet"><section className="balance"><span>موجودی قابل استفاده</span><strong>{fa.format(data.current.coins)}</strong><b>سکه</b></section>
    <button className="giftButton" disabled={giftTaken} onClick={() => run.mutate(() => api.claimDailyGift({ userId: data.current.id, day: todayKey() }))}><Gift /><div><b>{giftTaken ? "هدیه امروز دریافت شد" : "هدیه روزانه را بگیر"}</b><span>+{fa.format(data.settings.dailyGift)} سکه</span></div><ChevronLeft /></button>
    <section className={`financialSafe${safeUnlocked ? " unlocked" : ""}`} aria-label="گاوصندوق مالی"><header><Shield /><span><b>گاوصندوق مالی</b><small>{safeUnlocked ? "خلاصه دفترکل همین حساب" : data.financialSafe.configured ? "محافظت‌شده با پین سرور" : "یک پین ۴ تا ۶ رقمی بساز"}</small></span>{safeUnlocked && <button aria-label="قفل کردن گاوصندوق" onClick={() => { setSafeUnlocked(false); setChangingPin(false); setSafeMessage(""); }}><LockKeyhole />قفل</button>}</header>
      {!data.financialSafe.configured ? <div className="safePinForm"><label><span>پین تازه</span><input aria-label="پین تازه گاوصندوق" inputMode="numeric" autoComplete="new-password" type="password" minLength={4} maxLength={6} value={newPin} onChange={(event) => setNewPin(event.target.value.replace(/\D/g, ""))} /></label><label><span>تکرار پین</span><input aria-label="تکرار پین تازه گاوصندوق" inputMode="numeric" autoComplete="new-password" type="password" minLength={4} maxLength={6} value={confirmPin} onChange={(event) => setConfirmPin(event.target.value.replace(/\D/g, ""))} /></label><button disabled={safeBusy || !/^\d{4,6}$/.test(newPin) || newPin !== confirmPin} onClick={() => { void savePin(); }}><ShieldCheck />فعال‌کردن گاوصندوق</button></div> : !safeUnlocked ? <div className="safePinForm unlock"><label><span>پین گاوصندوق</span><input aria-label="پین گاوصندوق" inputMode="numeric" autoComplete="current-password" type="password" minLength={4} maxLength={6} disabled={locked} value={pin} onChange={(event) => setPin(event.target.value.replace(/\D/g, ""))} onKeyDown={(event) => { if (event.key === "Enter") void unlock(); }} /></label><button disabled={safeBusy || locked || !/^\d{4,6}$/.test(pin)} onClick={() => { void unlock(); }}><LockKeyhole />باز کردن</button>{locked && <p>قفل موقت تا {lockedUntil?.toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" })}</p>}</div> : changingPin ? <div className="safePinForm change"><label><span>پین فعلی</span><input aria-label="پین فعلی گاوصندوق" inputMode="numeric" type="password" maxLength={6} value={pin} onChange={(event) => setPin(event.target.value.replace(/\D/g, ""))} /></label><label><span>پین تازه</span><input aria-label="پین تازه گاوصندوق" inputMode="numeric" type="password" maxLength={6} value={newPin} onChange={(event) => setNewPin(event.target.value.replace(/\D/g, ""))} /></label><label><span>تکرار پین تازه</span><input aria-label="تکرار پین تازه گاوصندوق" inputMode="numeric" type="password" maxLength={6} value={confirmPin} onChange={(event) => setConfirmPin(event.target.value.replace(/\D/g, ""))} /></label><button disabled={safeBusy || !/^\d{4,6}$/.test(pin) || !/^\d{4,6}$/.test(newPin) || newPin !== confirmPin} onClick={() => { void savePin(); }}>ذخیره پین تازه</button><button onClick={() => { setChangingPin(false); setPin(""); setNewPin(""); setConfirmPin(""); }}>انصراف</button></div> : <><div className="safeMetrics"><span><small>دریافتی اخیر</small><b className="positive">+{fa.format(incoming)}</b></span><span><small>خرج اخیر</small><b className="negative">−{fa.format(outgoing)}</b></span><span><small>تعداد گردش</small><b>{fa.format(data.transactions.length)}</b></span></div><button className="changePinButton" onClick={() => setChangingPin(true)}>تغییر پین امن</button></>}
      {safeMessage && <p className="safeMessage" role="status">{safeMessage}</p>}
    </section>
    <div className="coinPackages">{([100, 250, 600] as const).map((amount) => <button key={amount} onClick={() => run.mutate(() => api.buyCoins({ userId: data.current.id, amount }))}><Coins /><b>{fa.format(amount)}</b><span>افزودن آزمایشی</span></button>)}</div>
    <section className="transactions"><h3>دفترکل آخرین گردش‌ها</h3>{data.transactions.slice(0, 10).map((t) => <div key={t.id}><span>{t.note}</span><b className={t.amount >= 0 ? "positive" : "negative"}>{t.amount >= 0 ? "+" : ""}{fa.format(t.amount)}</b></div>)}{!data.transactions.length && <Empty text="تراکنشی ثبت نشده" />}</section></div>
  </div>;
}

function UserSettingsPage({ themeMode, systemPrefersDark, changeTheme }: { themeMode: ThemeMode; systemPrefersDark: boolean; changeTheme: (mode: ThemeMode) => void }) {
  return <div className="page userSettingsPage">
    <PageTitle title="تنظیمات" subtitle="ترجیحات برنامه روی این دستگاه" />
    <section className="themePicker standalone" aria-label="انتخاب پوسته">
      <header><Palette /><span><b>پوسته برنامه</b><small>{themeMode === "auto" ? `خودکار مطابق تنظیم دستگاه · اکنون ${systemPrefersDark ? "شب" : "روز"}` : "روز، شب، خودکار، نئونی یا شیشه‌ای"}</small></span></header>
      <div>
        <button className={themeMode === "neon" ? "selected" : ""} aria-pressed={themeMode === "neon"} onClick={() => changeTheme("neon")}><Zap /><span>شب نئونی</span></button>
        <button className={themeMode === "glass" ? "selected" : ""} aria-pressed={themeMode === "glass"} onClick={() => changeTheme("glass")}><Sparkles /><span>شیشه‌ای</span></button>
        <button className={themeMode === "day" ? "selected" : ""} aria-pressed={themeMode === "day"} onClick={() => changeTheme("day")}><Sun /><span>روز</span></button>
        <button className={themeMode === "night" ? "selected" : ""} aria-pressed={themeMode === "night"} onClick={() => changeTheme("night")}><Moon /><span>شب</span></button>
        <button className={themeMode === "auto" ? "selected" : ""} aria-pressed={themeMode === "auto"} aria-label={`پوسته خودکار، مطابق تنظیم دستگاه، اکنون ${systemPrefersDark ? "شب" : "روز"}`} onClick={() => changeTheme("auto")}><span className="autoThemeIcons"><Sun /><Moon /></span><span>خودکار · دستگاه</span></button>
      </div>
    </section>
    <section className="settingsNote"><Bell /><p><b>اعلان‌ها</b><span>اعلان فشاری در نسخه تست وب فعال نیست؛ رویدادها داخل خود برنامه نمایش داده می‌شوند.</span></p></section>
  </div>;
}

function GameStatsPage({ data }: { data: State }) {
  const me = data.playerScores.find((p) => p.id === data.current.id);
  const rankIndex = data.playerScores.findIndex((p) => p.id === data.current.id);
  const coinIn = data.transactions.filter((t) => t.amount > 0).reduce((s, t) => s + t.amount, 0);
  const coinOut = data.transactions.filter((t) => t.amount < 0).reduce((s, t) => s + t.amount, 0);
  const hosted = data.games.filter((g) => g.hostId === data.current.id);
  const tiles = [
    { icon: <Gamepad2 />, value: fa.format(hosted.length), label: "میز میزبانی‌شده" },
    { icon: <Trophy />, value: `${fa.format(me?.wins ?? 0)} / ${fa.format(me?.losses ?? 0)}`, label: "برد / باخت ثبت‌شده" },
    { icon: <Coins />, value: `+${fa.format(coinIn)}`, label: "سکه دریافتی" },
    { icon: <Coins />, value: fa.format(coinOut), label: "سکه خرج‌شده" },
    { icon: <Zap />, value: fa.format(data.current.xp), label: "امتیاز تجربه" },
    { icon: <Medal />, value: me?.groupName ?? "بدون گروه", label: "گروه امتیازی" },
  ];
  return <div className="page gameStatsPage">
    <PageTitle title="آمار بازی" subtitle={`عملکرد ${data.current.name} از داده‌های سرور`} />
    <div className="statRibbon"><div><b>{fa.format(data.current.wins)}</b><span>برد</span></div><div><b>{fa.format(me?.points ?? 0)}</b><span>امتیاز جدول</span></div><div><b>{rankIndex >= 0 ? fa.format(rankIndex + 1) : "—"}</b><span>رتبه بازیکنان</span></div></div>
    <section className="statsGrid">{tiles.map((tile) => <div key={tile.label}>{tile.icon}<b>{tile.value}</b><span>{tile.label}</span></div>)}</section>
    <p className="scoreFootnote">آمار از نتایج قطعی سرور (بازی، شرط و تورنمنت) محاسبه می‌شود.</p>
  </div>;
}

function StorePage({ data, run }: { data: State; run: Runner }) {
  return <div className="page storePage">
    <PageTitle title="فروشگاه" subtitle="بسته‌های سکه نسخه تست" />
    <div className="simulatedBadge"><ShieldAlert size={16} /><span><b>پرداخت شبیه‌سازی‌شده (نسخه تست)</b><small>پرداخت واقعی انجام نمی‌شود؛ سکه مستقیم از سرور آزمایشی اضافه می‌شود.</small></span></div>
    <section className="balance"><span>موجودی فعلی</span><strong>{fa.format(data.current.coins)}</strong><b>سکه</b></section>
    <div className="coinPackages">{([100, 250, 600] as const).map((amount) => <button key={amount} onClick={() => run.mutate(() => api.buyCoins({ userId: data.current.id, amount }))}><Coins /><b>{fa.format(amount)}</b><span>افزودن آزمایشی</span></button>)}</div>
  </div>;
}

function TwoFactorPage({ data, run }: { data: State; run: Runner }) {
  const enabled = data.current.twoFactorEnabled;
  return <div className="page twoFactorPage">
    <PageTitle title="تأیید دومرحله‌ای" subtitle="لایه امنیتی ورود به حساب" />
    <section className="twoFactorCard">
      <div><ShieldCheck /><span><b>{enabled ? "فعال است" : "غیرفعال است"}</b><small>وضعیت روی سرور ذخیره می‌شود</small></span></div>
      <button role="switch" aria-checked={enabled} aria-label="تغییر وضعیت تأیید دومرحله‌ای" className={enabled ? "toggle on" : "toggle"} onClick={() => run.mutate(() => api.setTwoFactor({ userId: data.current.id, enabled: !enabled }))}><i /></button>
    </section>
    <section className="twoFactorNote"><ShieldAlert /><p><b>نسخه تست: پیامک واقعی ارسال نمی‌شود.</b><span>در این بیلد فقط پرچم فعال‌بودن روی سرور ثبت می‌شود؛ اتصال درگاه پیامک و ارسال کد واقعی برای فاز حرفه‌ای است.</span></p></section>
  </div>;
}

function ActivityPage({ data }: { data: State }) {
  const iconFor = (kind: string) => kind === "message" ? <MessageCircle /> : kind === "transaction" ? <Coins /> : kind === "game" ? <Gamepad2 /> : <ShieldCheck />;
  return <div className="page activityPage">
    <PageTitle title="آخرین فعالیت" subtitle="تازه‌ترین رویدادهای این حساب روی سرور" />
    <div className="activityList" data-pull-refresh-scroll>{data.recentActivity.map((item, index) => <article key={`${item.kind}-${item.at}-${index}`}>{iconFor(item.kind)}<span><b>{item.label}</b>{item.detail && <small>{item.detail}</small>}</span><time>{new Date(item.at).toLocaleString("fa-IR")}</time></article>)}{!data.recentActivity.length && <Empty text="هنوز فعالیتی ثبت نشده است" />}</div>
  </div>;
}

function DeleteAccountPage({ data, onDeleted }: { data: State; onDeleted: () => void }) {
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const trimmed = name.trim();
  const matches = trimmed === data.current.name;
  const submit = async () => {
    if (!matches || busy) return;
    setBusy(true); setError("");
    try {
      const result = await api.deleteAccount({ userId: data.current.id, confirmName: trimmed });
      if (result.message && !result.message.includes("برای همیشه حذف شد")) setError(result.message);
      else onDeleted();
    } catch { setError("حذف انجام نشد؛ اتصال سرور را بررسی کنید."); }
    finally { setBusy(false); }
  };
  return <div className="page deleteAccountPage">
    <PageTitle title="حذف حساب کاربری" subtitle="این عمل برگشت‌پذیر نیست" />
    <section className="deleteWarning"><Trash2 /><p><b>همه داده‌های «{data.current.name}» برای همیشه از سرور حذف می‌شود</b><span>پیام‌ها، سکه‌ها، آمار بازی، آواتار و عضویت‌ها. برای تأیید، نام حساب را دقیق بنویس.</span></p></section>
    <label className="deleteConfirmField"><span>تأیید با نوشتن نام حساب</span><input value={name} onChange={(e) => setName(e.target.value)} placeholder={data.current.name} dir="rtl" /></label>
    {error && <p role="alert" className="gameError">{error}</p>}
    <button className="primary dangerButton" disabled={!matches || busy} onClick={() => { void submit(); }}>{busy ? "در حال حذف…" : "حذف دائمی حساب"}</button>
  </div>;
}

function LoginGate({ onAuthenticated }: { onAuthenticated: (id: number) => void }) {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [maritalStatus, setMaritalStatus] = useState<"" | "مجرد" | "متأهل">("");
  const [interests, setInterests] = useState<Interest[]>([]);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (busy) return;
    setBusy(true);
    setMessage("");
    try {
      if (mode === "login") {
        const result = await api.loginPhone({ phone: phone.trim(), code: code as "1234" });
        if (!result.ok || result.userId === null) { setMessage(result.message); return; }
        onAuthenticated(result.userId);
        return;
      }
      if (!maritalStatus) { setMessage("وضعیت تأهل را انتخاب کنید"); return; }
      const result = await api.verifyPhone({ name: name.trim(), phone: phone.trim(), code: code as "1234", maritalStatus, interests });
      onAuthenticated(result.userId);
    } catch {
      setMessage("اطلاعات ورود معتبر نیست؛ شماره و کد را دوباره بررسی کنید.");
    } finally {
      setBusy(false);
    }
  };

  return <div className="page loginGatePage">
    <section className="authPanel" aria-label="ورود و ثبت‌نام">
      <header className="loginGateCard"><LockKeyhole /><h1>ورود به حساب</h1><p>با شماره موبایل و کد تأیید وارد شوید یا حساب تازه بسازید.</p></header>
      <div className="authTabs" role="tablist" aria-label="انتخاب ورود یا ثبت‌نام">
        <button type="button" role="tab" aria-selected={mode === "login"} className={mode === "login" ? "active" : ""} onClick={() => { setMode("login"); setMessage(""); }}>ورود</button>
        <button type="button" role="tab" aria-selected={mode === "signup"} className={mode === "signup" ? "active" : ""} onClick={() => { setMode("signup"); setMessage(""); }}>ثبت‌نام</button>
      </div>
      <form className="authForm" onSubmit={(event) => { void submit(event); }}>
        {mode === "signup" && <><label><span>نام</span><input value={name} onChange={(event) => setName(event.target.value)} minLength={2} maxLength={40} autoComplete="name" required /></label><label><span>وضعیت تأهل</span><select value={maritalStatus} onChange={(event) => setMaritalStatus(event.target.value as "" | "مجرد" | "متأهل")} required><option value="" disabled>انتخاب کنید</option><option value="مجرد">مجرد</option><option value="متأهل">متأهل</option></select></label></>}
        <label><span>شماره موبایل</span><input type="tel" inputMode="tel" value={phone} onChange={(event) => setPhone(event.target.value)} minLength={7} autoComplete="tel" required /></label>
        <label><span>کد تأیید</span><input inputMode="numeric" value={code} onChange={(event) => setCode(event.target.value)} pattern="1234" autoComplete="one-time-code" required /></label>
        {mode === "signup" && <InterestPicker legend="علاقه‌مندی‌ها" selected={interests} onChange={setInterests} />}
        <p className="verificationHint">در این نسخه، کد تأیید ۱۲۳۴ است.</p>
        {message && <p className="authMessage" role="alert">{message}</p>}
        <button className="primary" type="submit" disabled={busy}>{busy ? "در حال بررسی…" : mode === "login" ? "ورود به حساب" : "ساخت حساب و ورود"}</button>
      </form>
    </section>
  </div>;
}

function ProfileStories({ data, run }: { data: State; run: Runner }) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [caption, setCaption] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [openStoryId, setOpenStoryId] = useState<number | null>(null);
  const activeStory = data.stories.find((story) => story.id === openStoryId) ?? null;
  const ownerStories = activeStory ? data.stories.filter((story) => story.userId === activeStory.userId).sort((a, b) => a.createdAt.localeCompare(b.createdAt)) : [];
  const activeIndex = activeStory ? ownerStories.findIndex((story) => story.id === activeStory.id) : -1;
  const storyOwners = data.users.filter((user) => data.stories.some((story) => story.userId === user.id));
  const myStories = data.stories.filter((story) => story.userId === data.current.id);

  useEffect(() => {
    if (!activeStory) return;
    void api.viewProfileStory({ storyId: activeStory.id, viewerId: data.current.id });
    const timer = window.setTimeout(() => {
      const next = ownerStories[activeIndex + 1];
      setOpenStoryId(next?.id ?? null);
    }, 7000);
    return () => window.clearTimeout(timer);
  }, [activeIndex, activeStory?.id, data.current.id]);

  const upload = () => {
    if (!file) { fileRef.current?.click(); return; }
    const allowed = ["image/jpeg", "image/png", "image/webp", "video/mp4", "video/webm"] as const;
    if (!allowed.includes(file.type as typeof allowed[number])) { run.mutate(() => Promise.resolve({ ok: true, message: "فرمت فایل برای استوری پشتیبانی نمی‌شود" })); return; }
    run.mutate(async () => {
      const encoded = await fileToBase64(file);
      const result = await api.createProfileStory({ userId: data.current.id, caption: caption.trim(), mediaType: file.type.startsWith("video/") ? "video" : "image", dataBase64: encoded.dataBase64, mimeType: file.type as typeof allowed[number], filename: file.name });
      setFile(null); setCaption("");
      if (fileRef.current) fileRef.current.value = "";
      return result;
    });
  };

  const openOwnerStories = (userId: number) => {
    const ordered = data.stories.filter((story) => story.userId === userId).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    const firstUnseen = ordered.find((story) => !story.viewedByMe) ?? ordered[0];
    setOpenStoryId(firstUnseen?.id ?? null);
  };

  return <>
    <section className="storyShelf" aria-label="استوری‌های پروفایل">
      <header><div><b>استوری‌ها</b><small>عکس یا ویدیو · نمایش برای ۲۴ ساعت</small></div><span>{fa.format(myStories.length)} استوری من</span></header>
      <div className="storyRail">
        <button className="storyOwner addStory" onClick={() => fileRef.current?.click()} aria-label="افزودن استوری تازه"><span className="storyRing"><Avatar name={data.current.name} index={data.current.id} /><i><Plus /></i></span><small>استوری من</small></button>
        {storyOwners.map((owner) => {
          const ownerRows = data.stories.filter((story) => story.userId === owner.id);
          const allViewed = ownerRows.every((story) => story.viewedByMe);
          return <button key={owner.id} className={`storyOwner ${allViewed ? "viewed" : ""}`} onClick={() => openOwnerStories(owner.id)} aria-label={`دیدن استوری‌های ${owner.name}`}><span className="storyRing"><Avatar name={owner.name} index={owner.id} /></span><small>{owner.id === data.current.id ? "استوری من" : owner.name}</small></button>;
        })}
      </div>
      <input ref={fileRef} className="hiddenInput" type="file" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm" onChange={(event) => setFile(event.target.files?.[0] ?? null)} />
      {file && <div className="storyComposer"><div><Image /><span><b>{file.name}</b><small>حداکثر ۸ مگابایت</small></span></div><textarea aria-label="متن اختیاری استوری" value={caption} maxLength={160} onChange={(event) => setCaption(event.target.value)} placeholder="متن کوتاه اختیاری…" /><div><button onClick={() => { setFile(null); setCaption(""); if (fileRef.current) fileRef.current.value = ""; }}>انصراف</button><button className="primary" onClick={upload}>انتشار استوری</button></div></div>}
    </section>
    {activeStory && <div className="storyViewer" role="dialog" aria-modal="true" aria-label={`استوری ${activeStory.userName}`}>
      <div className="storyProgress" aria-hidden="true">{ownerStories.map((story, index) => <i key={story.id} className={index < activeIndex ? "done" : index === activeIndex ? "playing" : ""} />)}</div>
      <header><Avatar name={activeStory.userName} index={activeStory.userId} /><div><b>{activeStory.userName}</b><small>{new Date(activeStory.createdAt).toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" })} · {fa.format(activeStory.viewCount)} بازدید</small></div>{activeStory.isMine && <button aria-label="حذف این استوری" onClick={() => { setOpenStoryId(null); run.mutate(() => api.deleteProfileStory({ storyId: activeStory.id, userId: data.current.id })); }}><Trash2 /></button>}<button aria-label="بستن استوری" onClick={() => setOpenStoryId(null)}><X /></button></header>
      <div className="storyMedia">{activeStory.mediaType === "image" ? <img src={activeStory.mediaUrl} alt={`استوری تصویری ${activeStory.userName}`} /> : <video src={activeStory.mediaUrl} autoPlay muted playsInline controls aria-label={`استوری ویدیویی ${activeStory.userName}`} />}</div>
      {activeStory.caption && <p>{activeStory.caption}</p>}
      <button className="storyPrev" aria-label="استوری قبلی" disabled={activeIndex <= 0} onClick={() => setOpenStoryId(ownerStories[activeIndex - 1]?.id ?? null)} />
      <button className="storyNext" aria-label="استوری بعدی" onClick={() => setOpenStoryId(ownerStories[activeIndex + 1]?.id ?? null)} />
    </div>}
  </>;
}

function AmbassadorCard({ data, run }: { data: State; run: Runner }) {
  const ambassador = data.ambassador;
  const [code, setCode] = useState("");
  const [copyStatus, setCopyStatus] = useState("");
  if (!ambassador) return null;
  const copyCode = async () => {
    try {
      await navigator.clipboard.writeText(ambassador.inviteCode);
      setCopyStatus("کد دعوت کپی شد");
    } catch {
      setCopyStatus(`کد شما: ${ambassador.inviteCode}`);
    }
    window.setTimeout(() => setCopyStatus(""), 2400);
  };
  return <section className="ambassadorCard" aria-label="کارت دعوت سفیران">
    <header><Crown /><div><b>کارت دعوت سفیران</b><small>برای هر دوست تازه، ۱۰۰ سکه پاداش</small></div><span>{fa.format(ambassador.referralCount)} دعوت</span></header>
    <div className="ambassadorCode"><code>{ambassador.inviteCode}</code><button aria-label="کپی کد دعوت سفیر" onClick={() => { void copyCode(); }}><Copy />کپی</button></div>
    <div className="ambassadorStats"><span><small>دوست‌های دعوت‌شده</small><b>{fa.format(ambassador.referralCount)}</b></span><span><small>پاداش دریافت‌شده</small><b>{fa.format(ambassador.rewardEarned)} سکه</b></span></div>
    {!ambassador.hasRedeemedCode && <div className="redeemAmbassador"><label><span>کد دعوت دوستت را داری؟</span><input aria-label="کد دعوت سفیر دوست" value={code} onChange={(event) => setCode(event.target.value.toUpperCase())} maxLength={24} placeholder="HS-…" /></label><button disabled={code.trim().length < 6} onClick={() => { run.mutate(() => api.redeemAmbassadorCode({ userId: data.current.id, code: code.trim() })); setCode(""); }}>ثبت کد</button></div>}
    {ambassador.hasRedeemedCode && <p className="ambassadorRedeemed"><Check />کد دعوت این حساب ثبت شده است</p>}
    {copyStatus && <p className="ambassadorCopyStatus" role="status">{copyStatus}</p>}
  </section>;
}

function ProfilePage({ data, run, openEdit, openAccess }: { data: State; run: Runner; openEdit: () => void; openAccess: (page: "admin" | "management") => void }) {
  const role = data.current.accessRole;
  return <div className="page profilePage" data-pull-refresh-scroll data-pull-refresh-page="profile">
    <PageTitle title="حساب من" subtitle="پروفایل و تنظیمات شخصی" />
    <section className="profileHero"><Avatar large name={data.current.name} index={data.current.id} /><div><h2>{data.current.name}</h2><p>{data.current.city} · {data.current.age} سال · {data.current.gender}</p><span className="maritalBadge">وضعیت تأهل: {data.current.maritalStatus}</span><span>{role === "management" ? "سطح مدیریت کل" : role === "admin" ? "سطح ادمین" : "سطح کاربر عادی"}</span></div><button onClick={openEdit}>ویرایش</button></section>
    {role === "user" && <AmbassadorCard data={data} run={run} />}
    <ProfileStories data={data} run={run} />
    <blockquote className="bioQuote">{data.current.bio || "هنوز معرفی کوتاهی ثبت نشده است."}</blockquote>
    {(data.detectiveSolved || data.quickDuelWon) && <section className="honorBadges" aria-label="نشان‌های افتخار"><header><Medal /><b>نشان‌های افتخار</b></header><div>{data.quickDuelWon && <span><Zap />فاتح دوئل</span>}{data.detectiveSolved && <span><Shield />کارآگاه زبده</span>}</div></section>}
    <section className="profileInterests" aria-label="علاقه‌مندی‌های من"><header><Heart /><div><b>علاقه‌مندی‌ها</b><small>{data.current.interests.length ? `${fa.format(data.current.interests.length)} مورد انتخاب شده` : "هنوز موردی انتخاب نشده"}</small></div><button onClick={openEdit}>ویرایش</button></header>{data.current.interests.length ? <div className="interestChips displayOnly">{data.current.interests.map((interest) => <span key={interest}>{interest}</span>)}</div> : <p>برای پیدا کردن گفتگوها و آدم‌های هم‌سلیقه، علاقه‌مندی‌هایت را انتخاب کن.</p>}</section>
    <div className="statRibbon"><div><b>{fa.format(data.current.wins)}</b><span>برد</span></div><div><b>{fa.format(data.current.xp)}</b><span>امتیاز</span></div><div><b>{data.current.accessRole === "admin" ? "محدود" : fa.format(data.current.coins)}</b><span>{data.current.accessRole === "admin" ? "دسترسی مالی" : "سکه"}</span></div></div>
    {role === "admin" && <button className="adminEntry" onClick={() => openAccess("admin")}><ShieldCheck /><span><b>پنل ادمین</b><small>نظارت گروه، کانال و گزارش‌ها</small></span><ChevronLeft /></button>}
    {role === "management" && <button className="adminEntry" onClick={() => openAccess("management")}><ShieldCheck /><span><b>پنل مدیریت کل</b><small>دسترسی سراسری، تنظیمات و سابقه حسابرسی</small></span><ChevronLeft /></button>}
  </div>;
}

function ModeratorPage({ data, unlocked, run }: { data: State; unlocked: boolean; run: Runner }) {
  if (data.current.accessRole !== "admin") return <div className="page adminGate"><ShieldAlert /><h2>پنل ادمین</h2><p>این بخش فقط پس از ورود با حساب دارای سطح ادمین در دسترس است.</p></div>;
  if (!unlocked) return <div className="page adminGate"><ShieldCheck /><h2>در حال بررسی دسترسی ادمین…</h2><p>سطح دسترسی سمت سرور در حال تأیید است.</p></div>;
  const publicSpaces = data.conversations.filter((conversation) => conversation.kind !== "private");
  const openReports = data.reports.filter((report) => report.status === "open");
  return <div className="page adminPage" data-pull-refresh-scroll data-pull-refresh-page="admin-panel"><div className="adminMast"><div><span>سطح دسترسی: ادمین</span><h2>نظارت گروه و کانال</h2><p>پیام‌های خصوصی و محرمانه، کیف پول کاربران، کدهای تأیید و رازهای دومرحله‌ای در این سطح نمایش داده نمی‌شوند و تلاش نامجاز در ممیزی مدیریت ثبت می‌شود.</p></div><ShieldCheck size={34} /></div><div className="adminStats"><div><b>{fa.format(publicSpaces.length)}</b><span>فضای عمومی</span></div><div><b>{fa.format(openReports.length)}</b><span>گزارش باز</span></div><div><b>{fa.format(data.messages.length)}</b><span>پیام قابل مشاهده</span></div></div><section className="adminSection"><div className="sectionHead"><h3><Flag />گزارش‌های کاربران</h3><span>{fa.format(openReports.length)} باز</span></div><div className="adminList">{data.reports.map((report) => <article key={report.id}><div><b>گزارش #{fa.format(report.id)}</b><small>{report.reporterName} · {report.subject} · {report.status === "open" ? "باز" : "بسته"}</small></div>{report.status === "open" && <button onClick={() => run.mutate(() => api.moderatorAction({ userId: data.current.id, action: "close_report", targetId: report.id }))}>بستن</button>}</article>)}{!data.reports.length && <Empty text="گزارشی ثبت نشده است" />}</div></section><section className="adminSection"><div className="sectionHead"><h3><Users />گروه‌ها و کانال‌ها</h3><span>بدون دسترسی به خصوصی</span></div><div className="adminList">{publicSpaces.map((conversation) => <article key={conversation.id}><div><b>{conversation.name}</b><small>{conversation.kind === "channel" ? "کانال" : "گروه"} · {conversation.isActive ? "فعال" : "تعلیق"}</small></div><button onClick={() => run.mutate(() => api.moderatorAction({ userId: data.current.id, action: "toggle_public_chat", targetId: conversation.id }))}>{conversation.isActive ? "تعلیق" : "فعال‌سازی"}</button></article>)}</div></section></div>;
}

function AdminPage({ data, unlocked, run, openSettings }: { data: State; unlocked: boolean; run: Runner; openSettings: () => void }) {
  const [notice, setNotice] = useState("");
  const [tab, setTab] = useState<"chats" | "users" | "reports" | "audit">("chats");
  const [selectedConv, setSelectedConv] = useState<number | null>(null);
  const [monitorFilter, setMonitorFilter] = useState<"all" | "private" | "secret">("private");
  const [search, setSearch] = useState("");
  if (data.current.accessRole !== "management") return <div className="page adminGate"><ShieldCheck /><h2>پنل مدیریت کل</h2><p>این بخش فقط پس از ورود با حساب دارای سطح مدیریت کل در دسترس است.</p></div>;
  if (!unlocked) return <div className="page adminGate"><ShieldCheck /><h2>در حال فعال‌سازی پنل مدیریت…</h2><p>سطح دسترسی مدیریت و ثبت ورود در سابقه امنیتی در حال بررسی است.</p></div>;
  const members = data.users.filter((u) => !u.isAdmin);
  const normalizedSearch = search.trim().toLocaleLowerCase("fa");
  const monitored = data.conversations.filter((conversation) => {
    const matchesType = monitorFilter === "all" || (monitorFilter === "private" && conversation.kind === "private") || (monitorFilter === "secret" && conversation.kind === "private" && conversation.confidential);
    const matchesSearch = !normalizedSearch || conversation.name.toLocaleLowerCase("fa").includes(normalizedSearch) || data.messages.some((message) => message.conversationId === conversation.id && message.content.toLocaleLowerCase("fa").includes(normalizedSearch));
    return matchesType && matchesSearch;
  });
  const selected = data.conversations.find((conversation) => conversation.id === selectedConv) ?? null;
  const selectedMessages = selected ? data.messages.filter((message) => message.conversationId === selected.id).slice(-20) : [];
  const openReview = (conversationId: number) => {
    setSelectedConv(conversationId);
    run.mutate(() => api.adminModerate({ userId: data.current.id, action: "view_chat", targetId: conversationId }));
  };
  return <div className="page adminPage" data-pull-refresh-scroll data-pull-refresh-page="management-panel">
    <div className="adminTitleRow"><PageTitle title="مرکز نظارت مدیریت" subtitle="دسترسی سراسری، اقدام مستقیم و سابقه حسابرسی" /><button aria-label="تنظیمات عمومی" onClick={openSettings}><Settings /></button></div>
    <div className="oversightBanner"><Eye /><p><b>نظارت کامل فعال است</b><span>مدیر می‌تواند همه گفتگوها، از جمله چت‌های محرمانه، را بازبینی کند. هر مشاهده و اقدام در سابقه مدیریت ثبت می‌شود.</span></p></div>
    <div className="adminMetrics"><span><b>{fa.format(members.length)}</b>کاربر</span><span><b>{fa.format(data.conversations.length)}</b>گفتگو</span><span><b>{fa.format(data.messages.length)}</b>پیام قابل بررسی</span><span><b>{fa.format(data.reports.filter((r) => r.status === "open").length)}</b>گزارش باز</span></div>
    <div className="adminTabs" role="tablist" aria-label="بخش‌های مدیریت"><button className={tab === "chats" ? "on" : ""} onClick={() => setTab("chats")}><Eye />نظارت</button><button className={tab === "users" ? "on" : ""} onClick={() => setTab("users")}><Users />کاربران</button><button className={tab === "reports" ? "on" : ""} onClick={() => setTab("reports")}><Flag />گزارش‌ها</button><button className={tab === "audit" ? "on" : ""} onClick={() => setTab("audit")}><History />سابقه</button></div>
    <section className="adminWorkspace">
      {tab === "chats" && (!selected ? <><div className="monitorTools"><div className="monitorFilters" role="group" aria-label="فیلتر گفتگوهای تحت نظارت"><button className={monitorFilter === "private" ? "on" : ""} aria-pressed={monitorFilter === "private"} onClick={() => setMonitorFilter("private")}>خصوصی</button><button className={monitorFilter === "secret" ? "on" : ""} aria-pressed={monitorFilter === "secret"} onClick={() => setMonitorFilter("secret")}><LockKeyhole />محرمانه</button><button className={monitorFilter === "all" ? "on" : ""} aria-pressed={monitorFilter === "all"} onClick={() => setMonitorFilter("all")}>همه</button></div><label className="adminSearch"><span>جستجو در نام یا متن گفتگو</span><input aria-label="جستجو در گفتگوهای تحت نظارت" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="نام گفتگو یا عبارت پیام…" /></label></div><div className="monitoredList" data-pull-refresh-scroll data-pull-refresh-page="management-monitored-chats">{monitored.map((conversation) => { const count = data.messages.filter((message) => message.conversationId === conversation.id).length; const conversationLabel = conversation.kind === "private" ? (conversation.confidential ? "محرمانه" : "خصوصی") : conversation.kind === "channel" ? "کانال" : "گروه"; return <article key={conversation.id}><div className="monitorIcon">{conversation.kind === "private" ? <LockKeyhole /> : conversation.kind === "channel" ? <Radio /> : <Users />}</div><span><b>{conversation.name}</b><small>{conversationLabel} · {fa.format(count)} پیام · {conversation.isActive ? "فعال" : "تعلیق‌شده"}</small></span><button onClick={() => openReview(conversation.id)}><Eye />بازبینی</button></article>; })}{!monitored.length && <Empty text="گفتگویی با این فیلتر پیدا نشد" />}</div></> : <div className="reviewPane"><header><button aria-label="بازگشت به فهرست گفتگوها" onClick={() => setSelectedConv(null)}><ChevronLeft /></button><div><b>{selected.name}</b><span>{selected.kind === "private" ? (selected.confidential ? "چت محرمانه" : "چت خصوصی") : selected.kind === "channel" ? "کانال" : "گروه"} · {selected.isActive ? "فعال" : "تعلیق‌شده"}</span></div><button className={selected.isActive ? "suspend" : "restore"} onClick={() => run.mutate(() => api.adminModerate({ userId: data.current.id, action: "toggle_chat", targetId: selected.id }))}>{selected.isActive ? <Ban /> : <Check />}{selected.isActive ? "تعلیق" : "بازگشایی"}</button></header><div className="reviewMessages" data-pull-refresh-scroll data-pull-refresh-page="management-chat-review">{selectedMessages.map((message) => <article key={message.id}><div><b>{message.senderName}</b><small>{new Date(message.createdAt).toLocaleString("fa-IR")}</small></div>{message.type === "text" || message.type === "system" ? <p>{message.content}</p> : message.type === "image" ? <img src={message.content} alt="رسانه تحت بازبینی مدیریت" /> : message.type === "video" ? <video src={message.content} controls aria-label="فیلم تحت بازبینی مدیریت" /> : <audio src={message.content} controls aria-label="صدای تحت بازبینی مدیریت" />}<button aria-label={`حذف پیام ${message.id}`} onClick={() => run.mutate(() => api.adminModerate({ userId: data.current.id, action: "delete_message", targetId: message.id }))}><Trash2 />حذف</button></article>)}{!selectedMessages.length && <Empty text="پیامی برای بازبینی وجود ندارد" />}</div></div>)}
      {tab === "users" && <div className="adminUsers" data-pull-refresh-scroll data-pull-refresh-page="management-users"><div className="noticeComposer"><input aria-label="متن اطلاعیه مدیر" value={notice} onChange={(e) => setNotice(e.target.value)} placeholder="اطلاعیه سراسری تازه…" /><button aria-label="انتشار اطلاعیه" onClick={() => { if (!notice.trim()) return; run.mutate(() => api.adminUpdate({ userId: data.current.id, kind: "notice", title: "اطلاعیه مدیریت", body: notice.trim() })); setNotice(""); }}><Send /></button></div>{members.map((user) => <article key={user.id}><Avatar name={user.name} index={user.id} /><span><b>{user.name}</b><small>{user.isActive ? "فعال" : "مسدود"} · {fa.format(user.coins)} سکه</small></span><button onClick={() => run.mutate(() => api.adminUpdate({ userId: data.current.id, kind: "toggle_user", targetId: user.id }))}>{user.isActive ? "مسدود کردن" : "فعال کردن"}</button></article>)}</div>}
      {tab === "reports" && <div className="adminReports" data-pull-refresh-scroll data-pull-refresh-page="management-reports">{data.reports.map((report) => <article key={report.id}><Flag /><span><b>{report.subject}</b><small>گزارش‌دهنده: {report.reporterName} · {report.status === "open" ? "باز" : "بسته"}</small></span>{report.status === "open" && <button onClick={() => run.mutate(() => api.adminUpdate({ userId: data.current.id, kind: "close_report", targetId: report.id }))}><Check />بستن</button>}</article>)}{!data.reports.length && <Empty text="گزارشی ثبت نشده است" />}</div>}
      {tab === "audit" && <div className="auditList" data-pull-refresh-scroll data-pull-refresh-page="management-audit">{data.adminAudit.map((entry) => <article key={entry.id}><ShieldCheck /><span><b>{entry.summary}</b><small>{entry.adminName} · {new Date(entry.createdAt).toLocaleString("fa-IR")}</small></span></article>)}{!data.adminAudit.length && <Empty text="هنوز رویداد مدیریتی ثبت نشده" />}</div>}
    </section>
  </div>;
}

function InterestPicker({ selected, onChange, legend }: { selected: Interest[]; onChange: (next: Interest[]) => void; legend: string }) {
  const toggle = (interest: Interest) => onChange(selected.includes(interest) ? selected.filter((item) => item !== interest) : [...selected, interest]);
  return <fieldset className="interestPicker wide"><legend>{legend}<small>چند گزینه هم‌زمان قابل انتخاب است</small></legend><div className="interestChips">{interestOptions.map((interest) => <label className={selected.includes(interest) ? "selected" : ""} key={interest}><input type="checkbox" checked={selected.includes(interest)} onChange={() => toggle(interest)} /><span>{interest}</span><Check /></label>)}</div></fieldset>;
}

function ProfileForm({ data, done }: { data: State; done: () => void }) {
  const [form, setForm] = useState({ name: data.current.name, age: data.current.age, gender: data.current.gender, maritalStatus: data.current.maritalStatus, city: data.current.city, bio: data.current.bio, interests: [...data.current.interests] as Interest[] });
  const submit = async (e: FormEvent) => { e.preventDefault(); await api.updateProfile({ userId: data.current.id, ...form }); done(); };
  return <form onSubmit={(e) => { void submit(e); }} className="formGrid"><label>نام<input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></label><label>سن<input type="number" min={data.settings.minAge} value={form.age} onChange={(e) => setForm({ ...form, age: Number(e.target.value) })} /></label><label>جنسیت<select value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })}><option>زن</option><option>مرد</option><option>نامشخص</option></select></label><label>وضعیت تأهل<select value={form.maritalStatus} onChange={(e) => setForm({ ...form, maritalStatus: e.target.value as "مجرد" | "متأهل" | "نامشخص" })}><option>مجرد</option><option>متأهل</option><option>نامشخص</option></select></label><label>شهر<input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></label><label className="wide">معرفی<textarea value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} /></label><InterestPicker legend="علاقه‌مندی‌ها" selected={form.interests} onChange={(interests) => setForm({ ...form, interests })} /><button className="primary wide" type="submit">ذخیره تغییرات</button></form>;
}

function RegisterForm({ done }: { done: (id: number, message: string) => void }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [maritalStatus, setMaritalStatus] = useState<"" | "مجرد" | "متأهل">("");
  const [interests, setInterests] = useState<Interest[]>([]);
  const submit = async (e: FormEvent) => { e.preventDefault(); if (!maritalStatus) return; const r = await api.verifyPhone({ name, phone, code: code as "1234", maritalStatus, interests }); done(r.userId, "حساب و علاقه‌مندی‌ها ذخیره شد"); };
  return <form className="loginForm registrationForm" onSubmit={(e) => { void submit(e); }}><p>در فاز تست، پیامک شبیه‌سازی شده و کد <b>۱۲۳۴</b> است.</p><div className="registrationFields"><label>نام<input value={name} onChange={(e) => setName(e.target.value)} required minLength={2} /></label><label>شماره موبایل<input type="tel" inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} required minLength={7} /></label><label>وضعیت تأهل<select aria-label="وضعیت تأهل" value={maritalStatus} onChange={(e) => setMaritalStatus(e.target.value as "" | "مجرد" | "متأهل")} required><option value="" disabled>انتخاب کنید</option><option value="مجرد">مجرد</option><option value="متأهل">متأهل</option></select></label><label>کد تأیید<input inputMode="numeric" value={code} onChange={(e) => setCode(e.target.value)} pattern="1234" required /></label></div><InterestPicker legend="علاقه‌مندی‌ها" selected={interests} onChange={setInterests} /><button className="primary" type="submit">تأیید و ساخت حساب</button></form>;
}

function AdminLogin({ userId, done }: { userId: number; done: (ok: boolean, message: string) => void }) { const submit = async (e: FormEvent) => { e.preventDefault(); const r = await api.adminLogin({ userId, panel: "management" }); done(r.ok, r.message); }; return <form className="loginForm" onSubmit={(e) => { void submit(e); }}><p>سطح مدیریت همین حساب برای ورود به پنل، در سمت سرور بررسی می‌شود.</p><button className="primary" type="submit">تأیید ورود مدیر</button></form>; }

function SettingsForm({ data, done }: { data: State; done: () => void }) { const [minAge, setMinAge] = useState(data.settings.minAge); const [dailyGift, setDailyGift] = useState(data.settings.dailyGift); const [dailyHangoutTime, setDailyHangoutTime] = useState(data.settings.dailyHangoutTime); const save = async (e: FormEvent) => { e.preventDefault(); await api.adminUpdate({ userId: data.current.id, kind: "settings", minAge, dailyGift, dailyHangoutTime }); done(); }; return <form className="formGrid" onSubmit={(e) => { void save(e); }}><label>حداقل سن<input type="number" min={18} max={30} value={minAge} onChange={(e) => setMinAge(Number(e.target.value))} /></label><label>هدیه روزانه<input type="number" min={1} max={200} value={dailyGift} onChange={(e) => setDailyGift(Number(e.target.value))} /></label><label className="wide">ساعت شروع دورهمی روزانه<input type="time" value={dailyHangoutTime} onChange={(e) => setDailyHangoutTime(e.target.value)} required /></label><button className="primary wide">ذخیره تنظیمات</button></form>; }

function Sheet({ title, close, children }: { title: string; close: () => void; children: React.ReactNode }) { return <div className="sheetBackdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) close(); }}><section className="sheet" data-pull-refresh-scroll data-pull-refresh-page="sheet"><header><h2>{title}</h2><button aria-label="بستن" onClick={close}><X /></button></header>{children}</section></div>; }
function PageTitle({ title, subtitle }: { title: string; subtitle: string }) { return <div className="pageTitle"><div><h1>{title}</h1><p>{subtitle}</p></div></div>; }
