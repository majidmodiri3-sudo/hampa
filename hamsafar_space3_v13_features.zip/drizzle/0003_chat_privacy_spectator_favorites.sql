ALTER TABLE `conversations` ADD `confidential` integer DEFAULT false NOT NULL;
--> statement-breakpoint
UPDATE `conversations` SET `confidential` = true WHERE `kind` = 'private';
--> statement-breakpoint
ALTER TABLE `memberships` ADD `muted` integer DEFAULT false NOT NULL;
--> statement-breakpoint
ALTER TABLE `memberships` ADD `blocked` integer DEFAULT false NOT NULL;
--> statement-breakpoint
CREATE TABLE `game_spectators` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `game_room_id` integer NOT NULL,
  `user_id` integer NOT NULL,
  `favorite_user_id` integer,
  `joined_at` integer NOT NULL,
  FOREIGN KEY (`game_room_id`) REFERENCES `game_rooms`(`id`) ON UPDATE no action ON DELETE no action,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action,
  FOREIGN KEY (`favorite_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `game_spectators_game_room_id_user_id_unique` ON `game_spectators` (`game_room_id`,`user_id`);
--> statement-breakpoint
CREATE TABLE `channel_comments` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `post_id` integer NOT NULL,
  `user_id` integer NOT NULL,
  `text` text NOT NULL,
  `created_at` integer NOT NULL,
  FOREIGN KEY (`post_id`) REFERENCES `channel_posts`(`id`) ON UPDATE no action ON DELETE no action,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);