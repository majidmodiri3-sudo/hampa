ALTER TABLE `game_spectators` ADD `favorite_team` text;
--> statement-breakpoint
ALTER TABLE `channel_posts` ADD `media_type` text;
--> statement-breakpoint
ALTER TABLE `channel_posts` ADD `media_blob_key` text;
--> statement-breakpoint
UPDATE `conversations` SET `confidential` = true WHERE `kind` = 'private';
