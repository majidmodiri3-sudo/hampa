CREATE TABLE `game_sessions` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `user_id` integer NOT NULL,
  `game_type` text NOT NULL,
  `stake` integer NOT NULL DEFAULT 0,
  `status` text NOT NULL DEFAULT 'active',
  `state_json` text NOT NULL,
  `created_at` integer NOT NULL,
  `updated_at` integer NOT NULL,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `game_sessions_user_status_idx` ON `game_sessions` (`user_id`,`status`);