CREATE TABLE `score_groups` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `name` text NOT NULL,
  `created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `score_groups_name_unique` ON `score_groups` (`name`);
--> statement-breakpoint
CREATE TABLE `score_group_members` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `group_id` integer NOT NULL,
  `user_id` integer NOT NULL,
  FOREIGN KEY (`group_id`) REFERENCES `score_groups`(`id`) ON UPDATE no action ON DELETE no action,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `score_group_members_user_id_unique` ON `score_group_members` (`user_id`);
--> statement-breakpoint
CREATE TABLE `score_events` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `user_id` integer NOT NULL,
  `source_type` text NOT NULL,
  `source_id` integer NOT NULL,
  `outcome` text NOT NULL,
  `points` integer NOT NULL,
  `created_at` integer NOT NULL,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `score_events_user_source_unique` ON `score_events` (`user_id`,`source_type`,`source_id`);
--> statement-breakpoint
CREATE INDEX `score_events_user_idx` ON `score_events` (`user_id`);
