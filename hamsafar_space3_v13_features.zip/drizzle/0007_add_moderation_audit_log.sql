CREATE TABLE `moderation_audit` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `admin_id` integer NOT NULL,
  `action` text NOT NULL,
  `target_type` text NOT NULL,
  `target_id` integer,
  `summary` text NOT NULL,
  `created_at` integer NOT NULL,
  FOREIGN KEY (`admin_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `moderation_audit_created_idx` ON `moderation_audit` (`created_at`);
