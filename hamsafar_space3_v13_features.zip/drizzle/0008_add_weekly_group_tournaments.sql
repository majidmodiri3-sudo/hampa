CREATE TABLE `tournaments` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `title` text NOT NULL,
  `game_type` text DEFAULT 'حکم' NOT NULL,
  `entry_fee` integer DEFAULT 50 NOT NULL,
  `prize_pool` integer DEFAULT 0 NOT NULL,
  `status` text DEFAULT 'registration' NOT NULL,
  `champion_group_id` integer,
  `created_at` integer NOT NULL,
  `finished_at` integer,
  FOREIGN KEY (`champion_group_id`) REFERENCES `score_groups`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `tournament_registrations` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `tournament_id` integer NOT NULL,
  `group_id` integer NOT NULL,
  `registered_by_user_id` integer NOT NULL,
  `created_at` integer NOT NULL,
  FOREIGN KEY (`tournament_id`) REFERENCES `tournaments`(`id`) ON UPDATE no action ON DELETE no action,
  FOREIGN KEY (`group_id`) REFERENCES `score_groups`(`id`) ON UPDATE no action ON DELETE no action,
  FOREIGN KEY (`registered_by_user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `tournament_registrations_tournament_id_group_id_unique` ON `tournament_registrations` (`tournament_id`,`group_id`);
--> statement-breakpoint
CREATE TABLE `tournament_matches` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `tournament_id` integer NOT NULL,
  `home_group_id` integer NOT NULL,
  `away_group_id` integer NOT NULL,
  `status` text DEFAULT 'scheduled' NOT NULL,
  `winner_group_id` integer,
  `game_room_id` integer,
  `created_at` integer NOT NULL,
  FOREIGN KEY (`tournament_id`) REFERENCES `tournaments`(`id`) ON UPDATE no action ON DELETE no action,
  FOREIGN KEY (`home_group_id`) REFERENCES `score_groups`(`id`) ON UPDATE no action ON DELETE no action,
  FOREIGN KEY (`away_group_id`) REFERENCES `score_groups`(`id`) ON UPDATE no action ON DELETE no action,
  FOREIGN KEY (`winner_group_id`) REFERENCES `score_groups`(`id`) ON UPDATE no action ON DELETE no action,
  FOREIGN KEY (`game_room_id`) REFERENCES `game_rooms`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `tournament_matches_tournament_idx` ON `tournament_matches` (`tournament_id`);
