CREATE TABLE `live_voice_clips` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `game_room_id` integer NOT NULL,
  `sender_id` integer NOT NULL,
  `sender_role` text NOT NULL,
  `blob_key` text NOT NULL,
  `mime_type` text NOT NULL,
  `duration_ms` integer DEFAULT 0 NOT NULL,
  `created_at` integer NOT NULL,
  FOREIGN KEY (`game_room_id`) REFERENCES `game_rooms`(`id`) ON UPDATE no action ON DELETE no action,
  FOREIGN KEY (`sender_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `live_voice_clips_room_idx` ON `live_voice_clips` (`game_room_id`,`id`);
--> statement-breakpoint
CREATE TABLE `spectator_gifts` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `game_room_id` integer NOT NULL,
  `spectator_id` integer NOT NULL,
  `amount` integer DEFAULT 0 NOT NULL,
  `status` text DEFAULT 'escrow' NOT NULL,
  `platform_fee` integer DEFAULT 0 NOT NULL,
  `paid_amount` integer DEFAULT 0 NOT NULL,
  `created_at` integer NOT NULL,
  `settled_at` integer,
  FOREIGN KEY (`game_room_id`) REFERENCES `game_rooms`(`id`) ON UPDATE no action ON DELETE no action,
  FOREIGN KEY (`spectator_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `spectator_gifts_game_room_id_spectator_id_unique` ON `spectator_gifts` (`game_room_id`,`spectator_id`);
--> statement-breakpoint
CREATE INDEX `spectator_gifts_room_idx` ON `spectator_gifts` (`game_room_id`);
