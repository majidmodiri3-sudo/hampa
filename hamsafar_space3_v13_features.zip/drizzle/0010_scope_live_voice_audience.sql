ALTER TABLE `live_voice_clips` ADD `audience` text DEFAULT 'spectator_room' NOT NULL;
--> statement-breakpoint
UPDATE `live_voice_clips` SET `audience` = 'player_room' WHERE `sender_role` = 'player';
