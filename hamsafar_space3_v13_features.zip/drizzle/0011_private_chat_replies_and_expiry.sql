ALTER TABLE `conversations` ADD `secret_timer_minutes` integer DEFAULT 5 NOT NULL;
--> statement-breakpoint
ALTER TABLE `messages` ADD `reply_to_id` integer;
--> statement-breakpoint
ALTER TABLE `messages` ADD `expires_at` integer;
--> statement-breakpoint
ALTER TABLE `channel_posts` ADD `reply_to_id` integer;
--> statement-breakpoint
UPDATE `conversations` SET `confidential` = 0 WHERE `kind` = 'private';
