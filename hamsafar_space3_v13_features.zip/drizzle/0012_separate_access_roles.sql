ALTER TABLE `users` ADD `access_role` text DEFAULT 'user' NOT NULL;
--> statement-breakpoint
UPDATE `users` SET `access_role` = 'management' WHERE `is_admin` = 1;
