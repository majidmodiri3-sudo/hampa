ALTER TABLE `users` ADD `marital_status` text DEFAULT 'نامشخص' NOT NULL;
