CREATE TABLE `player_game_avatars` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `user_id` integer NOT NULL,
  `face` text DEFAULT 'round' NOT NULL,
  `hair` text DEFAULT 'short' NOT NULL,
  `outfit` text DEFAULT 'ranger' NOT NULL,
  `accent` text DEFAULT 'emerald' NOT NULL,
  `emblem` text DEFAULT 'star' NOT NULL,
  `updated_at` integer NOT NULL,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `player_game_avatars_user_id_unique` ON `player_game_avatars` (`user_id`);