ALTER TABLE `game_rooms` ADD `turn_number` integer NOT NULL DEFAULT 1;
--> statement-breakpoint
ALTER TABLE `game_rooms` ADD `host_chance` integer NOT NULL DEFAULT 50;
--> statement-breakpoint
ALTER TABLE `game_rooms` ADD `commentary` text NOT NULL DEFAULT 'داور مجازی برای شروع دور آماده است.';
--> statement-breakpoint
ALTER TABLE `game_rooms` ADD `last_event` text NOT NULL DEFAULT 'شروع میز';
--> statement-breakpoint
ALTER TABLE `game_rooms` ADD `host_mood` text NOT NULL DEFAULT 'focused';
--> statement-breakpoint
ALTER TABLE `game_rooms` ADD `guest_mood` text NOT NULL DEFAULT 'focused';
--> statement-breakpoint
CREATE TABLE `game_cheers` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `game_room_id` integer NOT NULL,
  `sender_id` integer NOT NULL,
  `reaction` text NOT NULL,
  `created_at` integer NOT NULL,
  FOREIGN KEY (`game_room_id`) REFERENCES `game_rooms`(`id`) ON UPDATE no action ON DELETE cascade,
  FOREIGN KEY (`sender_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `game_cheers_room_idx` ON `game_cheers` (`game_room_id`, `id`);