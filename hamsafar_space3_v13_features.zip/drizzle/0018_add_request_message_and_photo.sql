ALTER TABLE `connection_requests` ADD `message` text DEFAULT '' NOT NULL;
--> statement-breakpoint
ALTER TABLE `connection_requests` ADD `image_blob_key` text;