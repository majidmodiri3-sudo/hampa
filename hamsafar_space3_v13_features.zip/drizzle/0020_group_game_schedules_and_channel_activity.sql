ALTER TABLE `conversations` ADD `channel_activity` text DEFAULT '' NOT NULL;
--> statement-breakpoint
CREATE TABLE `scheduled_group_games` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `title` text NOT NULL,
  `game_type` text NOT NULL,
  `group_id` integer,
  `host_id` integer NOT NULL,
  `starts_at` integer NOT NULL,
  `status` text DEFAULT 'scheduled' NOT NULL,
  `created_at` integer NOT NULL,
  FOREIGN KEY (`group_id`) REFERENCES `conversations`(`id`) ON UPDATE no action ON DELETE no action,
  FOREIGN KEY (`host_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `scheduled_group_games_starts_idx` ON `scheduled_group_games` (`starts_at`);
--> statement-breakpoint
CREATE TABLE `scheduled_game_responses` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `scheduled_game_id` integer NOT NULL,
  `user_id` integer NOT NULL,
  `response` text NOT NULL,
  `created_at` integer NOT NULL,
  FOREIGN KEY (`scheduled_game_id`) REFERENCES `scheduled_group_games`(`id`) ON UPDATE no action ON DELETE cascade,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `scheduled_game_responses_game_user_unique` ON `scheduled_game_responses` (`scheduled_game_id`,`user_id`);