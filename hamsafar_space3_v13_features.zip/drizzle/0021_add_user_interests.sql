ALTER TABLE `users` ADD `interests` text DEFAULT '[]' NOT NULL;
