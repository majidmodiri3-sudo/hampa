ALTER TABLE `conversations` ADD `image_blob_key` text;
