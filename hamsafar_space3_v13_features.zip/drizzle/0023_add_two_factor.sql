ALTER TABLE `users` ADD `two_factor_enabled` integer DEFAULT 0 NOT NULL;
