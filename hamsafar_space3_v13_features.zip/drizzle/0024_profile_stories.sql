CREATE TABLE `profile_stories` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `user_id` integer NOT NULL,
  `media_type` text NOT NULL,
  `media_blob_key` text NOT NULL,
  `caption` text DEFAULT '' NOT NULL,
  `expires_at` integer NOT NULL,
  `created_at` integer NOT NULL,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `profile_stories_user_expiry_idx` ON `profile_stories` (`user_id`,`expires_at`);
--> statement-breakpoint
CREATE TABLE `profile_story_views` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `story_id` integer NOT NULL,
  `viewer_id` integer NOT NULL,
  `viewed_at` integer NOT NULL,
  FOREIGN KEY (`story_id`) REFERENCES `profile_stories`(`id`) ON UPDATE no action ON DELETE cascade,
  FOREIGN KEY (`viewer_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `profile_story_views_story_viewer_unique` ON `profile_story_views` (`story_id`,`viewer_id`);
