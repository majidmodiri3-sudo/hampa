CREATE TABLE `daily_stories` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `user_id` integer NOT NULL,
  `story_day` text NOT NULL,
  `media_type` text NOT NULL,
  `media_blob_key` text NOT NULL,
  `caption` text DEFAULT '' NOT NULL,
  `expires_at` integer NOT NULL,
  `created_at` integer NOT NULL,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `daily_stories_user_day_unique` ON `daily_stories` (`user_id`,`story_day`);
--> statement-breakpoint
CREATE INDEX `daily_stories_expiry_idx` ON `daily_stories` (`expires_at`);
--> statement-breakpoint
CREATE TABLE `daily_story_views` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `story_id` integer NOT NULL,
  `viewer_id` integer NOT NULL,
  `viewed_at` integer NOT NULL,
  FOREIGN KEY (`story_id`) REFERENCES `daily_stories`(`id`) ON UPDATE no action ON DELETE cascade,
  FOREIGN KEY (`viewer_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `daily_story_views_story_viewer_unique` ON `daily_story_views` (`story_id`,`viewer_id`);
--> statement-breakpoint
CREATE TABLE `public_stories` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `user_id` integer NOT NULL,
  `media_type` text NOT NULL,
  `media_blob_key` text NOT NULL,
  `caption` text DEFAULT '' NOT NULL,
  `expires_at` integer NOT NULL,
  `created_at` integer NOT NULL,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `public_stories_expiry_idx` ON `public_stories` (`expires_at`);
--> statement-breakpoint
CREATE TABLE `public_story_likes` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `story_id` integer NOT NULL,
  `user_id` integer NOT NULL,
  `created_at` integer NOT NULL,
  FOREIGN KEY (`story_id`) REFERENCES `public_stories`(`id`) ON UPDATE no action ON DELETE cascade,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `public_story_likes_story_user_unique` ON `public_story_likes` (`story_id`,`user_id`);
--> statement-breakpoint
CREATE TABLE `public_story_comments` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `story_id` integer NOT NULL,
  `user_id` integer NOT NULL,
  `text` text NOT NULL,
  `created_at` integer NOT NULL,
  FOREIGN KEY (`story_id`) REFERENCES `public_stories`(`id`) ON UPDATE no action ON DELETE cascade,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `public_story_comments_story_idx` ON `public_story_comments` (`story_id`,`id`);
--> statement-breakpoint
CREATE TABLE `user_follows` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `follower_id` integer NOT NULL,
  `followed_id` integer NOT NULL,
  `created_at` integer NOT NULL,
  FOREIGN KEY (`follower_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade,
  FOREIGN KEY (`followed_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `user_follows_pair_unique` ON `user_follows` (`follower_id`,`followed_id`);