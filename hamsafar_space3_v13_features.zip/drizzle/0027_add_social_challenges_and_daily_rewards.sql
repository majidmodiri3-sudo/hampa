CREATE TABLE `battle_cries` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `user_id` integer NOT NULL REFERENCES `users`(`id`) ON DELETE CASCADE,
  `text` text NOT NULL,
  `expires_at` integer NOT NULL,
  `created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `battle_cries_expiry_idx` ON `battle_cries` (`expires_at`);
--> statement-breakpoint
CREATE TABLE `quick_duels` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `user_id` integer NOT NULL REFERENCES `users`(`id`) ON DELETE CASCADE,
  `question_key` text NOT NULL,
  `correct_option` integer NOT NULL,
  `started_at` integer NOT NULL,
  `answered_at` integer,
  `won` integer,
  `reward` integer NOT NULL DEFAULT 0
);
--> statement-breakpoint
CREATE INDEX `quick_duels_user_idx` ON `quick_duels` (`user_id`, `id`);
--> statement-breakpoint
CREATE TABLE `daily_wheel_spins` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `user_id` integer NOT NULL REFERENCES `users`(`id`) ON DELETE CASCADE,
  `spin_day` text NOT NULL,
  `reward` integer NOT NULL,
  `created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `daily_wheel_spins_user_day_unique` ON `daily_wheel_spins` (`user_id`, `spin_day`);
--> statement-breakpoint
CREATE TABLE `detective_attempts` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `user_id` integer NOT NULL REFERENCES `users`(`id`) ON DELETE CASCADE,
  `case_key` text NOT NULL,
  `accused` text NOT NULL,
  `correct` integer NOT NULL,
  `reward` integer NOT NULL DEFAULT 0,
  `created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `detective_attempts_user_case_idx` ON `detective_attempts` (`user_id`, `case_key`);