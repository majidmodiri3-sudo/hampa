CREATE TABLE `ambassador_profiles` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `user_id` integer NOT NULL REFERENCES `users`(`id`) ON DELETE CASCADE,
  `invite_code` text NOT NULL,
  `created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `ambassador_profiles_user_unique` ON `ambassador_profiles` (`user_id`);
--> statement-breakpoint
CREATE UNIQUE INDEX `ambassador_profiles_code_unique` ON `ambassador_profiles` (`invite_code`);
--> statement-breakpoint
CREATE TABLE `ambassador_referrals` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `inviter_id` integer NOT NULL REFERENCES `users`(`id`) ON DELETE CASCADE,
  `invitee_id` integer NOT NULL REFERENCES `users`(`id`) ON DELETE CASCADE,
  `invite_code` text NOT NULL,
  `reward` integer NOT NULL DEFAULT 100,
  `created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `ambassador_referrals_invitee_unique` ON `ambassador_referrals` (`invitee_id`);
--> statement-breakpoint
CREATE INDEX `ambassador_referrals_inviter_idx` ON `ambassador_referrals` (`inviter_id`, `id`);
--> statement-breakpoint
CREATE TABLE `financial_safe_pins` (
  `id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
  `user_id` integer NOT NULL REFERENCES `users`(`id`) ON DELETE CASCADE,
  `pin_hash` text NOT NULL,
  `failed_attempts` integer NOT NULL DEFAULT 0,
  `locked_until` integer,
  `updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `financial_safe_pins_user_unique` ON `financial_safe_pins` (`user_id`);