// scripts/build-client.mjs
//
// Standalone replacement for the SDK's buildClient() (which refuses to run
// outside the Hatch builder pipeline via HATCH_SPACES_BUILD_DRIVER).
// Same bundling recipe — Bun.build over client/index.html with the Tailwind
// plugin, production defines, and hashed asset names — minus the guard, so
// the app can be built on your own machine.
//
// Run from the project root:  bun run build:client

import { rm } from "node:fs/promises";
import { basename, dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import tailwindPlugin from "bun-plugin-tailwind";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const ENTRY = join(ROOT, "client/index.html");
const OUTDIR = join(ROOT, "client/dist");

if (typeof Bun === "undefined" || typeof Bun.build !== "function") {
  throw new Error("build-client.mjs must run under Bun");
}

await rm(OUTDIR, { force: true, recursive: true });

const result = await Bun.build({
  entrypoints: [ENTRY],
  outdir: OUTDIR,
  minify: true,
  define: {
    "process.env.NODE_ENV": JSON.stringify("production"),
  },
  naming: {
    asset: "assets/[name]-[hash].[ext]",
    chunk: "assets/[name]-[hash].[ext]",
    entry: "[name].[ext]",
  },
  plugins: [tailwindPlugin],
});

if (!result.success) {
  for (const log of result.logs) console.error(log);
  throw new Error("client build failed; see logged diagnostics");
}

// Bun emits imported assets as bare `./<name>-<hash>.<ext>`; re-prefix them
// to `./assets/...` so they resolve when served from the project root.
const assetFiles = result.outputs
  .filter((o) => o.kind === "asset")
  .map((o) => basename(o.path));

if (assetFiles.length > 0) {
  for (const output of result.outputs) {
    if (!/\.(js|css|html)$/.test(output.path)) continue;
    let text = await output.text();
    let changed = false;
    for (const name of assetFiles) {
      const bare = `./${name}`;
      if (text.includes(bare)) {
        text = text.split(bare).join(`./assets/${name}`);
        changed = true;
      }
    }
    if (changed) await Bun.write(output.path, text);
  }
}

console.log(`client built -> ${OUTDIR}`);
