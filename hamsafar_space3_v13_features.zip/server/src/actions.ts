import { defineAction, z, type ActionsModule, type Ctx } from "@hatch/space-sdk";
import { and, desc, eq, gt, inArray, lt, or } from "drizzle-orm";
import * as schema from "./schema";

const okSchema = z.object({ ok: z.literal(true), message: z.string().optional() });
const requestResponseSchema = z.object({ ok: z.literal(true), message: z.string().optional(), conversationId: z.number().nullable() });
const quickDuelStartSchema = z.object({ ok: z.literal(true), duelId: z.number(), question: z.string(), options: z.array(z.string()).length(3), expiresAt: z.string() });
const quickDuelAnswerSchema = z.object({ ok: z.literal(true), correct: z.boolean(), reward: z.number(), message: z.string() });
const wheelResponseSchema = z.object({ ok: z.literal(true), reward: z.number(), message: z.string() });
const detectiveResponseSchema = z.object({ ok: z.literal(true), correct: z.boolean(), reward: z.number(), message: z.string() });
const safeUnlockResponseSchema = z.object({ ok: z.literal(true), unlocked: z.boolean(), message: z.string(), lockedUntil: z.string().nullable() });
const safePinResponseSchema = z.object({ ok: z.literal(true), configured: z.boolean(), message: z.string() });
const ambassadorRedeemResponseSchema = z.object({ ok: z.literal(true), redeemed: z.boolean(), message: z.string() });
const QUICK_DUEL_REWARD = 50;
const AMBASSADOR_REWARD = 100;
const DETECTIVE_REWARD = 200;
const DETECTIVE_ENTRY = 20;
const quickDuelBank = [
  { key: "multiply-9-6", question: "حاصل ۹ × ۶ کدام است؟", options: ["۴۸", "۵۴", "۶۳"], correct: 1 },
  { key: "sequence-3", question: "عدد بعدی در دنباله ۳، ۶، ۱۲ چیست؟", options: ["۱۸", "۲۱", "۲۴"], correct: 2 },
  { key: "iran-capital", question: "پایتخت ایران کدام شهر است؟", options: ["تهران", "شیراز", "تبریز"], correct: 0 },
] as const;
const DEMO_PHONES = new Set(["09000000001", "09000000002", "09000000003", "09999999998", "09999999999"]);
const interestSchema = z.enum(["موسیقی", "ورزش", "سفر", "فیلم و سریال", "کتاب", "بازی", "آشپزی", "هنر", "تکنولوژی", "طبیعت‌گردی", "عکاسی", "مد و استایل", "قهوه و کافه", "حیوانات"]);
const interestsSchema = z.array(interestSchema).max(14).refine((values) => new Set(values).size === values.length, "علاقه‌مندی تکراری مجاز نیست");
type Interest = z.infer<typeof interestSchema>;
const parseInterests = (value: string): Interest[] => {
  try {
    const parsed: unknown = JSON.parse(value);
    const result = interestsSchema.safeParse(parsed);
    return result.success ? result.data : [];
  } catch {
    return [];
  }
};
const tehranDayKey = (date = new Date()) => {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Tehran", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(date);
  const value = (type: "year" | "month" | "day") => parts.find((part) => part.type === type)?.value ?? "00";
  return `${value("year")}-${value("month")}-${value("day")}`;
};
const PIN_HASH_ITERATIONS = 210_000;
const bytesToBase64 = (bytes: Uint8Array) => btoa(String.fromCharCode(...bytes));
const base64ToBytes = (value: string) => Uint8Array.from(atob(value), (char) => char.charCodeAt(0));
const hashFinancialPin = async (pin: string): Promise<string> => {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(pin), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations: PIN_HASH_ITERATIONS, hash: "SHA-256" }, key, 256);
  return `v1$${PIN_HASH_ITERATIONS}$${bytesToBase64(salt)}$${bytesToBase64(new Uint8Array(bits))}`;
};
const verifyFinancialPin = async (pin: string, stored: string): Promise<boolean> => {
  const [version, iterationsText, saltText, expectedText] = stored.split("$");
  const iterations = Number(iterationsText);
  if (version !== "v1" || !Number.isInteger(iterations) || iterations < 100_000 || !saltText || !expectedText) return false;
  const salt = base64ToBytes(saltText);
  const expected = base64ToBytes(expectedText);
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(pin), "PBKDF2", false, ["deriveBits"]);
  const bits = new Uint8Array(await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations, hash: "SHA-256" }, key, expected.byteLength * 8));
  if (bits.byteLength !== expected.byteLength) return false;
  let difference = 0;
  for (let index = 0; index < bits.byteLength; index += 1) difference |= (bits[index] ?? 0) ^ (expected[index] ?? 0);
  return difference === 0;
};
const storyUploadSchema = z.object({
  userId: z.number().int().positive(),
  caption: z.string().trim().max(160),
  mediaType: z.enum(["image", "video"]),
  dataBase64: z.string().min(1),
  mimeType: z.enum(["image/jpeg", "image/png", "image/webp", "video/mp4", "video/webm"]),
  filename: z.string().min(1).max(100),
});
const storyBytes = (args: z.infer<typeof storyUploadSchema>) => {
  if ((args.mediaType === "image") !== args.mimeType.startsWith("image/")) return null;
  const binary = Uint8Array.from(atob(args.dataBase64), (char) => char.charCodeAt(0));
  return binary.byteLength <= 8 * 1024 * 1024 ? binary : null;
};
const userSchema = z.object({ id: z.number(), phone: z.string(), name: z.string(), age: z.number(), gender: z.string(), maritalStatus: z.enum(["مجرد", "متأهل", "نامشخص"]), bio: z.string(), city: z.string(), interests: interestsSchema, coins: z.number(), xp: z.number(), wins: z.number(), isTest: z.boolean(), isAdmin: z.boolean(), accessRole: z.enum(["user", "admin", "management"]), isActive: z.boolean(), twoFactorEnabled: z.boolean(), lastGiftDay: z.string().nullable() });
const gameTypeSchema = z.enum(["مافیا", "حکم", "پوکر", "۲۱", "کوئیز", "منچ", "مارپله"]);
const quickGameTypeSchema = z.enum(["مافیا", "حکم", "پوکر", "۲۱", "کوئیز"]);
const messageReactionSchema = z.enum(["❤️", "😂", "😍", "👍", "👏", "🔥"]);
const gameAvatarSchema = z.object({
  userId: z.number(),
  userName: z.string(),
  face: z.enum(["round", "sharp", "soft"]),
  hair: z.enum(["short", "wave", "crest", "hood"]),
  outfit: z.enum(["ranger", "royal", "shadow", "sport"]),
  accent: z.enum(["emerald", "cherry", "gold", "ocean"]),
  emblem: z.enum(["star", "shield", "bolt", "crown"]),
  updatedAt: z.string(),
});
const directorDecisionSchema = z.object({
  commentary: z.string().min(8).max(120),
  event: z.string().min(3).max(60),
  hostChance: z.number().int().min(20).max(80),
  hostMood: z.enum(["focused", "celebrate", "worried"]),
  guestMood: z.enum(["focused", "celebrate", "worried"]),
});
const gamePlayerSchema = z.object({ id: z.number().nullable(), name: z.string(), color: z.enum(["red", "blue", "yellow", "green"]), bot: z.boolean() });
const boardEventSchema = z.discriminatedUnion("type", [
  z.object({ type: z.literal("die"), playerIndex: z.number(), playerId: z.number().nullable(), value: z.number().int().min(1).max(6) }),
  z.object({ type: z.literal("move"), playerIndex: z.number(), playerId: z.number().nullable(), from: z.number(), to: z.number(), landing: z.number(), jump: z.enum(["ladder", "snake"]).nullable() }),
]);
type BoardEvent = z.infer<typeof boardEventSchema>;
const gameSessionResponse = z.object({
  ok: z.literal(true),
  sessionId: z.number(),
  gameType: gameTypeSchema,
  status: z.enum(["active", "finished"]),
  prompt: z.string(),
  board: z.array(z.string()),
  options: z.array(z.string()),
  result: z.string().nullable(),
  won: z.boolean().nullable(),
  coins: z.number(),
  xp: z.number(),
  boardKind: z.enum(["classic", "ludo", "snakes"]),
  die: z.number().nullable(),
  currentPlayerIndex: z.number(),
  players: z.array(gamePlayerSchema),
  ludoPieces: z.array(z.object({ id: z.number(), playerIndex: z.number(), progress: z.number() })),
  snakePositions: z.array(z.number()),
  movablePieceIds: z.array(z.number()),
  safeCells: z.array(z.number()),
  eventQueue: z.array(boardEventSchema),
});
type GameType = z.infer<typeof gameTypeSchema>;
const normalizeGameType = (value: string): GameType => gameTypeSchema.safeParse(value).data ?? "حکم";
type GameSessionView = z.infer<typeof gameSessionResponse>;
type GamePlayer = z.infer<typeof gamePlayerSchema>;
type GameState = {
  round: number;
  playerScore: number;
  botScore: number;
  hand: number[];
  botHand: number[];
  target: number;
  question: number;
  finished: boolean;
  won: boolean | null;
  result: string | null;
  boardKind?: "classic" | "ludo" | "snakes";
  playerCount?: number;
  currentPlayerIndex?: number;
  die?: number | null;
  players?: GamePlayer[];
  ludoPieces?: Array<{ id: number; playerIndex: number; progress: number }>;
  snakePositions?: number[];
  movablePieceIds?: number[];
  safeCells?: number[];
  winnerIndex?: number | null;
  turn?: number;
  eventQueue?: BoardEvent[];
  eventLog?: BoardEvent[];
};

const randomCard = () => Math.floor(Math.random() * 9) + 2;
const cardName = (value: number) => value === 11 ? "آس" : value === 10 ? "۱۰" : String(value);
const sum21 = (cards: number[]) => cards.reduce((total, card) => total + card, 0);
const pairScore = (cards: number[]) => {
  const counts = new Map<number, number>();
  for (const card of cards) counts.set(card, (counts.get(card) ?? 0) + 1);
  return Math.max(...counts.values()) * 20 + cards.reduce((a, b) => a + b, 0);
};
const quizBank = [
  { question: "پایتخت ایران کدام شهر است؟", options: ["تهران", "شیراز", "تبریز"], correct: 0 },
  { question: "عدد بعدی در دنباله ۲، ۴، ۸ چیست؟", options: ["۱۰", "۱۲", "۱۶"], correct: 2 },
  { question: "کدام سیاره به خورشید نزدیک‌تر است؟", options: ["عطارد", "زمین", "مریخ"], correct: 0 },
] as const;

const BOARD_COLORS = ["red", "blue", "yellow", "green"] as const;
const BOT_NAMES = ["رُها", "سام", "آبتین"] as const;
const LUDO_SAFE_CELLS = [0, 8, 13, 21, 26, 34, 39, 47] as const;
const SNAKES_AND_LADDERS: Record<number, number> = { 4: 25, 13: 46, 33: 49, 42: 63, 50: 69, 62: 81, 74: 92, 27: 5, 40: 3, 43: 18, 54: 31, 66: 45, 76: 58, 89: 53, 99: 41 };
const rollDie = () => Math.floor(Math.random() * 6) + 1;
const baseBoardState = (kind: "ludo" | "snakes", playerCount: number, userId: number, userName: string): GameState => ({
  round: 1, playerScore: 0, botScore: 0, hand: [], botHand: [], target: kind === "ludo" ? 58 : 100, question: 0, finished: false, won: null, result: null,
  boardKind: kind, playerCount, currentPlayerIndex: 0, die: null,
  players: Array.from({ length: playerCount }, (_, index): GamePlayer => ({ id: index === 0 ? userId : null, name: index === 0 ? userName : (BOT_NAMES[index - 1] ?? `حریف ${index}`), color: BOARD_COLORS[index] ?? "green", bot: index !== 0 })),
  ludoPieces: kind === "ludo" ? Array.from({ length: playerCount * 4 }, (_, id) => ({ id, playerIndex: Math.floor(id / 4), progress: -1 })) : [],
  snakePositions: kind === "snakes" ? Array.from({ length: playerCount }, () => 0) : [],
  movablePieceIds: [], safeCells: [...LUDO_SAFE_CELLS], winnerIndex: null, turn: 1, eventQueue: [], eventLog: [],
});

function initialGameState(gameType: GameType, playerCount: number, userId: number, userName: string): GameState {
  if (gameType === "منچ") return baseBoardState("ludo", playerCount, userId, userName);
  if (gameType === "مارپله") return baseBoardState("snakes", playerCount, userId, userName);
  if (gameType === "۲۱") return { round: 1, playerScore: 0, botScore: 0, hand: [randomCard(), randomCard()], botHand: [randomCard(), randomCard()], target: 0, question: 0, finished: false, won: null, result: null };
  if (gameType === "پوکر") return { round: 1, playerScore: 0, botScore: 0, hand: [randomCard(), randomCard(), randomCard(), randomCard(), randomCard()], botHand: [randomCard(), randomCard(), randomCard(), randomCard(), randomCard()], target: 0, question: 0, finished: false, won: null, result: null };
  if (gameType === "حکم") return { round: 1, playerScore: 0, botScore: 0, hand: [randomCard(), randomCard(), randomCard()], botHand: [randomCard(), randomCard(), randomCard()], target: 0, question: 0, finished: false, won: null, result: null };
  if (gameType === "کوئیز") { const question = Math.floor(Math.random() * quizBank.length); return { round: 1, playerScore: 0, botScore: 0, hand: [], botHand: [], target: quizBank[question]?.correct ?? 0, question, finished: false, won: null, result: null }; }
  return { round: 1, playerScore: 0, botScore: 0, hand: [], botHand: [], target: Math.floor(Math.random() * 3), question: 0, finished: false, won: null, result: null };
}

function gameView(id: number, gameType: GameType, state: GameState, user: { coins: number; xp: number }): GameSessionView {
  const boardKind = state.boardKind ?? "classic";
  const lastBoardEvent = [...(state.eventQueue ?? [])].reverse().find((event) => event.type === "die");
  const lastDie = lastBoardEvent?.type === "die" ? lastBoardEvent.value : null;
  const extras = {
    boardKind,
    die: state.boardKind === "snakes" ? lastDie : (state.die ?? null),
    currentPlayerIndex: state.currentPlayerIndex ?? 0,
    players: state.players ?? [],
    ludoPieces: state.ludoPieces ?? [],
    snakePositions: state.snakePositions ?? [],
    movablePieceIds: state.movablePieceIds ?? [],
    safeCells: state.safeCells ?? [],
    eventQueue: state.eventQueue ?? [],
  };
  if (gameType === "منچ" || gameType === "مارپله") {
    const player = extras.players[extras.currentPlayerIndex];
    const title = gameType === "منچ" ? "منچ" : "مارپله";
    return { ok: true, sessionId: id, gameType, status: state.finished ? "finished" : "active", prompt: state.finished ? `${title} تمام شد.` : state.die ? `${player?.name ?? "بازیکن"} تاس ${state.die} آورده؛ مهره را انتخاب کن.` : `نوبت ${player?.name ?? "بازیکن"}؛ تاس را لمس کن.`, board: [], options: [], result: state.result, won: state.won, coins: user.coins, xp: user.xp, ...extras };
  }
  if (gameType === "۲۱") return { ok: true, sessionId: id, gameType, status: state.finished ? "finished" : "active", prompt: state.finished ? "این دست تمام شد." : "کارت بگیر یا روی امتیاز فعلی بایست.", board: [`دست شما: ${state.hand.map(cardName).join("، ")} · جمع ${sum21(state.hand)}`, `دست حریف: ${state.finished ? `${state.botHand.map(cardName).join("، ")} · جمع ${sum21(state.botHand)}` : `${cardName(state.botHand[0] ?? 0)}، کارت مخفی`}`], options: state.finished ? [] : ["کارت بگیر", "ایست"], result: state.result, won: state.won, coins: user.coins, xp: user.xp, ...extras };
  if (gameType === "پوکر") return { ok: true, sessionId: id, gameType, status: state.finished ? "finished" : "active", prompt: state.finished ? "دست‌ها رو شدند." : "یک کارت از سه کارت اول را عوض کن یا بدون تعویض بازی کن.", board: [`دست شما: ${state.hand.map(cardName).join("  ·  ")}`, state.finished ? `دست حریف: ${state.botHand.map(cardName).join("  ·  ")}` : "دست حریف: پنج کارت بسته"], options: state.finished ? [] : ["تعویض کارت ۱", "تعویض کارت ۲", "تعویض کارت ۳", "بدون تعویض"], result: state.result, won: state.won, coins: user.coins, xp: user.xp, ...extras };
  if (gameType === "حکم") return { ok: true, sessionId: id, gameType, status: state.finished ? "finished" : "active", prompt: state.finished ? "سه دست کامل شد." : `دست ${state.round} از ۳؛ یک کارت بازی کن.`, board: [`امتیاز شما ${state.playerScore}`, `امتیاز حریف ${state.botScore}`], options: state.finished ? [] : state.hand.map((card) => `بازی کارت ${cardName(card)}`), result: state.result, won: state.won, coins: user.coins, xp: user.xp, ...extras };
  if (gameType === "کوئیز") { const quiz = quizBank[state.question] ?? quizBank[0]; return { ok: true, sessionId: id, gameType, status: state.finished ? "finished" : "active", prompt: quiz.question, board: ["فقط یک پاسخ درست است", "پاسخ روی سرور بررسی می‌شود"], options: state.finished ? [] : [...quiz.options], result: state.result, won: state.won, coins: user.coins, xp: user.xp, ...extras }; }
  return { ok: true, sessionId: id, gameType, status: state.finished ? "finished" : "active", prompt: state.finished ? "رأی‌گیری تمام شد." : "به سرنخ‌ها نگاه کن و مافیا را پیدا کن.", board: ["نفر ۱: می‌گوید نفر ۲ مشکوک است", "نفر ۲: می‌گوید نفر ۳ شهروند است", "نفر ۳: سکوت کرده"], options: state.finished ? [] : ["اتهام به نفر ۱", "اتهام به نفر ۲", "اتهام به نفر ۳"], result: state.result, won: state.won, coins: user.coins, xp: user.xp, ...extras };
}

const ludoAbsoluteCell = (progress: number, playerIndex: number) => progress >= 0 && progress < 52 ? (progress + playerIndex * 13) % 52 : -1;
const ludoMovable = (state: GameState, playerIndex: number, die: number) => (state.ludoPieces ?? []).filter((piece) => {
  if (piece.playerIndex !== playerIndex || piece.progress >= 58) return false;
  if (piece.progress < 0) return die === 6;
  return piece.progress + die <= 58;
});
const nextTurn = (state: GameState) => {
  const count = state.playerCount ?? 2;
  state.currentPlayerIndex = ((state.currentPlayerIndex ?? 0) + 1) % count;
  state.turn = (state.turn ?? 1) + 1;
  state.die = null;
  state.movablePieceIds = [];
};
const applyLudoPiece = (state: GameState, pieceId: number, die: number) => {
  const pieces = state.ludoPieces ?? [];
  const piece = pieces.find((item) => item.id === pieceId);
  const playerIndex = state.currentPlayerIndex ?? 0;
  const player = state.players?.[playerIndex];
  if (!piece || piece.playerIndex !== playerIndex || !ludoMovable(state, playerIndex, die).some((item) => item.id === pieceId)) return false;
  piece.progress = piece.progress < 0 ? 0 : piece.progress + die;
  const absolute = ludoAbsoluteCell(piece.progress, playerIndex);
  let captured = 0;
  if (absolute >= 0 && !LUDO_SAFE_CELLS.includes(absolute as typeof LUDO_SAFE_CELLS[number])) {
    for (const rival of pieces) {
      if (rival.playerIndex !== playerIndex && ludoAbsoluteCell(rival.progress, rival.playerIndex) === absolute) { rival.progress = -1; captured += 1; }
    }
  }
  const finishedCount = pieces.filter((item) => item.playerIndex === playerIndex && item.progress === 58).length;
  const detail = piece.progress === 58 ? `${player?.name ?? "بازیکن"} یک مهره را به خانه پایانی رساند.` : captured ? `${player?.name ?? "بازیکن"} حرکت کرد و ${captured} مهره حریف را گرفت.` : `${player?.name ?? "بازیکن"} مهره ${piece.id % 4 + 1} را ${die} خانه حرکت داد.`;
  state.result = detail;
  state.die = null;
  state.movablePieceIds = [];
  if (finishedCount === 4) { state.finished = true; state.winnerIndex = playerIndex; state.won = playerIndex === 0; state.result = `${player?.name ?? "بازیکن"} هر چهار مهره را به خانه رساند و برنده شد.`; return true; }
  if (die !== 6) nextTurn(state);
  return true;
};
const rollLudoForCurrent = (state: GameState) => {
  const playerIndex = state.currentPlayerIndex ?? 0;
  const die = rollDie();
  const movable = ludoMovable(state, playerIndex, die);
  state.die = die;
  state.movablePieceIds = movable.map((piece) => piece.id);
  state.result = movable.length ? `${movable.length} مهره قابل حرکت است.` : "حرکت مجازی وجود ندارد؛ نوبت رد شد.";
  if (!movable.length) { state.die = null; if (die !== 6) nextTurn(state); }
};
const playLudoBots = (state: GameState) => {
  let guard = 0;
  while (!state.finished && (state.currentPlayerIndex ?? 0) !== 0 && guard < 36) {
    guard += 1;
    rollLudoForCurrent(state);
    const movable = state.movablePieceIds ?? [];
    const die = state.die;
    if (die && movable.length) {
      const pieces = state.ludoPieces ?? [];
      const preferred = movable.map((id) => pieces.find((piece) => piece.id === id)).filter((piece): piece is { id: number; playerIndex: number; progress: number } => !!piece).sort((a, b) => b.progress - a.progress)[0];
      if (preferred) applyLudoPiece(state, preferred.id, die);
    }
  }
};
const applySnakesTurn = (state: GameState) => {
  const playerIndex = state.currentPlayerIndex ?? 0;
  const player = state.players?.[playerIndex];
  const playerId = player?.id ?? null;
  const positions = state.snakePositions ?? [];
  const from = positions[playerIndex] ?? 0;
  const die = rollDie();
  const dieEvent: BoardEvent = { type: "die", playerIndex, playerId, value: die };
  state.eventQueue = [...(state.eventQueue ?? []), dieEvent];
  state.eventLog = [...(state.eventLog ?? []), dieEvent];
  let landing = from + die;
  let to = landing;
  let jump: "ladder" | "snake" | null = null;
  let detail = `${player?.name ?? "بازیکن"} تاس ${die} آورد.`;
  if (landing > 100) { landing = from; to = from; detail += " برای رسیدن دقیق به ۱۰۰ حرکت نکرد."; }
  else {
    const destination = SNAKES_AND_LADDERS[landing];
    if (destination !== undefined) { jump = destination > landing ? "ladder" : "snake"; detail += jump === "ladder" ? ` از نردبان ${landing} به ${destination} رفت.` : ` مار او را از ${landing} به ${destination} برگرداند.`; landing = destination; }
    else detail += ` از خانه ${from} به ${landing} رفت.`;
  }
  const moveEvent: BoardEvent = { type: "move", playerIndex, playerId, from, to, landing, jump };
  state.eventQueue = [...(state.eventQueue ?? []), moveEvent];
  state.eventLog = [...(state.eventLog ?? []), moveEvent];
  positions[playerIndex] = landing;
  state.snakePositions = positions;
  state.die = die;
  state.result = detail;
  if (landing === 100) { state.finished = true; state.winnerIndex = playerIndex; state.won = playerIndex === 0; state.result = `${player?.name ?? "بازیکن"} دقیقاً به خانه ۱۰۰ رسید و برنده شد.`; return; }
  if (die !== 6) nextTurn(state);
};
const playSnakesBots = (state: GameState) => {
  let guard = 0;
  while (!state.finished && (state.currentPlayerIndex ?? 0) !== 0 && guard < 36) { guard += 1; applySnakesTurn(state); }
};

async function persistBoardTurn(ctx: Ctx, session: typeof schema.gameSessions.$inferSelect, state: GameState, user: typeof schema.users.$inferSelect): Promise<typeof schema.users.$inferSelect> {
  const db = ctx.db<typeof schema>();
  await db.update(schema.gameSessions).set({ status: state.finished ? "finished" : "active", stateJson: JSON.stringify(state), updatedAt: new Date() }).where(eq(schema.gameSessions.id, session.id));
  if (!state.finished) return user;
  const reward = state.won ? Math.max(20, session.stake * 2) : 0;
  const xpGain = state.won ? 10 : 2;
  const nextUser = { ...user, coins: user.coins + reward, xp: user.xp + xpGain, wins: user.wins + (state.won ? 1 : 0) };
  await db.update(schema.users).set({ coins: nextUser.coins, xp: nextUser.xp, wins: nextUser.wins }).where(eq(schema.users.id, user.id));
  if (reward > 0) await db.insert(schema.transactions).values({ userId: user.id, amount: reward, kind: "game_reward", note: `جایزه بازی ${session.gameType}` });
  const finishedRoom = (await db.insert(schema.gameRooms).values({ gameType: session.gameType, hostId: user.id, status: "finished", stake: session.stake, winnerId: state.won ? user.id : null }).returning({ id: schema.gameRooms.id }))[0];
  if (finishedRoom) await db.insert(schema.scoreEvents).values({ userId: user.id, sourceType: "game", sourceId: finishedRoom.id, outcome: state.won ? "win" : "loss", points: xpGain }).onConflictDoNothing();
  return nextUser;
}

const stateSchema = z.object({
  current: userSchema,
  users: z.array(userSchema),
  stories: z.array(z.object({ id: z.number(), userId: z.number(), userName: z.string(), mediaType: z.enum(["image", "video"]), mediaUrl: z.string(), caption: z.string(), expiresAt: z.string(), createdAt: z.string(), viewCount: z.number(), viewedByMe: z.boolean(), isMine: z.boolean() })),
  dailyStories: z.array(z.object({ id: z.number(), userId: z.number(), userName: z.string(), mediaType: z.enum(["image", "video"]), mediaUrl: z.string(), caption: z.string(), expiresAt: z.string(), createdAt: z.string(), viewCount: z.number(), viewedByMe: z.boolean(), isMine: z.boolean() })),
  publicStories: z.array(z.object({ id: z.number(), userId: z.number(), userName: z.string(), mediaType: z.enum(["image", "video"]), mediaUrl: z.string(), caption: z.string(), expiresAt: z.string(), createdAt: z.string(), likeCount: z.number(), commentCount: z.number(), likedByMe: z.boolean(), followedByMe: z.boolean(), isMine: z.boolean() })),
  publicStoryComments: z.array(z.object({ id: z.number(), storyId: z.number(), userId: z.number(), userName: z.string(), text: z.string(), createdAt: z.string() })),
  requests: z.array(z.object({ id: z.number(), senderId: z.number(), receiverId: z.number(), status: z.string(), senderName: z.string(), receiverName: z.string(), message: z.string(), imageUrl: z.string().nullable() })), 
  conversations: z.array(z.object({ id: z.number(), kind: z.string(), name: z.string(), ownerId: z.number(), ownerName: z.string(), description: z.string(), imageUrl: z.string().nullable(), channelActivity: z.string(), confidential: z.boolean(), secretTimerMinutes: z.number(), isActive: z.boolean(), groupFund: z.number(), role: z.string().nullable(), following: z.boolean(), muted: z.boolean(), blocked: z.boolean(), memberCount: z.number() })),
  members: z.array(z.object({ conversationId: z.number(), userId: z.number(), name: z.string(), role: z.string() })),
  messages: z.array(z.object({ id: z.number(), conversationId: z.number(), senderId: z.number(), senderName: z.string(), senderRole: z.enum(["owner", "supervisor", "moderator", "superadmin", "admin", "member"]), type: z.string(), content: z.string(), replyToId: z.number().nullable(), replySenderName: z.string().nullable(), replyPreview: z.string().nullable(), reactions: z.array(z.object({ emoji: messageReactionSchema, count: z.number(), reactedByMe: z.boolean() })), expiresAt: z.string().nullable(), editedAt: z.string().nullable(), createdAt: z.string() })), 
  posts: z.array(z.object({ id: z.number(), conversationId: z.number(), authorId: z.number(), authorName: z.string(), text: z.string(), mediaType: z.enum(["voice", "image", "video"]).nullable(), mediaUrl: z.string().nullable(), replyToId: z.number().nullable(), replyAuthorName: z.string().nullable(), replyPreview: z.string().nullable(), likes: z.number(), comments: z.number(), createdAt: z.string() })),
  comments: z.array(z.object({ id: z.number(), postId: z.number(), userId: z.number(), userName: z.string(), text: z.string(), createdAt: z.string() })),
  gameAvatars: z.array(gameAvatarSchema),
  gameRecordings: z.array(z.object({ id: z.number(), gameType: gameTypeSchema, status: z.enum(["active", "finished"]), createdAt: z.string(), events: z.array(boardEventSchema), players: z.array(gamePlayerSchema), finalPositions: z.array(z.number()), result: z.string().nullable() })),
  games: z.array(z.object({
    id: z.number(), gameType: z.string(), hostId: z.number(), hostName: z.string(), status: z.string(), stake: z.number(), winnerId: z.number().nullable(), spectators: z.number(), favoriteTargetId: z.number().nullable(), favoriteName: z.string().nullable(), favoriteTeam: z.string().nullable(),
    currentRole: z.enum(["player", "spectator"]).nullable(), playerNames: z.array(z.string()),
    turnNumber: z.number(), hostChance: z.number(), commentary: z.string(), lastEvent: z.string(), hostMood: z.enum(["focused", "celebrate", "worried"]), guestMood: z.enum(["focused", "celebrate", "worried"]),
    cheers: z.array(z.object({ reaction: z.enum(["👏", "🔥", "❤️", "🎉"]), count: z.number() })), recentCheers: z.array(z.object({ id: z.number(), senderName: z.string(), reaction: z.enum(["👏", "🔥", "❤️", "🎉"]) })),
    voiceClips: z.array(z.object({ id: z.number(), senderId: z.number(), senderName: z.string(), senderRole: z.enum(["player", "spectator"]), audience: z.enum(["player_room", "spectator_room", "reward_announcement"]), url: z.string(), durationMs: z.number(), createdAt: z.string() })),
    giftEntries: z.array(z.object({ spectatorId: z.number(), spectatorName: z.string(), amount: z.number(), status: z.enum(["escrow", "released", "refunded"]), platformFee: z.number(), paidAmount: z.number() })),
    giftPool: z.number(), giftFee: z.number(), giftPayout: z.number(),
  })), 
  transactions: z.array(z.object({ id: z.number(), amount: z.number(), kind: z.string(), note: z.string(), createdAt: z.string() })),
  notices: z.array(z.object({ id: z.number(), title: z.string(), body: z.string(), pinned: z.boolean(), active: z.boolean() })),
  reports: z.array(z.object({ id: z.number(), reporterId: z.number(), reporterName: z.string(), subject: z.string(), status: z.string() })),
  groupScores: z.array(z.object({ id: z.number(), name: z.string(), points: z.number(), wins: z.number(), losses: z.number(), gamePoints: z.number(), betPoints: z.number(), memberNames: z.array(z.string()) })),
  playerScores: z.array(z.object({ id: z.number(), name: z.string(), groupName: z.string().nullable(), points: z.number(), wins: z.number(), losses: z.number(), gamePoints: z.number(), betPoints: z.number() })),
  scoreEventCount: z.number(),
  scheduledGames: z.array(z.object({ id: z.number(), title: z.string(), gameType: gameTypeSchema, groupId: z.number().nullable(), groupName: z.string().nullable(), hostId: z.number(), hostName: z.string(), startsAt: z.string(), status: z.enum(["scheduled", "live", "finished"]), myResponse: z.enum(["play", "watch"]).nullable(), playerCount: z.number(), watcherCount: z.number() })),
  adminAudit: z.array(z.object({ id: z.number(), adminName: z.string(), action: z.string(), targetType: z.string(), targetId: z.number().nullable(), summary: z.string(), createdAt: z.string() })),
  tournament: z.object({
    id: z.number(), title: z.string(), gameType: gameTypeSchema, entryFee: z.number(), prizePool: z.number(), status: z.enum(["registration", "live", "finished"]), championGroupId: z.number().nullable(), championGroupName: z.string().nullable(),
    registrations: z.array(z.object({ groupId: z.number(), groupName: z.string(), memberNames: z.array(z.string()) })),
    matches: z.array(z.object({ id: z.number(), homeGroupId: z.number(), homeGroupName: z.string(), awayGroupId: z.number(), awayGroupName: z.string(), status: z.enum(["scheduled", "live", "finished"]), winnerGroupId: z.number().nullable(), winnerGroupName: z.string().nullable(), gameRoomId: z.number().nullable() })),
  }).nullable(),
  currentGroupId: z.number().nullable(),
  recentActivity: z.array(z.object({ kind: z.enum(["message", "transaction", "game", "audit"]), label: z.string(), detail: z.string().nullable(), at: z.string() })),
  activeBattleCry: z.object({ id: z.number(), userId: z.number(), userName: z.string(), text: z.string(), expiresAt: z.string() }).nullable(),
  ambassador: z.object({ inviteCode: z.string(), referralCount: z.number(), rewardEarned: z.number(), hasRedeemedCode: z.boolean() }).nullable(),
  financialSafe: z.object({ configured: z.boolean(), lockedUntil: z.string().nullable() }),
  wheelSpunToday: z.boolean(),
  detectiveSolved: z.boolean(),
  quickDuelWon: z.boolean(),
  settings: z.object({ minAge: z.number(), dailyGift: z.number(), gameCommission: z.number(), dailyHangoutTime: z.string() }),
});

async function ensureScoreGroups(ctx: Ctx, allUsers: Array<typeof schema.users.$inferSelect>): Promise<void> {
  const db = ctx.db<typeof schema>();
  const players = allUsers.filter((user) => user.isTest && DEMO_PHONES.has(user.phone) && !user.isAdmin);
  const existingMemberships = await db.select().from(schema.scoreGroupMembers);
  const assignedIds = new Set(existingMemberships.map((row) => row.userId));
  const unassigned = players.filter((user) => !assignedIds.has(user.id));
  if (!unassigned.length) return;

  for (const user of unassigned) {
    const groupName = `گروه ${user.name}`;
    await db.insert(schema.scoreGroups).values({ name: groupName }).onConflictDoNothing();
    const group = (await db.select().from(schema.scoreGroups).where(eq(schema.scoreGroups.name, groupName)).limit(1))[0];
    if (group) await db.insert(schema.scoreGroupMembers).values({ groupId: group.id, userId: user.id }).onConflictDoNothing();
  }
}

async function ensureAmbassadorProfile(ctx: Ctx, userId: number): Promise<typeof schema.ambassadorProfiles.$inferSelect> {
  const db = ctx.db<typeof schema>();
  const existing = (await db.select().from(schema.ambassadorProfiles).where(eq(schema.ambassadorProfiles.userId, userId)).limit(1))[0];
  if (existing) return existing;
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const code = `HS-${userId.toString(36).toUpperCase()}-${crypto.randomUUID().replace(/-/g, "").slice(0, 6).toUpperCase()}`;
    const created = (await db.insert(schema.ambassadorProfiles).values({ userId, inviteCode: code }).onConflictDoNothing().returning())[0];
    if (created) return created;
  }
  const recovered = (await db.select().from(schema.ambassadorProfiles).where(eq(schema.ambassadorProfiles.userId, userId)).limit(1))[0];
  if (!recovered) throw new Error("Ambassador profile unavailable");
  return recovered;
}

async function loadState(ctx: Ctx, userId: number): Promise<z.infer<typeof stateSchema>> {
  const db = ctx.db<typeof schema>();
  const allUsers = await db.select().from(schema.users).orderBy(schema.users.id);
  await ensureScoreGroups(ctx, allUsers);
  // Test accounts can be recreated during earlier migrations, so a stale
  // browser session must not strand the whole artifact on the loading screen.
  // Fall back to the first active account; the response remains authoritative
  // and all later mutations use its real id.
  const current = allUsers.find((u) => u.id === userId && u.isActive);
  // Never substitute another account for a caller-supplied id. A stale or tampered
  // session must return to login instead of inheriting someone else's authority.
  if (!current) throw new Error("Account unavailable");
  const ambassadorProfile = current.accessRole === "user" ? await ensureAmbassadorProfile(ctx, current.id) : null;
  const ambassadorReferralRows = ambassadorProfile ? await db.select().from(schema.ambassadorReferrals).where(eq(schema.ambassadorReferrals.inviterId, current.id)) : [];
  const redeemedAmbassadorCode = ambassadorProfile ? (await db.select({ id: schema.ambassadorReferrals.id }).from(schema.ambassadorReferrals).where(eq(schema.ambassadorReferrals.inviteeId, current.id)).limit(1))[0] : null;
  const safePin = (await db.select().from(schema.financialSafePins).where(eq(schema.financialSafePins.userId, current.id)).limit(1))[0] ?? null;
  const nowDate = new Date();
  const expiredStoryRows = await db.select({ id: schema.profileStories.id }).from(schema.profileStories).where(lt(schema.profileStories.expiresAt, nowDate));
  if (expiredStoryRows.length) {
    const expiredIds = expiredStoryRows.map((story) => story.id);
    await db.delete(schema.profileStoryViews).where(inArray(schema.profileStoryViews.storyId, expiredIds));
    await db.delete(schema.profileStories).where(inArray(schema.profileStories.id, expiredIds));
  }
  const storyRows = await db.select().from(schema.profileStories).orderBy(desc(schema.profileStories.createdAt));
  const storyIds = storyRows.map((story) => story.id);
  const storyViewRows = storyIds.length ? await db.select().from(schema.profileStoryViews).where(inArray(schema.profileStoryViews.storyId, storyIds)) : [];
  const expiredDailyRows = await db.select({ id: schema.dailyStories.id }).from(schema.dailyStories).where(lt(schema.dailyStories.expiresAt, nowDate));
  if (expiredDailyRows.length) {
    const expiredIds = expiredDailyRows.map((story) => story.id);
    await db.delete(schema.dailyStoryViews).where(inArray(schema.dailyStoryViews.storyId, expiredIds));
    await db.delete(schema.dailyStories).where(inArray(schema.dailyStories.id, expiredIds));
  }
  const dailyStoryRows = await db.select().from(schema.dailyStories).orderBy(desc(schema.dailyStories.createdAt));
  const dailyStoryIds = dailyStoryRows.map((story) => story.id);
  const dailyViewRows = dailyStoryIds.length ? await db.select().from(schema.dailyStoryViews).where(inArray(schema.dailyStoryViews.storyId, dailyStoryIds)) : [];
  const expiredPublicRows = await db.select({ id: schema.publicStories.id }).from(schema.publicStories).where(lt(schema.publicStories.expiresAt, nowDate));
  if (expiredPublicRows.length) {
    const expiredIds = expiredPublicRows.map((story) => story.id);
    await db.delete(schema.publicStoryLikes).where(inArray(schema.publicStoryLikes.storyId, expiredIds));
    await db.delete(schema.publicStoryComments).where(inArray(schema.publicStoryComments.storyId, expiredIds));
    await db.delete(schema.publicStories).where(inArray(schema.publicStories.id, expiredIds));
  }
  const publicStoryRows = await db.select().from(schema.publicStories).orderBy(desc(schema.publicStories.createdAt));
  const publicStoryIds = publicStoryRows.map((story) => story.id);
  const publicLikeRows = publicStoryIds.length ? await db.select().from(schema.publicStoryLikes).where(inArray(schema.publicStoryLikes.storyId, publicStoryIds)) : [];
  const publicCommentRows = publicStoryIds.length ? await db.select().from(schema.publicStoryComments).where(inArray(schema.publicStoryComments.storyId, publicStoryIds)).orderBy(schema.publicStoryComments.id) : [];
  const followRows = await db.select().from(schema.userFollows);
  const reqRows = await db.select().from(schema.connectionRequests).where(or(eq(schema.connectionRequests.senderId, current.id), eq(schema.connectionRequests.receiverId, current.id))).orderBy(desc(schema.connectionRequests.id));
  const memberRows = await db.select().from(schema.memberships);
  const allConversationRows = await db.select().from(schema.conversations).orderBy(desc(schema.conversations.id));
  const convRows = current.accessRole === "management" ? allConversationRows : current.accessRole === "admin" ? allConversationRows.filter((conversation) => conversation.kind !== "private") : allConversationRows.filter((conversation) => conversation.isActive);
  const visibleIds = convRows.filter((c) => current.accessRole === "management" || (current.accessRole === "admin" && c.kind !== "private") || c.kind !== "private" || memberRows.some((m) => m.conversationId === c.id && m.userId === current.id)).map((c) => c.id);
  const msgRows = visibleIds.length ? await db.select().from(schema.messages).where(inArray(schema.messages.conversationId, visibleIds)).orderBy(desc(schema.messages.id)) : [];
  const visibleMessageIds = msgRows.map((message) => message.id);
  const reactionRows = visibleMessageIds.length ? await db.select().from(schema.messageReactions).where(inArray(schema.messageReactions.messageId, visibleMessageIds)) : [];
  const postRows = await db.select().from(schema.channelPosts).orderBy(desc(schema.channelPosts.id)).limit(30);
  const commentRows = await db.select().from(schema.channelComments).orderBy(desc(schema.channelComments.id)).limit(40);
  const avatarRows = await db.select().from(schema.playerGameAvatars).orderBy(desc(schema.playerGameAvatars.updatedAt));
  const gameRows = await db.select().from(schema.gameRooms).orderBy(desc(schema.gameRooms.id)).limit(12);
  const gameSessionRows = await db.select().from(schema.gameSessions).where(eq(schema.gameSessions.userId, current.id)).orderBy(desc(schema.gameSessions.id)).limit(12);
  const gameIds = gameRows.map((room) => room.id);
  const spectatorRows = await db.select().from(schema.gameSpectators).where(eq(schema.gameSpectators.userId, current.id));
  const voiceRows = gameIds.length ? await db.select().from(schema.liveVoiceClips).where(inArray(schema.liveVoiceClips.gameRoomId, gameIds)).orderBy(desc(schema.liveVoiceClips.id)) : [];
  const giftRows = gameIds.length ? await db.select().from(schema.spectatorGifts).where(inArray(schema.spectatorGifts.gameRoomId, gameIds)).orderBy(desc(schema.spectatorGifts.id)) : [];
  const cheerRows = gameIds.length ? await db.select().from(schema.gameCheers).where(inArray(schema.gameCheers.gameRoomId, gameIds)).orderBy(desc(schema.gameCheers.id)) : [];
  const txRows = current.accessRole === "admin" ? [] : await db.select().from(schema.transactions).where(eq(schema.transactions.userId, current.id)).orderBy(desc(schema.transactions.id)).limit(10);
  const activeBattleCryRow = (await db.select().from(schema.battleCries).where(gt(schema.battleCries.expiresAt, nowDate)).orderBy(desc(schema.battleCries.id)).limit(1))[0] ?? null;
  const dayKey = tehranDayKey(nowDate);
  const wheelSpinToday = (await db.select({ id: schema.dailyWheelSpins.id }).from(schema.dailyWheelSpins).where(and(eq(schema.dailyWheelSpins.userId, current.id), eq(schema.dailyWheelSpins.spinDay, dayKey))).limit(1))[0] ?? null;
  const solvedDetectiveAttempt = (await db.select({ id: schema.detectiveAttempts.id }).from(schema.detectiveAttempts).where(and(eq(schema.detectiveAttempts.userId, current.id), eq(schema.detectiveAttempts.caseKey, "club-safe-1"), eq(schema.detectiveAttempts.correct, true))).limit(1))[0] ?? null;
  const wonQuickDuel = (await db.select({ id: schema.quickDuels.id }).from(schema.quickDuels).where(and(eq(schema.quickDuels.userId, current.id), eq(schema.quickDuels.won, true))).limit(1))[0] ?? null;
  const noticeRows = await db.select().from(schema.notices).orderBy(desc(schema.notices.pinned), desc(schema.notices.id));
  const reportRows = current.accessRole !== "user" ? await db.select().from(schema.reports).orderBy(desc(schema.reports.id)) : [];
  const scoreGroupRows = await db.select().from(schema.scoreGroups).orderBy(schema.scoreGroups.id);
  const scoreMemberRows = await db.select().from(schema.scoreGroupMembers);
  const scoreEventRows = await db.select().from(schema.scoreEvents).orderBy(desc(schema.scoreEvents.id));
  const scheduledGameRows = await db.select().from(schema.scheduledGroupGames).orderBy(schema.scheduledGroupGames.startsAt).limit(12);
  const scheduledGameIds = scheduledGameRows.map((game) => game.id);
  const scheduledResponseRows = scheduledGameIds.length ? await db.select().from(schema.scheduledGameResponses).where(inArray(schema.scheduledGameResponses.scheduledGameId, scheduledGameIds)) : [];
  const auditRows = current.accessRole === "management" ? await db.select().from(schema.moderationAudit).orderBy(desc(schema.moderationAudit.id)).limit(40) : [];
  const currentTournament = (await db.select().from(schema.tournaments).orderBy(desc(schema.tournaments.id)).limit(1))[0] ?? null;
  const tournamentRegistrationRows = currentTournament ? await db.select().from(schema.tournamentRegistrations).where(eq(schema.tournamentRegistrations.tournamentId, currentTournament.id)) : [];
  const tournamentMatchRows = currentTournament ? await db.select().from(schema.tournamentMatches).where(eq(schema.tournamentMatches.tournamentId, currentTournament.id)).orderBy(schema.tournamentMatches.id) : [];
  const setting = (await db.select().from(schema.settings).limit(1))[0] ?? { id: 1, minAge: 18, dailyGift: 25, gameCommission: 30, dailyHangoutTime: "21:00" };
  const convNameOf = (id: number) => allConversationRows.find((c) => c.id === id)?.name ?? "گفتگو";
  const myMessageRows = await db.select().from(schema.messages).where(eq(schema.messages.senderId, current.id)).orderBy(desc(schema.messages.id)).limit(15);
  const mediaActivityLabel = (type: string) => type === "image" ? "تصویر" : type === "video" ? "فیلم" : type === "voice" ? "ویس" : "پیام";
  const recentActivity: z.infer<typeof stateSchema>["recentActivity"] = [
    ...myMessageRows.map((m) => ({
      kind: "message" as const,
      label: `پیام در ${convNameOf(m.conversationId)}`,
      detail: m.type === "text" || m.type === "system" ? (m.content.length > 70 ? `${m.content.slice(0, 70)}…` : m.content) : mediaActivityLabel(m.type),
      at: m.createdAt.toISOString(),
    })),
    ...txRows.map((t) => ({
      kind: "transaction" as const,
      label: t.note,
      detail: `${t.amount >= 0 ? "+" : ""}${t.amount} سکه`,
      at: t.createdAt.toISOString(),
    })),
    ...gameRows.filter((g) => g.hostId === current.id).map((g) => ({
      kind: "game" as const,
      label: `میزبانی ${g.gameType}`,
      detail: g.status === "live" ? `زنده · ورودی ${g.stake} سکه` : `پایان‌یافته · ورودی ${g.stake} سکه`,
      at: g.createdAt.toISOString(),
    })),
    ...auditRows.map((row) => ({
      kind: "audit" as const,
      label: row.summary,
      detail: null as string | null,
      at: row.createdAt.toISOString(),
    })),
  ].sort((a, b) => (a.at < b.at ? 1 : -1)).slice(0, 30);
  const nameOf = (id: number) => allUsers.find((u) => u.id === id)?.name ?? "کاربر";
  const groupNameOf = (userIdValue: number) => { const membership = scoreMemberRows.find((row) => row.userId === userIdValue); return membership ? (scoreGroupRows.find((group) => group.id === membership.groupId)?.name ?? null) : null; };
  const playerScores = allUsers.filter((u) => u.isTest && DEMO_PHONES.has(u.phone) && !u.isAdmin).map((u) => {
    const events = scoreEventRows.filter((event) => event.userId === u.id);
    return { id: u.id, name: u.name, groupName: groupNameOf(u.id), points: events.reduce((sum, event) => sum + event.points, 0), wins: events.filter((event) => event.outcome === "win").length, losses: events.filter((event) => event.outcome === "loss").length, gamePoints: events.filter((event) => event.sourceType === "game").reduce((sum, event) => sum + event.points, 0), betPoints: events.filter((event) => event.sourceType === "bet").reduce((sum, event) => sum + event.points, 0) };
  }).sort((a, b) => b.points - a.points || b.wins - a.wins || a.id - b.id);
  const groupScores = scoreGroupRows.map((group) => {
    const ids = scoreMemberRows.filter((member) => member.groupId === group.id).map((member) => member.userId);
    const rows = playerScores.filter((player) => ids.includes(player.id));
    return { id: group.id, name: group.name, points: rows.reduce((sum, player) => sum + player.points, 0), wins: rows.reduce((sum, player) => sum + player.wins, 0), losses: rows.reduce((sum, player) => sum + player.losses, 0), gamePoints: rows.reduce((sum, player) => sum + player.gamePoints, 0), betPoints: rows.reduce((sum, player) => sum + player.betPoints, 0), memberNames: rows.map((player) => player.name) };
  }).sort((a, b) => b.points - a.points || b.wins - a.wins || a.id - b.id);
  const now = Date.now();
  const unexpiredMessages = msgRows.filter((message) => !message.expiresAt || message.expiresAt.getTime() > now);
  const messageById = new Map(unexpiredMessages.map((message) => [message.id, message]));
  const postById = new Map(postRows.map((post) => [post.id, post]));
  const mediaLabel = (type: string) => type === "image" ? "تصویر" : type === "video" ? "فیلم" : type === "voice" ? "ویس" : "پیام";
  const resolvedMessages = await Promise.all(unexpiredMessages.reverse().map(async (m) => {
    const replied = m.replyToId ? messageById.get(m.replyToId) : undefined;
    const reactions = new Map<z.infer<typeof messageReactionSchema>, { count: number; reactedByMe: boolean }>();
    for (const row of reactionRows.filter((reaction) => reaction.messageId === m.id)) {
      const parsedEmoji = messageReactionSchema.safeParse(row.emoji);
      if (!parsedEmoji.success) continue;
      const currentReaction = reactions.get(parsedEmoji.data) ?? { count: 0, reactedByMe: false };
      reactions.set(parsedEmoji.data, { count: currentReaction.count + 1, reactedByMe: currentReaction.reactedByMe || row.userId === current.id });
    }
    return { id: m.id, conversationId: m.conversationId, senderId: m.senderId, senderName: nameOf(m.senderId), senderRole: memberRows.find((member) => member.conversationId === m.conversationId && member.userId === m.senderId)?.role ?? "member", type: m.type !== "text" && m.type !== "system" && !m.content.startsWith("messages/") ? "system" : m.type, content: m.type === "text" || m.type === "system" ? m.content : m.content.startsWith("messages/") ? await ctx.blobs.getUrl(m.content) : "رسانه نامعتبر حذف شد", replyToId: m.replyToId ?? null, replySenderName: replied ? nameOf(replied.senderId) : null, replyPreview: replied ? (replied.type === "text" || replied.type === "system" ? replied.content.slice(0, 90) : mediaLabel(replied.type)) : null, reactions: [...reactions.entries()].map(([emoji, reaction]) => ({ emoji, ...reaction })), expiresAt: m.expiresAt?.toISOString() ?? null, editedAt: m.editedAt?.toISOString() ?? null, createdAt: m.createdAt.toISOString() };
  }));
  return {
    current: { ...current, phone: "", coins: current.accessRole === "admin" ? 0 : current.coins, twoFactorEnabled: current.accessRole === "admin" ? false : current.twoFactorEnabled, interests: parseInterests(current.interests), lastGiftDay: current.lastGiftDay ?? null },
    users: allUsers.filter((u) => u.isActive).map((u) => ({ ...u, phone: "", coins: current.accessRole === "admin" ? 0 : u.coins, twoFactorEnabled: current.accessRole === "admin" ? false : u.twoFactorEnabled, interests: parseInterests(u.interests), lastGiftDay: u.lastGiftDay ?? null })),
    stories: await Promise.all(storyRows.map(async (story) => ({ id: story.id, userId: story.userId, userName: nameOf(story.userId), mediaType: story.mediaType, mediaUrl: await ctx.blobs.getUrl(story.mediaBlobKey), caption: story.caption, expiresAt: story.expiresAt.toISOString(), createdAt: story.createdAt.toISOString(), viewCount: storyViewRows.filter((view) => view.storyId === story.id).length, viewedByMe: storyViewRows.some((view) => view.storyId === story.id && view.viewerId === current.id), isMine: story.userId === current.id }))),
    dailyStories: await Promise.all(dailyStoryRows.map(async (story) => ({ id: story.id, userId: story.userId, userName: nameOf(story.userId), mediaType: story.mediaType, mediaUrl: await ctx.blobs.getUrl(story.mediaBlobKey), caption: story.caption, expiresAt: story.expiresAt.toISOString(), createdAt: story.createdAt.toISOString(), viewCount: dailyViewRows.filter((view) => view.storyId === story.id).length, viewedByMe: dailyViewRows.some((view) => view.storyId === story.id && view.viewerId === current.id), isMine: story.userId === current.id }))),
    publicStories: await Promise.all(publicStoryRows.map(async (story) => ({ id: story.id, userId: story.userId, userName: nameOf(story.userId), mediaType: story.mediaType, mediaUrl: await ctx.blobs.getUrl(story.mediaBlobKey), caption: story.caption, expiresAt: story.expiresAt.toISOString(), createdAt: story.createdAt.toISOString(), likeCount: publicLikeRows.filter((like) => like.storyId === story.id).length, commentCount: publicCommentRows.filter((comment) => comment.storyId === story.id).length, likedByMe: publicLikeRows.some((like) => like.storyId === story.id && like.userId === current.id), followedByMe: followRows.some((follow) => follow.followerId === current.id && follow.followedId === story.userId), isMine: story.userId === current.id }))),
    publicStoryComments: publicCommentRows.map((comment) => ({ id: comment.id, storyId: comment.storyId, userId: comment.userId, userName: nameOf(comment.userId), text: comment.text, createdAt: comment.createdAt.toISOString() })),
    requests: await Promise.all(reqRows.map(async (r) => ({ id: r.id, senderId: r.senderId, receiverId: r.receiverId, status: r.status, senderName: nameOf(r.senderId), receiverName: nameOf(r.receiverId), message: r.message, imageUrl: r.imageBlobKey ? await ctx.blobs.getUrl(r.imageBlobKey) : null }))),
    conversations: await Promise.all(convRows.filter((c) => current.accessRole === "management" || visibleIds.includes(c.id) || c.kind !== "private").map(async (c) => { const own = memberRows.find((m) => m.conversationId === c.id && m.userId === current.id); return { id: c.id, kind: c.kind, name: c.name, ownerId: c.ownerId, ownerName: nameOf(c.ownerId), description: c.description, imageUrl: c.imageBlobKey ? await ctx.blobs.getUrl(c.imageBlobKey) : null, channelActivity: c.channelActivity, confidential: c.confidential, secretTimerMinutes: c.secretTimerMinutes, isActive: c.isActive, groupFund: c.groupFund, role: own?.role ?? null, following: own?.following ?? false, muted: own?.muted ?? false, blocked: own?.blocked ?? false, memberCount: memberRows.filter((m) => m.conversationId === c.id).length }; })),
    members: memberRows.map((m) => ({ conversationId: m.conversationId, userId: m.userId, name: nameOf(m.userId), role: m.role })),
    messages: resolvedMessages,
    posts: await Promise.all(postRows.map(async (p) => { const replied = p.replyToId ? postById.get(p.replyToId) : undefined; return { id: p.id, conversationId: p.conversationId, authorId: p.authorId, authorName: nameOf(p.authorId), text: p.text, mediaType: p.mediaType ?? null, mediaUrl: p.mediaBlobKey ? await ctx.blobs.getUrl(p.mediaBlobKey) : null, replyToId: p.replyToId ?? null, replyAuthorName: replied ? nameOf(replied.authorId) : null, replyPreview: replied ? (replied.text || (replied.mediaType ? mediaLabel(replied.mediaType) : "مطلب")) : null, likes: p.likes, comments: p.comments, createdAt: p.createdAt.toISOString() }; })),
    comments: commentRows.map((c) => ({ id: c.id, postId: c.postId, userId: c.userId, userName: nameOf(c.userId), text: c.text, createdAt: c.createdAt.toISOString() })),
    gameAvatars: avatarRows.map((avatar) => ({ userId: avatar.userId, userName: nameOf(avatar.userId), face: avatar.face, hair: avatar.hair, outfit: avatar.outfit, accent: avatar.accent, emblem: avatar.emblem, updatedAt: avatar.updatedAt.toISOString() })),
    gameRecordings: gameSessionRows.flatMap((recording) => {
      try {
        const state = JSON.parse(recording.stateJson) as GameState;
        const parsedEvents = z.array(boardEventSchema).safeParse(state.eventLog ?? []);
        if (!parsedEvents.success || !parsedEvents.data.length) return [];
        return [{ id: recording.id, gameType: normalizeGameType(recording.gameType), status: recording.status, createdAt: recording.createdAt.toISOString(), events: parsedEvents.data, players: state.players ?? [], finalPositions: state.snakePositions ?? [], result: state.result }];
      } catch { return []; }
    }),
    games: await Promise.all(gameRows.map(async (g) => {
      const spectator = spectatorRows.find((s) => s.gameRoomId === g.id);
      const tournamentMatch = tournamentMatchRows.find((match) => match.gameRoomId === g.id);
      const awayPlayerId = tournamentMatch ? scoreMemberRows.find((member) => member.groupId === tournamentMatch.awayGroupId)?.userId : undefined;
      const fallbackGuestId = allUsers.find((candidate) => candidate.isTest && DEMO_PHONES.has(candidate.phone) && !candidate.isAdmin && candidate.id !== g.hostId)?.id;
      const playerIds = [g.hostId, awayPlayerId ?? fallbackGuestId].filter((id): id is number => typeof id === "number");
      const currentRole = playerIds.includes(current.id) ? "player" as const : spectator ? "spectator" as const : null;
      const visibleVoiceRows = voiceRows.filter((clip) => clip.gameRoomId === g.id && (
        currentRole === "spectator" ||
        (currentRole === "player" && (clip.senderRole === "player" || clip.audience === "reward_announcement"))
      )).slice(0, 8).reverse();
      const roomGifts = giftRows.filter((gift) => gift.gameRoomId === g.id);
      const roomCheers = cheerRows.filter((cheer) => cheer.gameRoomId === g.id);
      const cheerTypes = ["👏", "🔥", "❤️", "🎉"] as const;
      return {
        id: g.id, gameType: g.gameType, hostId: g.hostId, hostName: nameOf(g.hostId), status: g.status, stake: g.stake, winnerId: g.winnerId ?? null, spectators: g.spectators,
        favoriteTargetId: spectator?.favoriteUserId ?? null, favoriteName: spectator?.favoriteUserId ? nameOf(spectator.favoriteUserId) : null, favoriteTeam: spectator?.favoriteTeam ?? null,
        currentRole, playerNames: playerIds.map(nameOf), turnNumber: g.turnNumber, hostChance: g.hostChance, commentary: g.commentary, lastEvent: g.lastEvent, hostMood: g.hostMood, guestMood: g.guestMood,
        cheers: cheerTypes.map((reaction) => ({ reaction, count: roomCheers.filter((cheer) => cheer.reaction === reaction).length })), recentCheers: roomCheers.slice(0, 8).map((cheer) => ({ id: cheer.id, senderName: nameOf(cheer.senderId), reaction: cheer.reaction })),
        voiceClips: await Promise.all(visibleVoiceRows.map(async (clip) => ({ id: clip.id, senderId: clip.senderId, senderName: nameOf(clip.senderId), senderRole: clip.senderRole, audience: clip.audience, url: await ctx.blobs.getUrl(clip.blobKey), durationMs: clip.durationMs, createdAt: clip.createdAt.toISOString() }))),
        giftEntries: roomGifts.map((gift) => ({ spectatorId: gift.spectatorId, spectatorName: nameOf(gift.spectatorId), amount: gift.amount, status: gift.status, platformFee: gift.platformFee, paidAmount: gift.paidAmount })),
        giftPool: roomGifts.reduce((sum, gift) => sum + gift.amount, 0), giftFee: roomGifts.reduce((sum, gift) => sum + (gift.status === "escrow" ? Math.floor(gift.amount * 0.3) : gift.platformFee), 0), giftPayout: roomGifts.reduce((sum, gift) => sum + (gift.status === "escrow" ? gift.amount - Math.floor(gift.amount * 0.3) : gift.paidAmount), 0),
      };
    })), 
    transactions: txRows.map((t) => ({ id: t.id, amount: t.amount, kind: t.kind, note: t.note, createdAt: t.createdAt.toISOString() })),
    notices: noticeRows.filter((n) => n.title !== "تست چندنفره آماده است").map((n) => ({ id: n.id, title: n.title, body: n.body, pinned: n.pinned, active: n.active })),
    reports: reportRows.map((r) => ({ id: r.id, reporterId: r.reporterId, reporterName: nameOf(r.reporterId), subject: r.subject, status: r.status })),
    groupScores,
    playerScores,
    scoreEventCount: scoreEventRows.length,
    scheduledGames: scheduledGameRows.map((game) => {
      const responses = scheduledResponseRows.filter((response) => response.scheduledGameId === game.id);
      const group = game.groupId ? allConversationRows.find((conversation) => conversation.id === game.groupId) : null;
      return { id: game.id, title: game.title, gameType: normalizeGameType(game.gameType), groupId: game.groupId ?? null, groupName: group?.name ?? null, hostId: game.hostId, hostName: nameOf(game.hostId), startsAt: game.startsAt.toISOString(), status: game.status, myResponse: responses.find((response) => response.userId === current.id)?.response ?? null, playerCount: responses.filter((response) => response.response === "play").length, watcherCount: responses.filter((response) => response.response === "watch").length };
    }),
    adminAudit: auditRows.map((row) => ({ id: row.id, adminName: nameOf(row.adminId), action: row.action, targetType: row.targetType, targetId: row.targetId ?? null, summary: row.summary, createdAt: row.createdAt.toISOString() })),
    tournament: currentTournament ? {
      id: currentTournament.id,
      title: currentTournament.title,
      gameType: normalizeGameType(currentTournament.gameType),
      entryFee: currentTournament.entryFee,
      prizePool: currentTournament.prizePool,
      status: currentTournament.status,
      championGroupId: currentTournament.championGroupId ?? null,
      championGroupName: currentTournament.championGroupId ? (scoreGroupRows.find((group) => group.id === currentTournament.championGroupId)?.name ?? null) : null,
      registrations: tournamentRegistrationRows.map((registration) => ({ groupId: registration.groupId, groupName: scoreGroupRows.find((group) => group.id === registration.groupId)?.name ?? "گروه", memberNames: scoreMemberRows.filter((member) => member.groupId === registration.groupId).map((member) => nameOf(member.userId)) })),
      matches: tournamentMatchRows.map((match) => ({ id: match.id, homeGroupId: match.homeGroupId, homeGroupName: scoreGroupRows.find((group) => group.id === match.homeGroupId)?.name ?? "گروه میزبان", awayGroupId: match.awayGroupId, awayGroupName: scoreGroupRows.find((group) => group.id === match.awayGroupId)?.name ?? "گروه مهمان", status: match.status, winnerGroupId: match.winnerGroupId ?? null, winnerGroupName: match.winnerGroupId ? (scoreGroupRows.find((group) => group.id === match.winnerGroupId)?.name ?? null) : null, gameRoomId: match.gameRoomId ?? null })),
    } : null,
    currentGroupId: scoreMemberRows.find((member) => member.userId === current.id)?.groupId ?? null,
    recentActivity,
    activeBattleCry: activeBattleCryRow ? { id: activeBattleCryRow.id, userId: activeBattleCryRow.userId, userName: allUsers.find((user) => user.id === activeBattleCryRow.userId)?.name ?? "بازیکن", text: activeBattleCryRow.text, expiresAt: activeBattleCryRow.expiresAt.toISOString() } : null,
    ambassador: ambassadorProfile ? { inviteCode: ambassadorProfile.inviteCode, referralCount: ambassadorReferralRows.length, rewardEarned: ambassadorReferralRows.reduce((sum, referral) => sum + referral.reward, 0), hasRedeemedCode: redeemedAmbassadorCode !== null && redeemedAmbassadorCode !== undefined } : null,
    financialSafe: { configured: safePin !== null, lockedUntil: safePin?.lockedUntil && safePin.lockedUntil.getTime() > Date.now() ? safePin.lockedUntil.toISOString() : null },
    wheelSpunToday: wheelSpinToday !== null,
    detectiveSolved: solvedDetectiveAttempt !== null,
    quickDuelWon: wonQuickDuel !== null,
    settings: { minAge: setting.minAge, dailyGift: setting.dailyGift, gameCommission: setting.gameCommission, dailyHangoutTime: setting.dailyHangoutTime },
  };
}

async function liveRoomPlayers(ctx: Ctx, gameRoomId: number, hostId: number): Promise<number[]> {
  const db = ctx.db<typeof schema>();
  const match = (await db.select().from(schema.tournamentMatches).where(eq(schema.tournamentMatches.gameRoomId, gameRoomId)).limit(1))[0];
  if (match) {
    const awayMember = (await db.select().from(schema.scoreGroupMembers).where(eq(schema.scoreGroupMembers.groupId, match.awayGroupId)).limit(1))[0];
    return [hostId, ...(awayMember ? [awayMember.userId] : [])];
  }
  const candidates = (await db.select().from(schema.users)).filter((candidate) => candidate.isTest && DEMO_PHONES.has(candidate.phone) && !candidate.isAdmin && candidate.id !== hostId);
  return [hostId, ...(candidates[0] ? [candidates[0].id] : [])];
}

async function settleGiftEscrow(ctx: Ctx, gameRoomId: number, winnerId: number): Promise<{ count: number; gross: number; fee: number; payout: number }> {
  const db = ctx.db<typeof schema>();
  const gifts = await db.select().from(schema.spectatorGifts).where(and(eq(schema.spectatorGifts.gameRoomId, gameRoomId), eq(schema.spectatorGifts.status, "escrow")));
  let gross = 0; let fee = 0; let payout = 0;
  for (const gift of gifts) {
    const itemFee = Math.floor(gift.amount * 0.3);
    const itemPayout = gift.amount - itemFee;
    gross += gift.amount; fee += itemFee; payout += itemPayout;
    await db.update(schema.spectatorGifts).set({ status: "released", platformFee: itemFee, paidAmount: itemPayout, settledAt: new Date() }).where(eq(schema.spectatorGifts.id, gift.id));
  }
  if (payout > 0) {
    const winner = (await db.select().from(schema.users).where(eq(schema.users.id, winnerId)).limit(1))[0];
    if (winner) {
      await db.update(schema.users).set({ coins: winner.coins + payout }).where(eq(schema.users.id, winner.id));
      await db.insert(schema.transactions).values({ userId: winner.id, amount: payout, kind: "spectator_gift_payout", note: `هدیه تماشاچیان میز ${gameRoomId} پس از کسر ۳۰٪` });
    }
  }
  return { count: gifts.length, gross, fee, payout };
}

const dailyHangoutTitles = ["پرسش صمیمی", "بازی شناخت", "صندلی داغ", "چالش دونفره", "قصه و موسیقی", "شب مافیا", "حال خوب"] as const;

export const Actions = {
  startDailyHangout: defineAction({
    request: z.object({}),
    response: okSchema,
    async handler(ctx): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const hangout = (await db.select().from(schema.conversations).where(and(eq(schema.conversations.kind, "group"), eq(schema.conversations.name, "دورهمی"))).limit(1))[0];
      if (!hangout) return { ok: true, message: "اتاق دورهمی هنوز ساخته نشده است" };
      const owner = (await db.select().from(schema.users).where(eq(schema.users.id, hangout.ownerId)).limit(1))[0];
      if (!owner) return { ok: true, message: "مدیر اتاق دورهمی پیدا نشد" };
      const program = dailyHangoutTitles[new Date().getDay()] ?? dailyHangoutTitles[0];
      await db.insert(schema.messages).values({ conversationId: hangout.id, senderId: owner.id, type: "system", content: `برنامه امشب آغاز شد: ${program} — وارد گفتگو شوید و همراه جمع باشید.` });
      ctx.invalidateQueries();
      return { ok: true, message: `برنامه «${program}» در اتاق دورهمی آغاز شد` };
    },
  }),

  seedDemo: defineAction({
    request: z.object({}), response: z.object({ ok: z.literal(true), userId: z.number() }),
    async handler(ctx): Promise<{ ok: true; userId: number }> {
      const db = ctx.db<typeof schema>();
      const seeds = [
        { phone: "09000000001", name: "آوا", age: 27, gender: "زن", city: "تهران", bio: "اهل موسیقی، سفر و گفتگو", coins: 820, xp: 62, wins: 4, isTest: true },
        { phone: "09000000002", name: "نیما", age: 30, gender: "مرد", city: "شیراز", bio: "علاقه‌مند به بازی و طبیعت", coins: 690, xp: 48, wins: 3, isTest: true },
        { phone: "09000000003", name: "کیان", age: 29, gender: "مرد", city: "رشت", bio: "کتاب، کافه و فیلم", coins: 540, xp: 31, wins: 2, isTest: true },
        { phone: "09999999998", name: "ادمین آزمایشی", age: 32, gender: "نامشخص", city: "مرکز", bio: "حساب ادمین محتوا", coins: 5000, xp: 0, wins: 0, isTest: true, isAdmin: true, accessRole: "admin" as const },
        { phone: "09999999999", name: "مدیریت آزمایشی", age: 35, gender: "نامشخص", city: "مرکز", bio: "حساب مدیریت کل", coins: 9999, xp: 0, wins: 0, isTest: true, isAdmin: true, accessRole: "management" as const },
      ];
      for (const row of seeds) await db.insert(schema.users).values(row).onConflictDoNothing();
      await db.insert(schema.settings).values({ id: 1, minAge: 18, dailyGift: 25, gameCommission: 30 }).onConflictDoNothing();
      const users = await db.select().from(schema.users).orderBy(schema.users.id);
      const ava = users.find((u) => u.name === "آوا") ?? users[0]; const nima = users.find((u) => u.name === "نیما") ?? users[1]; const kian = users.find((u) => u.name === "کیان") ?? users[2];
      if (!ava || !nima || !kian) throw new Error("Seed users unavailable");
      await ensureScoreGroups(ctx, users);
      const existingConvs = await db.select().from(schema.conversations);
      if (!existingConvs.length) {
        const created = await db.insert(schema.conversations).values([
          { kind: "group", name: "گپ شبانه", ownerId: ava.id, description: "گفتگوی آزاد اعضای تست" },
          { kind: "channel", name: "اخبار همسفر", ownerId: nima.id, description: "اطلاعیه‌ها و رویدادهای جامعه" },
          { kind: "private", name: "آوا و نیما", ownerId: ava.id, description: "گفتگوی خصوصی پس از پذیرش درخواست", confidential: false },
        ]).returning({ id: schema.conversations.id, kind: schema.conversations.kind });
        for (const c of created) {
          const memberIds = c.kind === "private" ? [ava.id, nima.id] : [ava.id, nima.id, kian.id];
          await db.insert(schema.memberships).values(memberIds.map((id, index) => ({ conversationId: c.id, userId: id, role: index === 0 ? "owner" as const : "member" as const, following: c.kind === "channel" })));
        }
        const privateConv = created.find((c) => c.kind === "private"); const groupConv = created.find((c) => c.kind === "group"); const channelConv = created.find((c) => c.kind === "channel");
        if (privateConv) await db.insert(schema.messages).values([{ conversationId: privateConv.id, senderId: ava.id, content: "سلام نیما، برای تست چت آماده‌ای؟" }, { conversationId: privateConv.id, senderId: nima.id, content: "آره، پیام‌ها روی سرور ذخیره می‌شن." }]);
        if (groupConv) await db.insert(schema.messages).values([{ conversationId: groupConv.id, senderId: kian.id, content: "امشب بازی مافیا داریم." }, { conversationId: groupConv.id, senderId: ava.id, type: "text", content: "برای هماهنگی، پیام‌ها را همین‌جا بفرستید." }]);
        if (channelConv) await db.insert(schema.channelPosts).values({ conversationId: channelConv.id, authorId: nima.id, text: "دورهمی آزمایشی مافیا امشب؛ برای ورود به اتاق بازی آماده باشید.", likes: 2, comments: 1 });
      }
      const hangout = (await db.select().from(schema.conversations).where(and(eq(schema.conversations.kind, "group"), eq(schema.conversations.name, "دورهمی"))).limit(1))[0]
        ?? (await db.insert(schema.conversations).values({ kind: "group", name: "دورهمی", ownerId: ava.id, description: "اتاق برنامه روزانه؛ هر شب در ساعت تعیین‌شده فعال می‌شود" }).returning())[0];
      if (hangout) {
        for (const user of users.filter((candidate) => candidate.isTest && DEMO_PHONES.has(candidate.phone))) {
          await db.insert(schema.memberships).values({ conversationId: hangout.id, userId: user.id, role: user.id === ava.id ? "owner" : "member" }).onConflictDoNothing();
        }
        const hangoutMessages = await db.select().from(schema.messages).where(eq(schema.messages.conversationId, hangout.id)).limit(1);
        if (!hangoutMessages.length) await db.insert(schema.messages).values({ conversationId: hangout.id, senderId: ava.id, type: "system", content: "به دورهمی خوش آمدید؛ برنامه هر شب سر ساعت شروع می‌شود." });
      }
      const existingNotices = await db.select().from(schema.notices);
      if (!existingNotices.length) await db.insert(schema.notices).values([{ title: "تست چندنفره آماده است", body: "با نوار حساب‌ها بین آوا، نیما و کیان جابه‌جا شوید.", pinned: true }, { title: "هدیه روزانه", body: "امروز هدیه سکه را از کیف پول دریافت کنید." }]);
      const existingReq = await db.select().from(schema.connectionRequests);
      if (!existingReq.length) await db.insert(schema.connectionRequests).values({ senderId: kian.id, receiverId: ava.id, status: "pending" });
      const games = await db.select().from(schema.gameRooms);
      if (!games.length) await db.insert(schema.gameRooms).values({ gameType: "مافیا", hostId: nima.id, status: "live", stake: 40, spectators: 2 });
      const scheduled = await db.select().from(schema.scheduledGroupGames).limit(1);
      if (!scheduled.length) {
        const group = (await db.select().from(schema.conversations).where(eq(schema.conversations.kind, "group")).orderBy(schema.conversations.id).limit(1))[0];
        const base = Date.now();
        await db.insert(schema.scheduledGroupGames).values([
          { title: "نبرد گروهی مافیا", gameType: "مافیا", groupId: group?.id ?? null, hostId: nima.id, startsAt: new Date(base + 45 * 60_000), status: "scheduled" },
          { title: "چالش گروهی حکم", gameType: "حکم", groupId: group?.id ?? null, hostId: ava.id, startsAt: new Date(base + 3 * 60 * 60_000), status: "scheduled" },
        ]);
      }
      ctx.invalidateQueries(); return { ok: true, userId: ava.id };
    },
  }),

  getState: defineAction({ request: z.object({ userId: z.number().int().positive() }), response: stateSchema, async handler(ctx, args) { return loadState(ctx, args.userId); } }),

  loginPhone: defineAction({
    request: z.object({ phone: z.string().min(7), code: z.literal("1234") }),
    response: z.object({ ok: z.boolean(), userId: z.number().nullable(), message: z.string() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const user = (await db.select().from(schema.users).where(eq(schema.users.phone, args.phone.trim())).limit(1))[0];
      if (!user) return { ok: false, userId: null, message: "حسابی با این شماره پیدا نشد" };
      if (!user.isActive) return { ok: false, userId: null, message: "این حساب فعال نیست" };
      return { ok: true, userId: user.id, message: "ورود با موفقیت انجام شد" };
    },
  }),

  verifyPhone: defineAction({
    request: z.object({ phone: z.string().min(7), code: z.literal("1234"), name: z.string().min(2).max(40), maritalStatus: z.enum(["مجرد", "متأهل"]), interests: interestsSchema }),
    response: z.object({ userId: z.number() }),
    async handler(ctx, args) {
      const db = ctx.db<typeof schema>();
      const interests = JSON.stringify(args.interests);
      const found = (await db.select().from(schema.users).where(eq(schema.users.phone, args.phone)).limit(1))[0];
      if (found) {
        await db.update(schema.users).set({ name: args.name, maritalStatus: args.maritalStatus, interests, isActive: true }).where(eq(schema.users.id, found.id));
        ctx.invalidateQueries();
        return { userId: found.id };
      }
      const result = await db.insert(schema.users).values({ phone: args.phone, name: args.name, maritalStatus: args.maritalStatus, interests, isTest: false }).returning({ id: schema.users.id });
      const row = result[0];
      if (!row) throw new Error("User creation failed");
      ctx.invalidateQueries();
      return { userId: row.id };
    },
  }),

  updateProfile: defineAction({
    request: z.object({ userId: z.number(), name: z.string().min(2).max(40), age: z.number().int().min(18).max(99), gender: z.string().max(20), maritalStatus: z.enum(["مجرد", "متأهل", "نامشخص"]), city: z.string().max(40), bio: z.string().max(180), interests: interestsSchema }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      await db.update(schema.users).set({ name: args.name, age: args.age, gender: args.gender, maritalStatus: args.maritalStatus, city: args.city, bio: args.bio, interests: JSON.stringify(args.interests) }).where(eq(schema.users.id, args.userId));
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  createProfileStory: defineAction({
    request: z.object({
      userId: z.number().int().positive(),
      caption: z.string().trim().max(160),
      mediaType: z.enum(["image", "video"]),
      dataBase64: z.string().min(1),
      mimeType: z.enum(["image/jpeg", "image/png", "image/webp", "video/mp4", "video/webm"]),
      filename: z.string().min(1).max(100),
    }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      if (!user || !user.isActive) return { ok: true, message: "حساب فعال پیدا نشد" };
      if ((args.mediaType === "image") !== args.mimeType.startsWith("image/")) return { ok: true, message: "نوع رسانه با فایل هماهنگ نیست" };
      const binary = Uint8Array.from(atob(args.dataBase64), (char) => char.charCodeAt(0));
      if (binary.byteLength > 8 * 1024 * 1024) return { ok: true, message: "حجم استوری باید کمتر از ۸ مگابایت باشد" };
      const safeName = args.filename.replace(/[^a-zA-Z0-9._-]/g, "_");
      const key = `stories/${args.userId}/${Date.now()}-${safeName}`;
      await ctx.blobs.put(key, binary, { contentType: args.mimeType });
      await db.insert(schema.profileStories).values({ userId: user.id, mediaType: args.mediaType, mediaBlobKey: key, caption: args.caption, expiresAt: new Date(Date.now() + 24 * 60 * 60_000) });
      ctx.invalidateQueries();
      return { ok: true, message: "استوری تا ۲۴ ساعت روی پروفایل شما نمایش داده می‌شود" };
    },
  }),

  viewProfileStory: defineAction({
    request: z.object({ storyId: z.number().int().positive(), viewerId: z.number().int().positive() }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const story = (await db.select().from(schema.profileStories).where(eq(schema.profileStories.id, args.storyId)).limit(1))[0];
      const viewer = (await db.select().from(schema.users).where(eq(schema.users.id, args.viewerId)).limit(1))[0];
      if (!story || story.expiresAt.getTime() <= Date.now() || !viewer?.isActive) return { ok: true, message: "این استوری دیگر در دسترس نیست" };
      await db.insert(schema.profileStoryViews).values({ storyId: story.id, viewerId: viewer.id }).onConflictDoUpdate({ target: [schema.profileStoryViews.storyId, schema.profileStoryViews.viewerId], set: { viewedAt: new Date() } });
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  deleteProfileStory: defineAction({
    request: z.object({ storyId: z.number().int().positive(), userId: z.number().int().positive() }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const story = (await db.select().from(schema.profileStories).where(eq(schema.profileStories.id, args.storyId)).limit(1))[0];
      if (!story || story.userId !== args.userId) return { ok: true, message: "فقط صاحب استوری می‌تواند آن را حذف کند" };
      await db.delete(schema.profileStoryViews).where(eq(schema.profileStoryViews.storyId, story.id));
      await db.delete(schema.profileStories).where(eq(schema.profileStories.id, story.id));
      ctx.invalidateQueries();
      return { ok: true, message: "استوری حذف شد" };
    },
  }),

  createDailyStory: defineAction({
    request: storyUploadSchema,
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      if (!user?.isActive) return { ok: true, message: "حساب فعال پیدا نشد" };
      const storyDay = tehranDayKey();
      const existing = (await db.select().from(schema.dailyStories).where(and(eq(schema.dailyStories.userId, user.id), eq(schema.dailyStories.storyDay, storyDay))).limit(1))[0];
      if (existing) return { ok: true, message: "امروز استوری روزانه گذاشته‌اید" };
      const binary = storyBytes(args);
      if (!binary) return { ok: true, message: "فرمت فایل هماهنگ نیست یا حجم آن بیشتر از ۸ مگابایت است" };
      const safeName = args.filename.replace(/[^a-zA-Z0-9._-]/g, "_");
      const key = `daily-stories/${user.id}/${Date.now()}-${safeName}`;
      await ctx.blobs.put(key, binary, { contentType: args.mimeType });
      const created = await db.insert(schema.dailyStories).values({ userId: user.id, storyDay, mediaType: args.mediaType, mediaBlobKey: key, caption: args.caption, expiresAt: new Date(Date.now() + 24 * 60 * 60_000) }).onConflictDoNothing().returning({ id: schema.dailyStories.id });
      if (!created[0]) return { ok: true, message: "امروز استوری روزانه گذاشته‌اید" };
      ctx.invalidateQueries();
      return { ok: true, message: "استوری روزانه منتشر شد و در صفحه درخواست‌ها دیده می‌شود" };
    },
  }),

  viewDailyStory: defineAction({
    request: z.object({ storyId: z.number().int().positive(), viewerId: z.number().int().positive() }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const story = (await db.select().from(schema.dailyStories).where(eq(schema.dailyStories.id, args.storyId)).limit(1))[0];
      const viewer = (await db.select().from(schema.users).where(eq(schema.users.id, args.viewerId)).limit(1))[0];
      if (!story || story.expiresAt.getTime() <= Date.now() || !viewer?.isActive) return { ok: true, message: "این استوری دیگر در دسترس نیست" };
      await db.insert(schema.dailyStoryViews).values({ storyId: story.id, viewerId: viewer.id }).onConflictDoUpdate({ target: [schema.dailyStoryViews.storyId, schema.dailyStoryViews.viewerId], set: { viewedAt: new Date() } });
      ctx.invalidateQueries();
      return { ok: true };
    },
  }),

  deleteDailyStory: defineAction({
    request: z.object({ storyId: z.number().int().positive(), userId: z.number().int().positive() }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const story = (await db.select().from(schema.dailyStories).where(eq(schema.dailyStories.id, args.storyId)).limit(1))[0];
      if (!story || story.userId !== args.userId) return { ok: true, message: "فقط صاحب استوری می‌تواند آن را حذف کند" };
      await db.delete(schema.dailyStoryViews).where(eq(schema.dailyStoryViews.storyId, story.id));
      await db.delete(schema.dailyStories).where(eq(schema.dailyStories.id, story.id));
      ctx.invalidateQueries();
      return { ok: true, message: "استوری روزانه حذف شد" };
    },
  }),

  createPublicStory: defineAction({
    request: storyUploadSchema,
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      if (!user?.isActive) return { ok: true, message: "حساب فعال پیدا نشد" };
      const binary = storyBytes(args);
      if (!binary) return { ok: true, message: "فرمت فایل هماهنگ نیست یا حجم آن بیشتر از ۸ مگابایت است" };
      const safeName = args.filename.replace(/[^a-zA-Z0-9._-]/g, "_");
      const key = `public-stories/${user.id}/${Date.now()}-${safeName}`;
      await ctx.blobs.put(key, binary, { contentType: args.mimeType });
      await db.insert(schema.publicStories).values({ userId: user.id, mediaType: args.mediaType, mediaBlobKey: key, caption: args.caption, expiresAt: new Date(Date.now() + 24 * 60 * 60_000) });
      ctx.invalidateQueries();
      return { ok: true, message: "استوری عمومی برای ۲۴ ساعت منتشر شد" };
    },
  }),

  deletePublicStory: defineAction({
    request: z.object({ storyId: z.number().int().positive(), userId: z.number().int().positive() }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const story = (await db.select().from(schema.publicStories).where(eq(schema.publicStories.id, args.storyId)).limit(1))[0];
      if (!story || story.userId !== args.userId) return { ok: true, message: "فقط صاحب استوری می‌تواند آن را حذف کند" };
      await db.delete(schema.publicStoryLikes).where(eq(schema.publicStoryLikes.storyId, story.id));
      await db.delete(schema.publicStoryComments).where(eq(schema.publicStoryComments.storyId, story.id));
      await db.delete(schema.publicStories).where(eq(schema.publicStories.id, story.id));
      ctx.invalidateQueries();
      return { ok: true, message: "استوری عمومی حذف شد" };
    },
  }),

  togglePublicStoryLike: defineAction({
    request: z.object({ storyId: z.number().int().positive(), userId: z.number().int().positive() }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const story = (await db.select().from(schema.publicStories).where(eq(schema.publicStories.id, args.storyId)).limit(1))[0];
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      if (!story || story.expiresAt.getTime() <= Date.now() || !user?.isActive) return { ok: true, message: "این استوری دیگر در دسترس نیست" };
      const existing = (await db.select().from(schema.publicStoryLikes).where(and(eq(schema.publicStoryLikes.storyId, story.id), eq(schema.publicStoryLikes.userId, user.id))).limit(1))[0];
      if (existing) await db.delete(schema.publicStoryLikes).where(eq(schema.publicStoryLikes.id, existing.id));
      else await db.insert(schema.publicStoryLikes).values({ storyId: story.id, userId: user.id });
      ctx.invalidateQueries();
      return { ok: true, message: existing ? "لایک برداشته شد" : "استوری را پسندیدید" };
    },
  }),

  commentPublicStory: defineAction({
    request: z.object({ storyId: z.number().int().positive(), userId: z.number().int().positive(), text: z.string().trim().min(1).max(240) }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const story = (await db.select().from(schema.publicStories).where(eq(schema.publicStories.id, args.storyId)).limit(1))[0];
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      if (!story || story.expiresAt.getTime() <= Date.now() || !user?.isActive) return { ok: true, message: "این استوری دیگر در دسترس نیست" };
      await db.insert(schema.publicStoryComments).values({ storyId: story.id, userId: user.id, text: args.text });
      ctx.invalidateQueries();
      return { ok: true, message: "کامنت ثبت شد" };
    },
  }),

  toggleFollowUser: defineAction({
    request: z.object({ followerId: z.number().int().positive(), followedId: z.number().int().positive() }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      if (args.followerId === args.followedId) return { ok: true, message: "نیازی به دنبال‌کردن خودتان نیست" };
      const users = await db.select().from(schema.users).where(inArray(schema.users.id, [args.followerId, args.followedId]));
      if (users.length !== 2 || users.some((user) => !user.isActive)) return { ok: true, message: "کاربر فعال پیدا نشد" };
      const existing = (await db.select().from(schema.userFollows).where(and(eq(schema.userFollows.followerId, args.followerId), eq(schema.userFollows.followedId, args.followedId))).limit(1))[0];
      if (existing) await db.delete(schema.userFollows).where(eq(schema.userFollows.id, existing.id));
      else await db.insert(schema.userFollows).values({ followerId: args.followerId, followedId: args.followedId });
      ctx.invalidateQueries();
      return { ok: true, message: existing ? "دنبال‌کردن متوقف شد" : "کاربر را دنبال کردید" };
    },
  }),

  setTwoFactor: defineAction({
    request: z.object({ userId: z.number().int().positive(), enabled: z.boolean() }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      if (!user || !user.isActive) return { ok: true, message: "حساب پیدا نشد" };
      await db.update(schema.users).set({ twoFactorEnabled: args.enabled }).where(eq(schema.users.id, user.id));
      ctx.invalidateQueries();
      return { ok: true, message: args.enabled ? "تأیید دومرحله‌ای فعال شد" : "تأیید دومرحله‌ای غیرفعال شد" };
    },
  }),

  deleteAccount: defineAction({
    request: z.object({ userId: z.number().int().positive(), confirmName: z.string().min(1).max(40) }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      if (!user) return { ok: true, message: "حساب پیدا نشد" };
      if (args.confirmName.trim() !== user.name) return { ok: true, message: "نام واردشده با نام حساب مطابقت ندارد؛ حساب حذف نشد" };
      const userId = user.id;
      const ownedStories = await db.select({ id: schema.profileStories.id }).from(schema.profileStories).where(eq(schema.profileStories.userId, userId));
      if (ownedStories.length) await db.delete(schema.profileStoryViews).where(inArray(schema.profileStoryViews.storyId, ownedStories.map((story) => story.id)));
      await db.delete(schema.profileStoryViews).where(eq(schema.profileStoryViews.viewerId, userId));
      await db.delete(schema.profileStories).where(eq(schema.profileStories.userId, userId));
      const ownedDailyStories = await db.select({ id: schema.dailyStories.id }).from(schema.dailyStories).where(eq(schema.dailyStories.userId, userId));
      if (ownedDailyStories.length) await db.delete(schema.dailyStoryViews).where(inArray(schema.dailyStoryViews.storyId, ownedDailyStories.map((story) => story.id)));
      await db.delete(schema.dailyStoryViews).where(eq(schema.dailyStoryViews.viewerId, userId));
      await db.delete(schema.dailyStories).where(eq(schema.dailyStories.userId, userId));
      const ownedPublicStories = await db.select({ id: schema.publicStories.id }).from(schema.publicStories).where(eq(schema.publicStories.userId, userId));
      if (ownedPublicStories.length) {
        const ownedIds = ownedPublicStories.map((story) => story.id);
        await db.delete(schema.publicStoryLikes).where(inArray(schema.publicStoryLikes.storyId, ownedIds));
        await db.delete(schema.publicStoryComments).where(inArray(schema.publicStoryComments.storyId, ownedIds));
      }
      await db.delete(schema.publicStoryLikes).where(eq(schema.publicStoryLikes.userId, userId));
      await db.delete(schema.publicStoryComments).where(eq(schema.publicStoryComments.userId, userId));
      await db.delete(schema.publicStories).where(eq(schema.publicStories.userId, userId));
      await db.delete(schema.userFollows).where(or(eq(schema.userFollows.followerId, userId), eq(schema.userFollows.followedId, userId)));
      await db.delete(schema.messageReactions).where(eq(schema.messageReactions.userId, userId));
      await db.delete(schema.channelComments).where(eq(schema.channelComments.userId, userId));
      const myPosts = await db.select({ id: schema.channelPosts.id }).from(schema.channelPosts).where(eq(schema.channelPosts.authorId, userId));
      if (myPosts.length) await db.delete(schema.channelComments).where(inArray(schema.channelComments.postId, myPosts.map((p) => p.id)));
      await db.delete(schema.messages).where(eq(schema.messages.senderId, userId));
      await db.delete(schema.channelPosts).where(eq(schema.channelPosts.authorId, userId));
      await db.delete(schema.connectionRequests).where(or(eq(schema.connectionRequests.senderId, userId), eq(schema.connectionRequests.receiverId, userId)));
      await db.delete(schema.memberships).where(eq(schema.memberships.userId, userId));
      await db.delete(schema.playerGameAvatars).where(eq(schema.playerGameAvatars.userId, userId));
      await db.delete(schema.scheduledGameResponses).where(eq(schema.scheduledGameResponses.userId, userId));
      await db.delete(schema.bets).where(or(eq(schema.bets.userId, userId), eq(schema.bets.targetUserId, userId)));
      await db.delete(schema.gameSpectators).where(eq(schema.gameSpectators.userId, userId));
      await db.delete(schema.liveVoiceClips).where(eq(schema.liveVoiceClips.senderId, userId));
      await db.delete(schema.spectatorGifts).where(eq(schema.spectatorGifts.spectatorId, userId));
      await db.delete(schema.gameSessions).where(eq(schema.gameSessions.userId, userId));
      await db.delete(schema.scoreEvents).where(eq(schema.scoreEvents.userId, userId));
      await db.delete(schema.scoreGroupMembers).where(eq(schema.scoreGroupMembers.userId, userId));
      await db.delete(schema.transactions).where(eq(schema.transactions.userId, userId));
      await db.delete(schema.reports).where(eq(schema.reports.reporterId, userId));
      await db.delete(schema.moderationAudit).where(eq(schema.moderationAudit.adminId, userId));
      await db.delete(schema.tournamentRegistrations).where(eq(schema.tournamentRegistrations.registeredByUserId, userId));
      const hostedRooms = await db.select({ id: schema.gameRooms.id }).from(schema.gameRooms).where(eq(schema.gameRooms.hostId, userId));
      const hostedRoomIds = hostedRooms.map((r) => r.id);
      if (hostedRoomIds.length) {
        await db.delete(schema.gameCheers).where(inArray(schema.gameCheers.gameRoomId, hostedRoomIds));
        await db.delete(schema.gameSpectators).where(inArray(schema.gameSpectators.gameRoomId, hostedRoomIds));
        await db.delete(schema.bets).where(inArray(schema.bets.gameRoomId, hostedRoomIds));
        await db.delete(schema.liveVoiceClips).where(inArray(schema.liveVoiceClips.gameRoomId, hostedRoomIds));
        await db.delete(schema.spectatorGifts).where(inArray(schema.spectatorGifts.gameRoomId, hostedRoomIds));
        await db.delete(schema.gameRooms).where(inArray(schema.gameRooms.id, hostedRoomIds));
      }
      await db.update(schema.gameRooms).set({ winnerId: null }).where(eq(schema.gameRooms.winnerId, userId));
      const hostedGames = await db.select({ id: schema.scheduledGroupGames.id }).from(schema.scheduledGroupGames).where(eq(schema.scheduledGroupGames.hostId, userId));
      const hostedGameIds = hostedGames.map((g) => g.id);
      if (hostedGameIds.length) {
        await db.delete(schema.scheduledGameResponses).where(inArray(schema.scheduledGameResponses.scheduledGameId, hostedGameIds));
        await db.delete(schema.scheduledGroupGames).where(inArray(schema.scheduledGroupGames.id, hostedGameIds));
      }
      const ownedConvs = await db.select({ id: schema.conversations.id }).from(schema.conversations).where(eq(schema.conversations.ownerId, userId));
      const ownedConvIds = ownedConvs.map((c) => c.id);
      if (ownedConvIds.length) {
        const ownedMessageIds = (await db.select({ id: schema.messages.id }).from(schema.messages).where(inArray(schema.messages.conversationId, ownedConvIds))).map((r) => r.id);
        if (ownedMessageIds.length) await db.delete(schema.messageReactions).where(inArray(schema.messageReactions.messageId, ownedMessageIds));
        await db.delete(schema.messages).where(inArray(schema.messages.conversationId, ownedConvIds));
        const ownedPosts = await db.select({ id: schema.channelPosts.id }).from(schema.channelPosts).where(inArray(schema.channelPosts.conversationId, ownedConvIds));
        if (ownedPosts.length) await db.delete(schema.channelComments).where(inArray(schema.channelComments.postId, ownedPosts.map((p) => p.id)));
        await db.delete(schema.channelPosts).where(inArray(schema.channelPosts.conversationId, ownedConvIds));
        await db.delete(schema.memberships).where(inArray(schema.memberships.conversationId, ownedConvIds));
        await db.delete(schema.conversations).where(inArray(schema.conversations.id, ownedConvIds));
      }
      await db.delete(schema.users).where(eq(schema.users.id, userId));
      ctx.invalidateQueries();
      return { ok: true, message: "حساب و همه داده‌های آن برای همیشه حذف شد" };
    },
  }),

  saveGameAvatar: defineAction({
    request: z.object({
      userId: z.number().int().positive(),
      face: z.enum(["round", "sharp", "soft"]),
      hair: z.enum(["short", "wave", "crest", "hood"]),
      outfit: z.enum(["ranger", "royal", "shadow", "sport"]),
      accent: z.enum(["emerald", "cherry", "gold", "ocean"]),
      emblem: z.enum(["star", "shield", "bolt", "crown"]),
    }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      if (!user || !user.isActive || user.accessRole !== "user") return { ok: true, message: "فقط بازیکن فعال می‌تواند آواتار مسابقه بسازد" };
      await db.insert(schema.playerGameAvatars).values({ ...args, updatedAt: new Date() }).onConflictDoUpdate({
        target: schema.playerGameAvatars.userId,
        set: { face: args.face, hair: args.hair, outfit: args.outfit, accent: args.accent, emblem: args.emblem, updatedAt: new Date() },
      });
      ctx.invalidateQueries();
      return { ok: true, message: "آواتار مسابقه ذخیره شد؛ حالا آماده ثبت‌نام هستید" };
    },
  }),

  sendRequest: defineAction({
    request: z.object({
      senderId: z.number(),
      receiverId: z.number(),
      message: z.string().trim().max(240).optional(),
      image: z.object({
        dataBase64: z.string().min(1),
        mimeType: z.enum(["image/jpeg", "image/png", "image/webp"]),
        filename: z.string().min(1).max(100),
      }).optional(),
    }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      if (args.senderId === args.receiverId) return { ok: true, message: "درخواست به خود ممکن نیست" };
      const sender = (await db.select().from(schema.users).where(eq(schema.users.id, args.senderId)).limit(1))[0];
      const receiver = (await db.select().from(schema.users).where(eq(schema.users.id, args.receiverId)).limit(1))[0];
      if (!sender || !receiver || !sender.isActive || !receiver.isActive) return { ok: true, message: "امکان ارسال درخواست به این کاربر وجود ندارد" };
      let imageBlobKey: string | null = null;
      if (args.image) {
        const binary = Uint8Array.from(atob(args.image.dataBase64), (char) => char.charCodeAt(0));
        if (binary.byteLength > 5 * 1024 * 1024) return { ok: true, message: "حجم عکس باید کمتر از ۵ مگابایت باشد" };
        const extension = args.image.mimeType === "image/png" ? "png" : args.image.mimeType === "image/webp" ? "webp" : "jpg";
        imageBlobKey = `requests/${args.senderId}-${args.receiverId}-${Date.now()}.${extension}`;
        await ctx.blobs.put(imageBlobKey, binary, { contentType: args.image.mimeType });
      }
      await db.insert(schema.connectionRequests).values({ senderId: args.senderId, receiverId: args.receiverId, message: args.message ?? "", imageBlobKey }).onConflictDoUpdate({
        target: [schema.connectionRequests.senderId, schema.connectionRequests.receiverId],
        set: { status: "pending", message: args.message ?? "", imageBlobKey, createdAt: new Date() },
      });
      ctx.invalidateQueries();
      return { ok: true, message: imageBlobKey ? "درخواست همراه یک عکس ارسال شد" : "درخواست ارسال شد" };
    },
  }),

  respondRequest: defineAction({ request: z.object({ requestId: z.number(), userId: z.number(), accept: z.boolean() }), response: requestResponseSchema, async handler(ctx, args): Promise<z.infer<typeof requestResponseSchema>> { const db = ctx.db<typeof schema>(); const req = (await db.select().from(schema.connectionRequests).where(and(eq(schema.connectionRequests.id, args.requestId), eq(schema.connectionRequests.receiverId, args.userId))).limit(1))[0]; if (!req) return { ok: true, message: "درخواست پیدا نشد", conversationId: null }; await db.update(schema.connectionRequests).set({ status: args.accept ? "accepted" : "rejected" }).where(eq(schema.connectionRequests.id, req.id)); let conversationId: number | null = null; if (args.accept) { const participantIds = [req.senderId, req.receiverId]; const pairMemberships = await db.select().from(schema.memberships).where(inArray(schema.memberships.userId, participantIds)); const privateRows = await db.select().from(schema.conversations).where(eq(schema.conversations.kind, "private")); const existing = privateRows.find((conversation) => participantIds.every((id) => pairMemberships.some((membership) => membership.conversationId === conversation.id && membership.userId === id))); if (existing) conversationId = existing.id; else { const names = await db.select().from(schema.users).where(inArray(schema.users.id, participantIds)); const conv = (await db.insert(schema.conversations).values({ kind: "private", name: names.map((u) => u.name).join(" و "), ownerId: req.receiverId, description: "گفتگوی خصوصی پس از پذیرش درخواست", confidential: false }).returning({ id: schema.conversations.id }))[0]; if (conv) { conversationId = conv.id; await db.insert(schema.memberships).values([{ conversationId: conv.id, userId: req.senderId, role: "member" }, { conversationId: conv.id, userId: req.receiverId, role: "owner" }]); } } } ctx.invalidateQueries(); return { ok: true, message: args.accept ? "درخواست پذیرفته شد؛ وارد چت خصوصی شدید" : "درخواست رد شد", conversationId }; } }),

  sendMessage: defineAction({ request: z.object({ conversationId: z.number(), senderId: z.number(), type: z.literal("text"), content: z.string().min(1).max(500), replyToId: z.number().int().positive().optional() }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); const conv = (await db.select().from(schema.conversations).where(eq(schema.conversations.id, args.conversationId)).limit(1))[0]; if (!conv) return { ok: true, message: "گفتگو پیدا نشد" }; const member = (await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, conv.id), eq(schema.memberships.userId, args.senderId))).limit(1))[0]; if (!member) return { ok: true, message: "ابتدا عضو گفتگو شوید" }; if (member.blocked) return { ok: true, message: "این گفتگو برای شما بلاک است" }; if (conv.kind === "channel" && member.role !== "owner" && member.role !== "superadmin" && member.role !== "admin") return { ok: true, message: "اعضای کانال فقط می‌توانند کامنت، استیکر و لایک بفرستند" }; const reply = args.replyToId ? (await db.select().from(schema.messages).where(and(eq(schema.messages.id, args.replyToId), eq(schema.messages.conversationId, conv.id))).limit(1))[0] : undefined; const expiresAt = conv.kind === "private" && conv.confidential ? new Date(Date.now() + conv.secretTimerMinutes * 60_000) : null; await db.insert(schema.messages).values({ conversationId: args.conversationId, senderId: args.senderId, type: args.type, content: args.content, replyToId: reply?.id ?? null, expiresAt }); ctx.invalidateQueries(); return { ok: true, message: conv.confidential ? `پیام تا ${conv.secretTimerMinutes} دقیقه دیگر حذف می‌شود` : "پیام ذخیره شد" }; } }),

  reactMessage: defineAction({
    request: z.object({ messageId: z.number().int().positive(), userId: z.number().int().positive(), emoji: messageReactionSchema }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const message = (await db.select().from(schema.messages).where(eq(schema.messages.id, args.messageId)).limit(1))[0];
      if (!message || message.type === "system") return { ok: true, message: "این پیام قابل واکنش نیست" };
      const member = (await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, message.conversationId), eq(schema.memberships.userId, args.userId))).limit(1))[0];
      if (!member || member.blocked) return { ok: true, message: "اجازه واکنش به این پیام را ندارید" };
      const existing = (await db.select().from(schema.messageReactions).where(and(eq(schema.messageReactions.messageId, message.id), eq(schema.messageReactions.userId, args.userId))).limit(1))[0];
      if (existing?.emoji === args.emoji) {
        await db.delete(schema.messageReactions).where(eq(schema.messageReactions.id, existing.id));
      } else if (existing) {
        await db.update(schema.messageReactions).set({ emoji: args.emoji, createdAt: new Date() }).where(eq(schema.messageReactions.id, existing.id));
      } else {
        await db.insert(schema.messageReactions).values({ messageId: message.id, userId: args.userId, emoji: args.emoji });
      }
      ctx.invalidateQueries();
      return { ok: true, message: existing?.emoji === args.emoji ? "واکنش برداشته شد" : "واکنش روی پیام ثبت شد" };
    },
  }),

  editMessage: defineAction({
    request: z.object({ messageId: z.number().int().positive(), userId: z.number().int().positive(), content: z.string().min(1).max(500) }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const message = (await db.select().from(schema.messages).where(eq(schema.messages.id, args.messageId)).limit(1))[0];
      if (!message || message.senderId !== args.userId) return { ok: true, message: "فقط پیام خودتان قابل ویرایش است" };
      if (message.type !== "text") return { ok: true, message: "فقط پیام متنی قابل ویرایش است" };
      const member = (await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, message.conversationId), eq(schema.memberships.userId, args.userId))).limit(1))[0];
      if (!member || member.blocked) return { ok: true, message: "اجازه ویرایش این پیام را ندارید" };
      await db.update(schema.messages).set({ content: args.content, editedAt: new Date() }).where(eq(schema.messages.id, message.id));
      ctx.invalidateQueries();
      return { ok: true, message: "ویرایش پیام ذخیره شد" };
    },
  }),

  deleteMessage: defineAction({
    request: z.object({ messageId: z.number().int().positive(), userId: z.number().int().positive() }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const message = (await db.select().from(schema.messages).where(eq(schema.messages.id, args.messageId)).limit(1))[0];
      if (!message || message.senderId !== args.userId) return { ok: true, message: "فقط پیام خودتان قابل حذف است" };
      await db.delete(schema.messages).where(eq(schema.messages.id, message.id));
      ctx.invalidateQueries();
      return { ok: true, message: "پیام حذف شد" };
    },
  }),

  forwardMessage: defineAction({
    request: z.object({ messageId: z.number().int().positive(), userId: z.number().int().positive(), targetConversationId: z.number().int().positive() }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const source = (await db.select().from(schema.messages).where(eq(schema.messages.id, args.messageId)).limit(1))[0];
      if (!source || source.type === "system") return { ok: true, message: "این پیام قابل ارسال نیست" };
      const sourceMember = (await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, source.conversationId), eq(schema.memberships.userId, args.userId))).limit(1))[0];
      const target = (await db.select().from(schema.conversations).where(eq(schema.conversations.id, args.targetConversationId)).limit(1))[0];
      const targetMember = target ? (await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, target.id), eq(schema.memberships.userId, args.userId))).limit(1))[0] : undefined;
      if (!sourceMember || !target || !targetMember || targetMember.blocked) return { ok: true, message: "اجازه ارسال به این گفتگو را ندارید" };
      if (target.kind === "channel" && targetMember.role !== "owner" && targetMember.role !== "superadmin" && targetMember.role !== "admin") return { ok: true, message: "اعضای کانال فقط می‌توانند کامنت، استیکر و لایک بفرستند" };
      if (target.kind === "channel" && source.type !== "text" && targetMember.role !== "owner") return { ok: true, message: "فقط مدیر کانال می‌تواند عکس و فیلم منتشر کند" };
      if (target.kind === "channel") {
        await db.insert(schema.channelPosts).values({ conversationId: target.id, authorId: args.userId, text: source.type === "text" ? source.content : "", mediaType: source.type === "image" || source.type === "video" || source.type === "voice" ? source.type : null, mediaBlobKey: source.type === "image" || source.type === "video" || source.type === "voice" ? source.content : null });
      } else {
        const expiresAt = target.kind === "private" && target.confidential ? new Date(Date.now() + target.secretTimerMinutes * 60_000) : null;
        await db.insert(schema.messages).values({ conversationId: target.id, senderId: args.userId, type: source.type, content: source.content, expiresAt });
      }
      ctx.invalidateQueries();
      return { ok: true, message: `پیام به «${target.name}» ارسال شد` };
    },
  }),

  sendMedia: defineAction({ request: z.object({ conversationId: z.number(), senderId: z.number(), type: z.enum(["voice", "image", "video"]), dataBase64: z.string().min(1), mimeType: z.enum(["audio/webm", "audio/mp4", "audio/mpeg", "image/jpeg", "image/png", "image/webp", "video/mp4", "video/webm"]), filename: z.string().max(100), replyToId: z.number().int().positive().optional() }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); const conv = (await db.select().from(schema.conversations).where(eq(schema.conversations.id, args.conversationId)).limit(1))[0]; if (!conv) return { ok: true, message: "گفتگو پیدا نشد" }; const member = (await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, conv.id), eq(schema.memberships.userId, args.senderId))).limit(1))[0]; if (!member) return { ok: true, message: "ابتدا عضو گفتگو شوید" }; if (member.blocked) return { ok: true, message: "این گفتگو برای شما بلاک است" }; if (conv.kind === "channel" && member.role !== "owner") return { ok: true, message: "فقط مدیر کانال می‌تواند عکس و فیلم منتشر کند" }; const binary = Uint8Array.from(atob(args.dataBase64), (char) => char.charCodeAt(0)); if (binary.byteLength > 8 * 1024 * 1024) return { ok: true, message: "حجم فایل باید کمتر از ۸ مگابایت باشد" }; const key = `messages/${args.conversationId}/${Date.now()}-${args.filename.replace(/[^a-zA-Z0-9._-]/g, "_")}`; await ctx.blobs.put(key, binary, { contentType: args.mimeType }); if (conv.kind === "channel") { const reply = args.replyToId ? (await db.select().from(schema.channelPosts).where(and(eq(schema.channelPosts.id, args.replyToId), eq(schema.channelPosts.conversationId, conv.id))).limit(1))[0] : undefined; await db.insert(schema.channelPosts).values({ conversationId: args.conversationId, authorId: args.senderId, text: "", mediaType: args.type, mediaBlobKey: key, replyToId: reply?.id ?? null }); } else { const reply = args.replyToId ? (await db.select().from(schema.messages).where(and(eq(schema.messages.id, args.replyToId), eq(schema.messages.conversationId, conv.id))).limit(1))[0] : undefined; const expiresAt = conv.kind === "private" && conv.confidential ? new Date(Date.now() + conv.secretTimerMinutes * 60_000) : null; await db.insert(schema.messages).values({ conversationId: args.conversationId, senderId: args.senderId, type: args.type, content: key, replyToId: reply?.id ?? null, expiresAt }); } ctx.invalidateQueries(); return { ok: true, message: conv.kind === "channel" ? "رسانه در کانال منتشر شد" : conv.confidential ? `رسانه تا ${conv.secretTimerMinutes} دقیقه دیگر حذف می‌شود` : "رسانه ذخیره شد" }; } }),

  createConversation: defineAction({
    request: z.object({ ownerId: z.number(), kind: z.enum(["group", "channel"]), name: z.string().min(2).max(50), rules: z.string().max(300), channelActivity: z.string().max(80), adminIds: z.array(z.number().int().positive()).max(6), superAdminIds: z.array(z.number().int().positive()).max(2), supervisorIds: z.array(z.number().int().positive()).max(2), moderatorIds: z.array(z.number().int().positive()).max(5) }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const cost = args.kind === "group" ? 100 : 150;
      const owner = (await db.select().from(schema.users).where(eq(schema.users.id, args.ownerId)).limit(1))[0];
      if (!owner || owner.coins < cost) return { ok: true, message: "سکه کافی نیست" };
      if (args.kind === "channel" && args.channelActivity.trim().length < 2) return { ok: true, message: "حوزه فعالیت کانال را وارد کنید" };
      const requestedIds = [...new Set([...args.adminIds, ...args.superAdminIds, ...args.supervisorIds, ...args.moderatorIds])].filter((id) => id !== owner.id);
      const eligibleUsers = requestedIds.length ? (await db.select().from(schema.users).where(inArray(schema.users.id, requestedIds))).filter((user) => user.isTest && DEMO_PHONES.has(user.phone)) : [];
      const eligibleIds = new Set(eligibleUsers.map((user) => user.id));
      const supervisors = args.kind === "group" ? args.supervisorIds.filter((id) => eligibleIds.has(id)).slice(0, 2) : [];
      const supervisorSet = new Set(supervisors);
      const moderators = args.kind === "group" ? args.moderatorIds.filter((id) => eligibleIds.has(id) && !supervisorSet.has(id)).slice(0, 5) : [];
      const superAdmins = args.kind === "channel" ? args.superAdminIds.filter((id) => eligibleIds.has(id)).slice(0, 2) : [];
      const superAdminSet = new Set(superAdmins);
      const admins = args.kind === "channel" ? args.adminIds.filter((id) => eligibleIds.has(id) && !superAdminSet.has(id)).slice(0, 6) : [];
      const conv = (await db.insert(schema.conversations).values({ kind: args.kind, name: args.name, ownerId: args.ownerId, description: args.rules, channelActivity: args.kind === "channel" ? args.channelActivity.trim() : "" }).returning({ id: schema.conversations.id }))[0];
      if (conv) {
        await db.insert(schema.memberships).values({ conversationId: conv.id, userId: args.ownerId, role: "owner", following: args.kind === "channel" });
        for (const id of supervisors) await db.insert(schema.memberships).values({ conversationId: conv.id, userId: id, role: "supervisor" }).onConflictDoNothing();
        for (const id of moderators) await db.insert(schema.memberships).values({ conversationId: conv.id, userId: id, role: "moderator" }).onConflictDoNothing();
        for (const id of superAdmins) await db.insert(schema.memberships).values({ conversationId: conv.id, userId: id, role: "superadmin", following: true }).onConflictDoNothing();
        for (const id of admins) await db.insert(schema.memberships).values({ conversationId: conv.id, userId: id, role: "admin", following: true }).onConflictDoNothing();
      }
      await db.update(schema.users).set({ coins: owner.coins - cost }).where(eq(schema.users.id, owner.id));
      await db.insert(schema.transactions).values({ userId: owner.id, amount: -cost, kind: "create", note: args.kind === "group" ? "ساخت گروه" : "ساخت کانال" });
      ctx.invalidateQueries();
      return { ok: true, message: args.kind === "group" ? `گروه با ۱ مدیر، ${supervisors.length} سرپرست و ${moderators.length} ناظر ساخته شد` : `کانال با ۱ مدیر، ${superAdmins.length} سوپر ادمین و ${admins.length} ادمین ساخته شد` };
    },
  }),

  joinConversation: defineAction({ request: z.object({ userId: z.number(), conversationId: z.number() }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); await db.insert(schema.memberships).values({ userId: args.userId, conversationId: args.conversationId, role: "member", following: true }).onConflictDoUpdate({ target: [schema.memberships.conversationId, schema.memberships.userId], set: { following: true } }); ctx.invalidateQueries(); return { ok: true, message: "عضویت و دنبال‌کردن ثبت شد" }; } }),

  inviteToConversation: defineAction({ request: z.object({ userId: z.number().int().positive(), conversationId: z.number().int().positive(), inviteeId: z.number().int().positive() }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); const inviter = (await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, args.conversationId), eq(schema.memberships.userId, args.userId))).limit(1))[0]; const conversation = (await db.select().from(schema.conversations).where(eq(schema.conversations.id, args.conversationId)).limit(1))[0]; const invitee = (await db.select().from(schema.users).where(eq(schema.users.id, args.inviteeId)).limit(1))[0]; if (!inviter || !conversation || conversation.kind === "private" || !invitee?.isActive) return { ok: true, message: "دعوت برای این فضا در دسترس نیست" }; await db.insert(schema.memberships).values({ conversationId: conversation.id, userId: invitee.id, role: "member", following: conversation.kind === "channel" }).onConflictDoNothing(); ctx.invalidateQueries(); return { ok: true, message: `${invitee.name} به ${conversation.kind === "channel" ? "کانال" : "گروه"} اضافه شد` }; } }),

  donateConversationFund: defineAction({ request: z.object({ userId: z.number().int().positive(), conversationId: z.number().int().positive(), amount: z.number().int().min(1).max(1000) }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); const member = (await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, args.conversationId), eq(schema.memberships.userId, args.userId))).limit(1))[0]; const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0]; const conversation = (await db.select().from(schema.conversations).where(eq(schema.conversations.id, args.conversationId)).limit(1))[0]; if (!member || !user || !conversation || conversation.kind === "private") return { ok: true, message: "صندوق این فضا در دسترس نیست" }; if (user.coins < args.amount) return { ok: true, message: "موجودی سکه کافی نیست" }; await db.batch([db.update(schema.users).set({ coins: user.coins - args.amount }).where(eq(schema.users.id, user.id)), db.update(schema.conversations).set({ groupFund: conversation.groupFund + args.amount }).where(eq(schema.conversations.id, conversation.id)), db.insert(schema.transactions).values({ userId: user.id, amount: -args.amount, kind: "group_fund", note: `کمک به صندوق ${conversation.name}` })]); ctx.invalidateQueries(); return { ok: true, message: `${args.amount} سکه به صندوق اضافه شد` }; } }),

  leaveConversation: defineAction({ request: z.object({ userId: z.number().int().positive(), conversationId: z.number().int().positive() }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); const member = (await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, args.conversationId), eq(schema.memberships.userId, args.userId))).limit(1))[0]; const conversation = (await db.select().from(schema.conversations).where(eq(schema.conversations.id, args.conversationId)).limit(1))[0]; if (!member || !conversation || conversation.kind === "private") return { ok: true, message: "عضویت پیدا نشد" }; if (member.role === "owner") return { ok: true, message: "مدیر باید پیش از خروج، مدیریت را واگذار کند" }; await db.delete(schema.memberships).where(eq(schema.memberships.id, member.id)); ctx.invalidateQueries(); return { ok: true, message: conversation.kind === "channel" ? "از کانال خارج شدید" : conversation.name === "دورهمی" ? "از اتاق خارج شدید" : "از گروه خارج شدید" }; } }),

  publishGameRecording: defineAction({ request: z.object({ userId: z.number().int().positive(), sessionId: z.number().int().positive(), conversationId: z.number().int().positive() }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); const session = (await db.select().from(schema.gameSessions).where(and(eq(schema.gameSessions.id, args.sessionId), eq(schema.gameSessions.userId, args.userId))).limit(1))[0]; const channel = (await db.select().from(schema.conversations).where(and(eq(schema.conversations.id, args.conversationId), eq(schema.conversations.kind, "channel"))).limit(1))[0]; const member = (await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, args.conversationId), eq(schema.memberships.userId, args.userId))).limit(1))[0]; if (!session || !channel || !member || !["owner", "superadmin", "admin"].includes(member.role)) return { ok: true, message: "مجوز انتشار در این کانال را ندارید" }; const state = JSON.parse(session.stateJson) as GameState; const events = state.eventLog ?? []; if (!events.length) return { ok: true, message: "این بازی هنوز رویدادی برای انتشار ندارد" }; const winner = state.winnerIndex === null || state.winnerIndex === undefined ? "در حال بازی" : `برنده: ${state.players?.[state.winnerIndex]?.name ?? "بازیکن"}`; await db.insert(schema.channelPosts).values({ conversationId: channel.id, authorId: args.userId, text: `بازپخش بازی ${session.gameType} · میز ${session.id}\n${winner} · ${Math.floor(events.length / 2)} حرکت ثبت‌شده` }); ctx.invalidateQueries(); return { ok: true, message: "بازپخش در کانال منتشر شد" }; } }),

  toggleFollow: defineAction({ request: z.object({ userId: z.number(), conversationId: z.number() }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); const member = (await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, args.conversationId), eq(schema.memberships.userId, args.userId))).limit(1))[0]; if (!member) { await db.insert(schema.memberships).values({ userId: args.userId, conversationId: args.conversationId, role: "member", following: true }); ctx.invalidateQueries(); return { ok: true, message: "کانال را دنبال می‌کنید" }; } await db.update(schema.memberships).set({ following: !member.following }).where(eq(schema.memberships.id, member.id)); ctx.invalidateQueries(); return { ok: true, message: member.following ? "دنبال‌کردن متوقف شد" : "کانال را دنبال می‌کنید" }; } }),

  publishChannel: defineAction({ request: z.object({ userId: z.number(), conversationId: z.number(), text: z.string().min(1).max(280), replyToId: z.number().int().positive().optional() }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); const conv = (await db.select().from(schema.conversations).where(eq(schema.conversations.id, args.conversationId)).limit(1))[0]; const member = (await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, args.conversationId), eq(schema.memberships.userId, args.userId))).limit(1))[0]; if (!conv || !member || (member.role !== "owner" && member.role !== "superadmin" && member.role !== "admin")) return { ok: true, message: "اعضای کانال فقط می‌توانند کامنت، استیکر و لایک بفرستند" }; const reply = args.replyToId ? (await db.select().from(schema.channelPosts).where(and(eq(schema.channelPosts.id, args.replyToId), eq(schema.channelPosts.conversationId, args.conversationId))).limit(1))[0] : undefined; await db.insert(schema.channelPosts).values({ conversationId: args.conversationId, authorId: args.userId, text: args.text, replyToId: reply?.id ?? null }); ctx.invalidateQueries(); return { ok: true, message: "مطلب منتشر شد" }; } }),

  reactChannel: defineAction({ request: z.object({ userId: z.number(), postId: z.number(), mode: z.enum(["like", "comment"]) }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); const post = (await db.select().from(schema.channelPosts).where(eq(schema.channelPosts.id, args.postId)).limit(1))[0]; const member = post ? (await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, post.conversationId), eq(schema.memberships.userId, args.userId))).limit(1))[0] : undefined; if (!post || !member) return { ok: true, message: "برای واکنش ابتدا عضو کانال شوید" }; await db.update(schema.channelPosts).set(args.mode === "like" ? { likes: post.likes + 1 } : { comments: post.comments + 1 }).where(eq(schema.channelPosts.id, post.id)); ctx.invalidateQueries(); return { ok: true, message: "واکنش ثبت شد" }; } }),

  claimDailyGift: defineAction({ request: z.object({ userId: z.number(), day: z.string().regex(/^\d{4}-\d{2}-\d{2}$/) }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0]; const setting = (await db.select().from(schema.settings).limit(1))[0]; if (!user || !setting || !user.isActive) return { ok: true, message: "حساب پیدا نشد" }; const serverDay = tehranDayKey(); if (user.lastGiftDay === serverDay) return { ok: true, message: "هدیه امروز دریافت شده" }; await db.batch([db.update(schema.users).set({ coins: user.coins + setting.dailyGift, lastGiftDay: serverDay }).where(eq(schema.users.id, user.id)), db.insert(schema.transactions).values({ userId: user.id, amount: setting.dailyGift, kind: "gift", note: "هدیه روزانه" })]); ctx.invalidateQueries(); return { ok: true, message: `${setting.dailyGift} سکه اضافه شد` }; } }),

  redeemAmbassadorCode: defineAction({
    request: z.object({ userId: z.number().int().positive(), code: z.string().trim().min(6).max(24) }),
    response: ambassadorRedeemResponseSchema,
    async handler(ctx, args): Promise<z.infer<typeof ambassadorRedeemResponseSchema>> {
      const db = ctx.db<typeof schema>();
      const invitee = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      const profile = (await db.select().from(schema.ambassadorProfiles).where(eq(schema.ambassadorProfiles.inviteCode, args.code.trim().toUpperCase())).limit(1))[0];
      if (!invitee?.isActive || invitee.accessRole !== "user") return { ok: true, redeemed: false, message: "این حساب امکان استفاده از کد سفیر را ندارد" };
      if (!profile) return { ok: true, redeemed: false, message: "کد سفیر معتبر نیست" };
      if (profile.userId === invitee.id) return { ok: true, redeemed: false, message: "نمی‌توانی کد دعوت خودت را استفاده کنی" };
      const existing = (await db.select().from(schema.ambassadorReferrals).where(eq(schema.ambassadorReferrals.inviteeId, invitee.id)).limit(1))[0];
      if (existing) return { ok: true, redeemed: false, message: "برای این حساب قبلاً یک کد سفیر ثبت شده" };
      const inviter = (await db.select().from(schema.users).where(eq(schema.users.id, profile.userId)).limit(1))[0];
      if (!inviter?.isActive) return { ok: true, redeemed: false, message: "سفیر این کد فعال نیست" };
      const created = (await db.insert(schema.ambassadorReferrals).values({ inviterId: inviter.id, inviteeId: invitee.id, inviteCode: profile.inviteCode, reward: AMBASSADOR_REWARD }).onConflictDoNothing().returning({ id: schema.ambassadorReferrals.id }))[0];
      if (!created) return { ok: true, redeemed: false, message: "برای این حساب قبلاً یک کد سفیر ثبت شده" };
      await db.batch([
        db.update(schema.users).set({ coins: inviter.coins + AMBASSADOR_REWARD }).where(eq(schema.users.id, inviter.id)),
        db.insert(schema.transactions).values({ userId: inviter.id, amount: AMBASSADOR_REWARD, kind: "ambassador_reward", note: `پاداش دعوت سفیر برای کاربر ${invitee.name}` }),
      ]);
      ctx.invalidateQueries();
      return { ok: true, redeemed: true, message: "کد ثبت شد و ۱۰۰ سکه به کیف سفیر اضافه شد" };
    },
  }),

  setFinancialSafePin: defineAction({
    request: z.object({ userId: z.number().int().positive(), newPin: z.string().regex(/^\d{4,6}$/), currentPin: z.string().regex(/^\d{4,6}$/).optional() }),
    response: safePinResponseSchema,
    async handler(ctx, args): Promise<z.infer<typeof safePinResponseSchema>> {
      const db = ctx.db<typeof schema>();
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      const existing = (await db.select().from(schema.financialSafePins).where(eq(schema.financialSafePins.userId, args.userId)).limit(1))[0];
      if (!user?.isActive || user.accessRole === "admin") return { ok: true, configured: false, message: "گاوصندوق برای این حساب در دسترس نیست" };
      if (existing) {
        if (!args.currentPin || !(await verifyFinancialPin(args.currentPin, existing.pinHash))) return { ok: true, configured: true, message: "پین فعلی درست نیست" };
      }
      const pinHash = await hashFinancialPin(args.newPin);
      await db.insert(schema.financialSafePins).values({ userId: user.id, pinHash, failedAttempts: 0, lockedUntil: null, updatedAt: new Date() }).onConflictDoUpdate({ target: schema.financialSafePins.userId, set: { pinHash, failedAttempts: 0, lockedUntil: null, updatedAt: new Date() } });
      ctx.invalidateQueries();
      return { ok: true, configured: true, message: existing ? "پین گاوصندوق تغییر کرد" : "پین گاوصندوق فعال شد" };
    },
  }),

  unlockFinancialSafe: defineAction({
    request: z.object({ userId: z.number().int().positive(), pin: z.string().regex(/^\d{4,6}$/) }),
    response: safeUnlockResponseSchema,
    async handler(ctx, args): Promise<z.infer<typeof safeUnlockResponseSchema>> {
      const db = ctx.db<typeof schema>();
      const safePin = (await db.select().from(schema.financialSafePins).where(eq(schema.financialSafePins.userId, args.userId)).limit(1))[0];
      if (!safePin) return { ok: true, unlocked: false, message: "ابتدا برای گاوصندوق پین بساز", lockedUntil: null };
      if (safePin.lockedUntil && safePin.lockedUntil.getTime() > Date.now()) return { ok: true, unlocked: false, message: "به‌دلیل تلاش ناموفق، گاوصندوق موقتاً قفل است", lockedUntil: safePin.lockedUntil.toISOString() };
      const valid = await verifyFinancialPin(args.pin, safePin.pinHash);
      if (valid) {
        await db.update(schema.financialSafePins).set({ failedAttempts: 0, lockedUntil: null, updatedAt: new Date() }).where(eq(schema.financialSafePins.id, safePin.id));
        ctx.invalidateQueries();
        return { ok: true, unlocked: true, message: "گاوصندوق باز شد", lockedUntil: null };
      }
      const attempts = safePin.failedAttempts + 1;
      const lockedUntil = attempts >= 5 ? new Date(Date.now() + 5 * 60_000) : null;
      await db.update(schema.financialSafePins).set({ failedAttempts: lockedUntil ? 0 : attempts, lockedUntil, updatedAt: new Date() }).where(eq(schema.financialSafePins.id, safePin.id));
      ctx.invalidateQueries();
      return { ok: true, unlocked: false, message: lockedUntil ? "پنج تلاش ناموفق؛ گاوصندوق پنج دقیقه قفل شد" : `پین نادرست است؛ ${5 - attempts} تلاش مانده`, lockedUntil: lockedUntil?.toISOString() ?? null };
    },
  }),

  createBattleCry: defineAction({
    request: z.object({ userId: z.number().int().positive(), text: z.string().trim().min(3).max(100) }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      if (!user || !user.isActive || user.accessRole !== "user") return { ok: true, message: "این حساب امکان ثبت کری ندارد" };
      if (user.coins < 10) return { ok: true, message: "برای ثبت کری ۱۰ سکه لازم است" };
      const expiresAt = new Date(Date.now() + 3 * 60_000);
      await db.batch([
        db.update(schema.users).set({ coins: user.coins - 10 }).where(eq(schema.users.id, user.id)),
        db.insert(schema.battleCries).values({ userId: user.id, text: args.text.trim(), expiresAt }),
        db.insert(schema.transactions).values({ userId: user.id, amount: -10, kind: "battle_cry", note: "ثبت کری سه‌دقیقه‌ای" }),
      ]);
      ctx.invalidateQueries();
      return { ok: true, message: "کری شما برای سه دقیقه روی صفحه اصلی پخش شد" };
    },
  }),

  startQuickDuel: defineAction({
    request: z.object({ userId: z.number().int().positive() }),
    response: quickDuelStartSchema,
    async handler(ctx, args): Promise<z.infer<typeof quickDuelStartSchema>> {
      const db = ctx.db<typeof schema>();
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      if (!user || !user.isActive || user.accessRole !== "user") throw new Error("Quick duel unavailable");
      const question = quickDuelBank[Math.floor(Math.random() * quickDuelBank.length)] ?? quickDuelBank[0];
      const startedAt = new Date();
      const inserted = (await db.insert(schema.quickDuels).values({ userId: user.id, questionKey: question.key, correctOption: question.correct, startedAt }).returning({ id: schema.quickDuels.id }))[0];
      if (!inserted) throw new Error("Quick duel creation failed");
      return { ok: true, duelId: inserted.id, question: question.question, options: [...question.options], expiresAt: new Date(startedAt.getTime() + 5_000).toISOString() };
    },
  }),

  answerQuickDuel: defineAction({
    request: z.object({ userId: z.number().int().positive(), duelId: z.number().int().positive(), option: z.number().int().min(0).max(2) }),
    response: quickDuelAnswerSchema,
    async handler(ctx, args): Promise<z.infer<typeof quickDuelAnswerSchema>> {
      const db = ctx.db<typeof schema>();
      const duel = (await db.select().from(schema.quickDuels).where(and(eq(schema.quickDuels.id, args.duelId), eq(schema.quickDuels.userId, args.userId))).limit(1))[0];
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      if (!duel || !user || duel.answeredAt) return { ok: true, correct: false, reward: 0, message: "این دوئل قبلاً پاسخ داده شده است" };
      const inTime = Date.now() <= duel.startedAt.getTime() + 5_000;
      const correct = inTime && args.option === duel.correctOption;
      const answeredAt = new Date();
      if (correct) {
        await db.batch([
          db.update(schema.quickDuels).set({ answeredAt, won: true, reward: QUICK_DUEL_REWARD }).where(eq(schema.quickDuels.id, duel.id)),
          db.update(schema.users).set({ coins: user.coins + QUICK_DUEL_REWARD }).where(eq(schema.users.id, user.id)),
          db.insert(schema.transactions).values({ userId: user.id, amount: QUICK_DUEL_REWARD, kind: "quick_duel", note: "برد دوئل پنج‌ثانیه‌ای" }),
        ]);
      } else {
        await db.update(schema.quickDuels).set({ answeredAt, won: false, reward: 0 }).where(eq(schema.quickDuels.id, duel.id));
      }
      ctx.invalidateQueries();
      return { ok: true, correct, reward: correct ? QUICK_DUEL_REWARD : 0, message: correct ? "پاسخ درست بود؛ ۵۰ سکه گرفتی" : inTime ? "پاسخ درست نبود؛ دوباره تمرین کن" : "پنج ثانیه تمام شد" };
    },
  }),

  spinDailyWheel: defineAction({
    request: z.object({ userId: z.number().int().positive() }),
    response: wheelResponseSchema,
    async handler(ctx, args): Promise<z.infer<typeof wheelResponseSchema>> {
      const db = ctx.db<typeof schema>();
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      if (!user || !user.isActive || user.accessRole !== "user") return { ok: true, reward: 0, message: "گردانه برای این حساب در دسترس نیست" };
      const spinDay = tehranDayKey();
      const existing = (await db.select().from(schema.dailyWheelSpins).where(and(eq(schema.dailyWheelSpins.userId, user.id), eq(schema.dailyWheelSpins.spinDay, spinDay))).limit(1))[0];
      if (existing) return { ok: true, reward: 0, message: "چرخش امروز را انجام داده‌ای" };
      const rewards = [10, 15, 25, 50] as const;
      const reward = rewards[Math.floor(Math.random() * rewards.length)] ?? 10;
      const inserted = (await db.insert(schema.dailyWheelSpins).values({ userId: user.id, spinDay, reward }).onConflictDoNothing().returning({ id: schema.dailyWheelSpins.id }))[0];
      if (!inserted) return { ok: true, reward: 0, message: "چرخش امروز را انجام داده‌ای" };
      await db.batch([
        db.update(schema.users).set({ coins: user.coins + reward }).where(eq(schema.users.id, user.id)),
        db.insert(schema.transactions).values({ userId: user.id, amount: reward, kind: "daily_wheel", note: "جایزه گردانه روزانه" }),
      ]);
      ctx.invalidateQueries();
      return { ok: true, reward, message: `${reward} سکه از گردانه گرفتی` };
    },
  }),

  solveDetectiveCase: defineAction({
    request: z.object({ userId: z.number().int().positive(), accused: z.enum(["ahmad", "reza", "sohrab"]) }),
    response: detectiveResponseSchema,
    async handler(ctx, args): Promise<z.infer<typeof detectiveResponseSchema>> {
      const db = ctx.db<typeof schema>();
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      if (!user || !user.isActive || user.accessRole !== "user") return { ok: true, correct: false, reward: 0, message: "پرونده برای این حساب در دسترس نیست" };
      const attempts = await db.select().from(schema.detectiveAttempts).where(and(eq(schema.detectiveAttempts.userId, user.id), eq(schema.detectiveAttempts.caseKey, "club-safe-1")));
      if (attempts.some((attempt) => attempt.correct)) return { ok: true, correct: true, reward: 0, message: "این پرونده را قبلاً حل کرده‌ای" };
      if (!attempts.length && user.coins < DETECTIVE_ENTRY) return { ok: true, correct: false, reward: 0, message: "برای ورود به پرونده ۲۰ سکه لازم است" };
      const correct = args.accused === "reza";
      const balanceAfterEntry = user.coins - (attempts.length ? 0 : DETECTIVE_ENTRY);
      const reward = correct ? DETECTIVE_REWARD : 0;
      const attemptWrite = db.insert(schema.detectiveAttempts).values({ userId: user.id, caseKey: "club-safe-1", accused: args.accused, correct, reward });
      const balanceWrite = db.update(schema.users).set({ coins: balanceAfterEntry + reward }).where(eq(schema.users.id, user.id));
      if (!attempts.length && reward) {
        await db.batch([attemptWrite, balanceWrite, db.insert(schema.transactions).values({ userId: user.id, amount: -DETECTIVE_ENTRY, kind: "detective_entry", note: "ورودی پرونده کارآگاهی" }), db.insert(schema.transactions).values({ userId: user.id, amount: reward, kind: "detective_reward", note: "حل پرونده کارآگاهی" })]);
      } else if (!attempts.length) {
        await db.batch([attemptWrite, balanceWrite, db.insert(schema.transactions).values({ userId: user.id, amount: -DETECTIVE_ENTRY, kind: "detective_entry", note: "ورودی پرونده کارآگاهی" })]);
      } else if (reward) {
        await db.batch([attemptWrite, balanceWrite, db.insert(schema.transactions).values({ userId: user.id, amount: reward, kind: "detective_reward", note: "حل پرونده کارآگاهی" })]);
      } else {
        await db.batch([attemptWrite, balanceWrite]);
      }
      ctx.invalidateQueries();
      return { ok: true, correct, reward, message: correct ? "سرنخ ساعت، رضا را لو داد؛ ۲۰۰ سکه گرفتی" : "این مظنون با همه سرنخ‌ها جور نیست؛ دوباره بررسی کن" };
    },
  }),

  buyCoins: defineAction({ request: z.object({ userId: z.number(), amount: z.union([z.literal(100), z.literal(250), z.literal(600)]) }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0]; if (user) { await db.update(schema.users).set({ coins: user.coins + args.amount }).where(eq(schema.users.id, user.id)); await db.insert(schema.transactions).values({ userId: user.id, amount: args.amount, kind: "test_purchase", note: "خرید آزمایشی بسته سکه" }); } ctx.invalidateQueries(); return { ok: true, message: "بسته آزمایشی اضافه شد" }; } }),

  respondToScheduledGame: defineAction({
    request: z.object({ userId: z.number().int().positive(), scheduledGameId: z.number().int().positive(), response: z.enum(["play", "watch"]) }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      const game = (await db.select().from(schema.scheduledGroupGames).where(eq(schema.scheduledGroupGames.id, args.scheduledGameId)).limit(1))[0];
      if (!user || !user.isActive) return { ok: true, message: "این حساب امکان ثبت حضور ندارد" };
      if (!game || game.status === "finished") return { ok: true, message: "این برنامه دیگر برای ثبت حضور باز نیست" };
      await db.insert(schema.scheduledGameResponses).values({ scheduledGameId: game.id, userId: user.id, response: args.response }).onConflictDoUpdate({
        target: [schema.scheduledGameResponses.scheduledGameId, schema.scheduledGameResponses.userId],
        set: { response: args.response, createdAt: new Date() },
      });
      ctx.invalidateQueries();
      return { ok: true, message: args.response === "play" ? "برای بازی ثبت شدی" : "برای تماشا ثبت شدی" };
    },
  }),

  startGameSession: defineAction({
    request: z.object({ userId: z.number().int().positive(), gameType: gameTypeSchema, stake: z.number().int().min(0).max(200), playerCount: z.number().int().min(2).max(4).default(2) }),
    response: gameSessionResponse,
    async handler(ctx, args): Promise<GameSessionView> {
      const db = ctx.db<typeof schema>();
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      if (!user || !user.isTest || !DEMO_PHONES.has(user.phone)) throw new Error("Test account unavailable");
      const activeSessions = await db.select().from(schema.gameSessions).where(and(eq(schema.gameSessions.userId, user.id), eq(schema.gameSessions.status, "active"))).orderBy(desc(schema.gameSessions.id));
      const resumable = activeSessions.find((session) => session.gameType === args.gameType && session.stake === args.stake);
      if (resumable) {
        const savedState = JSON.parse(resumable.stateJson) as GameState;
        return gameView(resumable.id, resumable.gameType, savedState, { coins: user.coins, xp: user.xp });
      }
      if (user.coins < args.stake) {
        return { ok: true, sessionId: 0, gameType: args.gameType, status: "finished", prompt: "بازی شروع نشد", board: [], options: [], result: "برای این ورودی سکه کافی نیست.", won: false, coins: user.coins, xp: user.xp, boardKind: args.gameType === "منچ" ? "ludo" : args.gameType === "مارپله" ? "snakes" : "classic", die: null, currentPlayerIndex: 0, players: [], ludoPieces: [], snakePositions: [], movablePieceIds: [], safeCells: [...LUDO_SAFE_CELLS], eventQueue: [] };
      }
      await db.update(schema.gameSessions).set({ status: "finished", updatedAt: new Date() }).where(and(eq(schema.gameSessions.userId, user.id), eq(schema.gameSessions.status, "active")));
      const state = initialGameState(args.gameType, args.playerCount, user.id, user.name);
      const inserted = (await db.insert(schema.gameSessions).values({ userId: user.id, gameType: args.gameType, stake: args.stake, stateJson: JSON.stringify(state) }).returning({ id: schema.gameSessions.id }))[0];
      if (!inserted) throw new Error("Game session creation failed");
      if (args.stake > 0) {
        await db.update(schema.users).set({ coins: user.coins - args.stake }).where(eq(schema.users.id, user.id));
        await db.insert(schema.transactions).values({ userId: user.id, amount: -args.stake, kind: "game_entry", note: `ورودی بازی ${args.gameType}` });
      }
      ctx.invalidateQueries();
      return gameView(inserted.id, args.gameType, state, { coins: user.coins - args.stake, xp: user.xp });
    },
  }),

  rollBoardGame: defineAction({
    request: z.object({ userId: z.number().int().positive(), sessionId: z.number().int().positive() }),
    response: gameSessionResponse,
    async handler(ctx, args): Promise<GameSessionView> {
      const db = ctx.db<typeof schema>();
      const session = (await db.select().from(schema.gameSessions).where(and(eq(schema.gameSessions.id, args.sessionId), eq(schema.gameSessions.userId, args.userId))).limit(1))[0];
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      if (!session || !user || session.status !== "active" || (session.gameType !== "منچ" && session.gameType !== "مارپله")) throw new Error("Active board game unavailable");
      const state = JSON.parse(session.stateJson) as GameState;
      state.eventQueue = [];
      if ((state.currentPlayerIndex ?? 0) !== 0) throw new Error("Not this user's turn");
      if (session.gameType === "منچ") {
        if (state.die) throw new Error("Choose a movable piece first");
        rollLudoForCurrent(state);
        if ((state.currentPlayerIndex ?? 0) !== 0) playLudoBots(state);
      } else {
        applySnakesTurn(state);
        if ((state.currentPlayerIndex ?? 0) !== 0) playSnakesBots(state);
      }
      const nextUser = await persistBoardTurn(ctx, session, state, user);
      ctx.invalidateQueries();
      return gameView(session.id, session.gameType, state, { coins: nextUser.coins, xp: nextUser.xp });
    },
  }),

  moveLudoPiece: defineAction({
    request: z.object({ userId: z.number().int().positive(), sessionId: z.number().int().positive(), pieceId: z.number().int().min(0).max(15) }),
    response: gameSessionResponse,
    async handler(ctx, args): Promise<GameSessionView> {
      const db = ctx.db<typeof schema>();
      const session = (await db.select().from(schema.gameSessions).where(and(eq(schema.gameSessions.id, args.sessionId), eq(schema.gameSessions.userId, args.userId))).limit(1))[0];
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      if (!session || !user || session.status !== "active" || session.gameType !== "منچ") throw new Error("Active Ludo session unavailable");
      const state = JSON.parse(session.stateJson) as GameState;
      if ((state.currentPlayerIndex ?? 0) !== 0 || !state.die) throw new Error("Roll the die on your turn first");
      if (!applyLudoPiece(state, args.pieceId, state.die)) throw new Error("Invalid piece move");
      if (!state.finished && (state.currentPlayerIndex ?? 0) !== 0) playLudoBots(state);
      const nextUser = await persistBoardTurn(ctx, session, state, user);
      ctx.invalidateQueries();
      return gameView(session.id, session.gameType, state, { coins: nextUser.coins, xp: nextUser.xp });
    },
  }),

  gameMove: defineAction({
    request: z.object({ userId: z.number().int().positive(), sessionId: z.number().int().positive(), move: z.number().int().min(0).max(3) }),
    response: gameSessionResponse,
    async handler(ctx, args): Promise<GameSessionView> {
      const db = ctx.db<typeof schema>();
      const session = (await db.select().from(schema.gameSessions).where(and(eq(schema.gameSessions.id, args.sessionId), eq(schema.gameSessions.userId, args.userId))).limit(1))[0];
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      if (!session || !user || session.status !== "active") throw new Error("Active game session unavailable");
      const state = JSON.parse(session.stateJson) as GameState;
      const gameType = session.gameType;
      if (gameType === "منچ" || gameType === "مارپله") throw new Error("Use board game actions");
      if (gameType === "۲۱") {
        if (args.move === 0) {
          state.hand.push(randomCard());
          const total = sum21(state.hand);
          state.result = `کارت تازه آمد؛ جمع دست شما ${total} شد.`;
          if (total > 21) { state.finished = true; state.won = false; state.result = `جمع دست شما ${total} شد؛ سوختید.`; }
        } else {
          while (sum21(state.botHand) < 17) state.botHand.push(randomCard());
          const yours = sum21(state.hand); const theirs = sum21(state.botHand);
          state.finished = true; state.won = yours <= 21 && (theirs > 21 || yours > theirs);
          state.result = state.won ? `شما ${yours}؛ حریف ${theirs}. این دست را بردید.` : `شما ${yours}؛ حریف ${theirs}. این دست را باختید.`;
        }
      } else if (gameType === "پوکر") {
        if (args.move < 3) state.hand[args.move] = randomCard();
        const yours = pairScore(state.hand); const theirs = pairScore(state.botHand);
        state.finished = true; state.won = yours >= theirs;
        state.result = state.won ? "ترکیب کارت‌های شما قوی‌تر بود؛ بردید." : "ترکیب حریف قوی‌تر بود؛ باختید.";
      } else if (gameType === "حکم") {
        const index = Math.min(args.move, Math.max(0, state.hand.length - 1));
        const yourCard = state.hand.splice(index, 1)[0] ?? 0; const botCard = state.botHand.splice(0, 1)[0] ?? 0;
        if (yourCard >= botCard) state.playerScore += 1; else state.botScore += 1;
        state.result = `شما ${cardName(yourCard)} و حریف ${cardName(botCard)} بازی کرد.`;
        state.round += 1;
        if (!state.hand.length) { state.finished = true; state.won = state.playerScore >= state.botScore; state.result += state.won ? " مجموع سه دست را بردید." : " مجموع سه دست را باختید."; }
      } else if (gameType === "کوئیز") {
        state.finished = true; state.won = args.move === state.target;
        state.result = state.won ? "پاسخ درست بود." : `پاسخ درست گزینه ${state.target + 1} بود.`;
      } else {
        state.finished = true; state.won = args.move === state.target;
        state.result = state.won ? "تحلیل درست بود؛ مافیا پیدا شد." : `رأی اشتباه بود؛ مافیا نفر ${state.target + 1} بود.`;
      }
      await db.update(schema.gameSessions).set({ status: state.finished ? "finished" : "active", stateJson: JSON.stringify(state), updatedAt: new Date() }).where(eq(schema.gameSessions.id, session.id));
      let nextUser = user;
      if (state.finished) {
        const reward = state.won ? Math.max(20, session.stake * 2) : 0;
        const xpGain = state.won ? 10 : 2;
        await db.update(schema.users).set({ coins: user.coins + reward, xp: user.xp + xpGain, wins: user.wins + (state.won ? 1 : 0) }).where(eq(schema.users.id, user.id));
        if (reward > 0) await db.insert(schema.transactions).values({ userId: user.id, amount: reward, kind: "game_reward", note: `جایزه بازی ${gameType}` });
        const finishedRoom = (await db.insert(schema.gameRooms).values({ gameType, hostId: user.id, status: "finished", stake: session.stake, winnerId: state.won ? user.id : null }).returning({ id: schema.gameRooms.id }))[0];
        if (finishedRoom) await db.insert(schema.scoreEvents).values({ userId: user.id, sourceType: "game", sourceId: finishedRoom.id, outcome: state.won ? "win" : "loss", points: xpGain }).onConflictDoNothing();
        nextUser = { ...user, coins: user.coins + reward, xp: user.xp + xpGain, wins: user.wins + (state.won ? 1 : 0) };
      }
      ctx.invalidateQueries();
      return gameView(session.id, gameType, state, { coins: nextUser.coins, xp: nextUser.xp });
    },
  }),

  playGame: defineAction({ request: z.object({ userId: z.number(), gameType: quickGameTypeSchema, stake: z.number().int().min(0).max(200), choice: z.number().int().min(0).max(2) }), response: z.object({ ok: z.literal(true), won: z.boolean(), reward: z.number(), roomId: z.number().nullable(), outcome: z.string() }), async handler(ctx, args): Promise<{ ok: true; won: boolean; reward: number; roomId: number | null; outcome: string }> { const db = ctx.db<typeof schema>(); const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0]; if (!user || user.coins < args.stake) return { ok: true, won: false, reward: 0, roomId: null, outcome: "برای این دست سکه کافی نیست" }; const winningChoice = Math.floor(Math.random() * 3); const won = args.choice === winningChoice; const reward = won ? Math.max(20, args.stake * 2) : 0; const room = (await db.insert(schema.gameRooms).values({ gameType: args.gameType, hostId: args.userId, status: "finished", stake: args.stake, winnerId: won ? args.userId : null }).returning({ id: schema.gameRooms.id }))[0]; await db.update(schema.users).set({ coins: user.coins - args.stake + reward, xp: user.xp + (won ? 10 : 2), wins: user.wins + (won ? 1 : 0) }).where(eq(schema.users.id, user.id)); await db.insert(schema.transactions).values({ userId: user.id, amount: reward - args.stake, kind: "game", note: `${args.gameType}: ${won ? "برد" : "باخت"}` }); if (room) await db.insert(schema.scoreEvents).values({ userId: user.id, sourceType: "game", sourceId: room.id, outcome: won ? "win" : "loss", points: won ? 10 : 2 }).onConflictDoNothing(); ctx.invalidateQueries(); const labels = ["انتخاب اول", "انتخاب دوم", "انتخاب سوم"]; return { ok: true, won, reward, roomId: room?.id ?? null, outcome: won ? "انتخابت درست بود" : `نتیجه دست: ${labels[winningChoice] ?? "انتخاب دیگر"}` }; } }),

  createLiveGame: defineAction({ request: z.object({ userId: z.number(), gameType: gameTypeSchema, stake: z.number().int().min(0).max(200) }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); await db.insert(schema.gameRooms).values({ gameType: args.gameType, hostId: args.userId, stake: args.stake, status: "live" }); ctx.invalidateQueries(); return { ok: true, message: "اتاق زنده ساخته شد" }; } }),

  watchGame: defineAction({ request: z.object({ gameRoomId: z.number(), userId: z.number(), favoriteTeam: z.enum(["تیم میزبان", "تیم مهمان"]) }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); const room = (await db.select().from(schema.gameRooms).where(and(eq(schema.gameRooms.id, args.gameRoomId), eq(schema.gameRooms.status, "live"))).limit(1))[0]; if (!room) return { ok: true, message: "اتاق زنده پیدا نشد" }; const players = await liveRoomPlayers(ctx, room.id, room.hostId); if (players.includes(args.userId)) return { ok: true, message: "شما به‌عنوان بازیکن به ویس میز متصل هستید" }; await db.insert(schema.gameSpectators).values({ gameRoomId: args.gameRoomId, userId: args.userId, favoriteUserId: null, favoriteTeam: args.favoriteTeam }).onConflictDoUpdate({ target: [schema.gameSpectators.gameRoomId, schema.gameSpectators.userId], set: { favoriteUserId: null, favoriteTeam: args.favoriteTeam } }); const spectators = await db.select().from(schema.gameSpectators).where(eq(schema.gameSpectators.gameRoomId, args.gameRoomId)); await db.update(schema.gameRooms).set({ spectators: spectators.length }).where(eq(schema.gameRooms.id, room.id)); ctx.invalidateQueries(); return { ok: true, message: `${args.favoriteTeam} ثبت شد؛ وارد اتاق تماشاچی شدید` }; } }),

  sendLiveVoice: defineAction({
    request: z.object({ gameRoomId: z.number().int().positive(), userId: z.number().int().positive(), audience: z.enum(["room", "reward_announcement"]), dataBase64: z.string().min(1), mimeType: z.enum(["audio/webm", "audio/mp4", "audio/mpeg"]), durationMs: z.number().int().min(200).max(20000) }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const room = (await db.select().from(schema.gameRooms).where(and(eq(schema.gameRooms.id, args.gameRoomId), eq(schema.gameRooms.status, "live"))).limit(1))[0];
      if (!room) return { ok: true, message: "اتاق زنده بسته شده است" };
      const players = await liveRoomPlayers(ctx, room.id, room.hostId);
      const spectator = (await db.select().from(schema.gameSpectators).where(and(eq(schema.gameSpectators.gameRoomId, room.id), eq(schema.gameSpectators.userId, args.userId))).limit(1))[0];
      const senderRole = players.includes(args.userId) ? "player" as const : spectator ? "spectator" as const : null;
      if (!senderRole) return { ok: true, message: "ابتدا وارد اتاق زنده شوید" };
      let audience: "player_room" | "spectator_room" | "reward_announcement" = senderRole === "player" ? "player_room" : "spectator_room";
      if (senderRole === "spectator" && args.audience === "reward_announcement") {
        const gift = (await db.select().from(schema.spectatorGifts).where(and(eq(schema.spectatorGifts.gameRoomId, room.id), eq(schema.spectatorGifts.spectatorId, args.userId), eq(schema.spectatorGifts.status, "escrow"))).limit(1))[0];
        if (!gift || gift.amount < 1) return { ok: true, message: "اول مبلغ هدیه را به امانت بسپارید؛ سپس اعلام صوتی برای بازیکنان فعال می‌شود" };
        audience = "reward_announcement";
      }
      const binary = Uint8Array.from(atob(args.dataBase64), (char) => char.charCodeAt(0));
      if (binary.byteLength > 2 * 1024 * 1024) return { ok: true, message: "ویس زنده باید کمتر از ۲ مگابایت باشد" };
      const key = `live-voice/${room.id}/${Date.now()}-${args.userId}.${args.mimeType === "audio/mpeg" ? "mp3" : args.mimeType === "audio/mp4" ? "m4a" : "webm"}`;
      await ctx.blobs.put(key, binary, { contentType: args.mimeType });
      await db.insert(schema.liveVoiceClips).values({ gameRoomId: room.id, senderId: args.userId, senderRole, audience, blobKey: key, mimeType: args.mimeType, durationMs: args.durationMs });
      ctx.invalidateQueries();
      return { ok: true, message: audience === "reward_announcement" ? "اعلام هدیه فقط این‌بار برای بازیکنان هم فرستاده شد" : senderRole === "player" ? "صدای بازیکن برای اتاق بازی و تماشاچیان پخش شد" : "صدای شما فقط در اتاق تماشاچیان پخش شد" };
    },
  }),

  advanceLiveDirector: defineAction({
    request: z.object({ gameRoomId: z.number().int().positive(), userId: z.number().int().positive() }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const room = (await db.select().from(schema.gameRooms).where(and(eq(schema.gameRooms.id, args.gameRoomId), eq(schema.gameRooms.status, "live"), eq(schema.gameRooms.hostId, args.userId))).limit(1))[0];
      if (!room) return { ok: true, message: "فقط میزبان می‌تواند دور بعد را به داور هوشمند بسپارد" };
      const players = await liveRoomPlayers(ctx, room.id, room.hostId);
      const names = await db.select().from(schema.users).where(inArray(schema.users.id, players));
      const hostName = names.find((user) => user.id === room.hostId)?.name ?? "میزبان";
      const guestName = names.find((user) => user.id !== room.hostId)?.name ?? "مهمان";
      const decision = await ctx.inference.complete(`در نقش داور و گزارشگر یک مسابقه دوستانه فارسی عمل کن. بازی: ${room.gameType}. دور بعد: ${room.turnNumber + 1}. بازیکنان: ${hostName} و ${guestName}. وضعیت قبلی: ${room.lastEvent}. درصد شانس قبلی میزبان: ${room.hostChance}. یک رخداد کوتاه و بی‌طرف برای پیشروی مسابقه بساز، درصد شانس تازه میزبان را بین ۲۰ تا ۸۰ تعیین کن، و واکنش هر بازیکن را مشخص کن. لحن گزارش زنده، کوتاه و محترمانه باشد.`, { schema: directorDecisionSchema });
      await db.update(schema.gameRooms).set({ turnNumber: room.turnNumber + 1, hostChance: decision.hostChance, commentary: decision.commentary, lastEvent: decision.event, hostMood: decision.hostMood, guestMood: decision.guestMood }).where(eq(schema.gameRooms.id, room.id));
      ctx.invalidateQueries();
      return { ok: true, message: `دور ${room.turnNumber + 1} با داوری هوشمند اجرا شد` };
    },
  }),

  cheerLiveGame: defineAction({
    request: z.object({ gameRoomId: z.number().int().positive(), userId: z.number().int().positive(), reaction: z.enum(["👏", "🔥", "❤️", "🎉"]) }), response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const room = (await db.select().from(schema.gameRooms).where(and(eq(schema.gameRooms.id, args.gameRoomId), eq(schema.gameRooms.status, "live"))).limit(1))[0];
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      if (!room || !user) return { ok: true, message: "میز زنده پیدا نشد" };
      const recent = await db.select().from(schema.gameCheers).where(and(eq(schema.gameCheers.gameRoomId, room.id), eq(schema.gameCheers.senderId, user.id))).orderBy(desc(schema.gameCheers.id)).limit(6);
      if (recent.length >= 6 && recent[0] && Date.now() - recent[0].createdAt.getTime() < 15_000) return { ok: true, message: "تشویق‌ها رسید؛ چند لحظه بعد دوباره بفرست" };
      await db.insert(schema.gameCheers).values({ gameRoomId: room.id, senderId: user.id, reaction: args.reaction });
      ctx.invalidateQueries();
      return { ok: true, message: "تشویق شما روی پخش زنده نمایش داده شد" };
    },
  }),

  addSpectatorGift: defineAction({
    request: z.object({ gameRoomId: z.number().int().positive(), userId: z.number().int().positive(), amount: z.number().int().min(1).max(500) }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const room = (await db.select().from(schema.gameRooms).where(and(eq(schema.gameRooms.id, args.gameRoomId), eq(schema.gameRooms.status, "live"))).limit(1))[0];
      const spectator = (await db.select().from(schema.gameSpectators).where(and(eq(schema.gameSpectators.gameRoomId, args.gameRoomId), eq(schema.gameSpectators.userId, args.userId))).limit(1))[0];
      const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
      if (!room || !spectator) return { ok: true, message: "ابتدا به‌عنوان تماشاچی وارد میز شوید" };
      if (!user || user.coins < args.amount) return { ok: true, message: "سکه کافی برای افزایش هدیه ندارید" };
      const existing = (await db.select().from(schema.spectatorGifts).where(and(eq(schema.spectatorGifts.gameRoomId, room.id), eq(schema.spectatorGifts.spectatorId, user.id))).limit(1))[0];
      if (existing && existing.status !== "escrow") return { ok: true, message: "هدیه این میز قبلاً تسویه شده است" };
      const nextAmount = (existing?.amount ?? 0) + args.amount;
      if (nextAmount > 2000) return { ok: true, message: "سقف هدیه هر تماشاچی برای یک میز ۲۰۰۰ سکه است" };
      if (existing) await db.update(schema.spectatorGifts).set({ amount: nextAmount }).where(eq(schema.spectatorGifts.id, existing.id));
      else await db.insert(schema.spectatorGifts).values({ gameRoomId: room.id, spectatorId: user.id, amount: args.amount });
      await db.update(schema.users).set({ coins: user.coins - args.amount }).where(eq(schema.users.id, user.id));
      await db.insert(schema.transactions).values({ userId: user.id, amount: -args.amount, kind: "spectator_gift_escrow", note: `امانت هدیه میز ${room.id}` });
      ctx.invalidateQueries();
      return { ok: true, message: `${args.amount} سکه به امانت هدیه اضافه شد؛ مجموع شما ${nextAmount} سکه` };
    },
  }),

  placeBet: defineAction({ request: z.object({ gameRoomId: z.number(), userId: z.number(), favoriteTeam: z.enum(["تیم میزبان", "تیم مهمان"]), amount: z.number().int().min(1).max(500) }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); const room = (await db.select().from(schema.gameRooms).where(and(eq(schema.gameRooms.id, args.gameRoomId), eq(schema.gameRooms.status, "live"))).limit(1))[0]; const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0]; if (!room) return { ok: true, message: "اتاق زنده پیدا نشد" }; if (!user || user.coins < args.amount) return { ok: true, message: "سکه کافی نیست" }; const eligiblePlayers = (await db.select().from(schema.users)).filter((candidate) => candidate.isTest && DEMO_PHONES.has(candidate.phone) && !candidate.isAdmin); const guest = eligiblePlayers.find((candidate) => candidate.id !== room.hostId) ?? eligiblePlayers[0]; const targetUserId = args.favoriteTeam === "تیم میزبان" ? room.hostId : (guest?.id ?? room.hostId); await db.insert(schema.bets).values({ gameRoomId: args.gameRoomId, userId: args.userId, targetUserId, amount: args.amount }); await db.update(schema.users).set({ coins: user.coins - args.amount }).where(eq(schema.users.id, user.id)); await db.insert(schema.transactions).values({ userId: user.id, amount: -args.amount, kind: "bet", note: `شرط روی ${args.favoriteTeam}` }); ctx.invalidateQueries(); return { ok: true, message: `شرط روی ${args.favoriteTeam} ثبت شد` }; } }),

  settleLiveGame: defineAction({ request: z.object({ gameRoomId: z.number().int().positive(), userId: z.number().int().positive(), winnerTeam: z.enum(["تیم میزبان", "تیم مهمان"]) }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); const room = (await db.select().from(schema.gameRooms).where(and(eq(schema.gameRooms.id, args.gameRoomId), eq(schema.gameRooms.status, "live"), eq(schema.gameRooms.hostId, args.userId))).limit(1))[0]; if (!room) return { ok: true, message: "فقط میزبان می‌تواند نتیجه این بازی زنده را ثبت کند" }; const players = await liveRoomPlayers(ctx, room.id, room.hostId); const winnerId = args.winnerTeam === "تیم میزبان" ? room.hostId : (players.find((id) => id !== room.hostId) ?? room.hostId); await db.update(schema.gameRooms).set({ status: "finished", winnerId }).where(eq(schema.gameRooms.id, room.id)); const openBets = await db.select().from(schema.bets).where(and(eq(schema.bets.gameRoomId, room.id), eq(schema.bets.status, "open")));
      for (const bet of openBets) { const won = bet.targetUserId === winnerId; await db.update(schema.bets).set({ status: won ? "won" : "lost" }).where(eq(schema.bets.id, bet.id)); const bettor = (await db.select().from(schema.users).where(eq(schema.users.id, bet.userId)).limit(1))[0]; if (won && bettor) { const reward = bet.amount * 2; await db.update(schema.users).set({ coins: bettor.coins + reward }).where(eq(schema.users.id, bettor.id)); await db.insert(schema.transactions).values({ userId: bettor.id, amount: reward, kind: "bet_reward", note: `برد شرط ${args.winnerTeam}` }); } await db.insert(schema.scoreEvents).values({ userId: bet.userId, sourceType: "bet", sourceId: bet.id, outcome: won ? "win" : "loss", points: won ? 5 : 0 }).onConflictDoNothing(); }
      const gifts = await settleGiftEscrow(ctx, room.id, winnerId);
      ctx.invalidateQueries(); return { ok: true, message: `نتیجه ${args.winnerTeam} ثبت شد؛ ${openBets.length} شرط و ${gifts.count} هدیه تسویه شد. ${gifts.payout} سکه پس از کسر ${gifts.fee} سکه کارمزد به برنده رسید` }; } }),

  adminCreateTournament: defineAction({ request: z.object({ userId: z.number(), gameType: gameTypeSchema, entryFee: z.number().int().min(0).max(500) }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
    const db = ctx.db<typeof schema>(); const admin = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
    if (!admin?.isAdmin || !DEMO_PHONES.has(admin.phone)) return { ok: true, message: "فقط مدیر می‌تواند دوره تازه بسازد" };
    const latest = (await db.select().from(schema.tournaments).orderBy(desc(schema.tournaments.id)).limit(1))[0];
    if (latest && latest.status !== "finished") return { ok: true, message: "ابتدا دوره فعال را به پایان برسانید" };
    await db.insert(schema.tournaments).values({ title: `تورنمنت هفتگی ${args.gameType}`, gameType: args.gameType, entryFee: args.entryFee });
    ctx.invalidateQueries(); return { ok: true, message: "ثبت‌نام تورنمنت هفتگی باز شد" };
  } }),

  registerTournament: defineAction({ request: z.object({ userId: z.number().int().positive(), tournamentId: z.number().int().positive() }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
    const db = ctx.db<typeof schema>();
    const tournament = (await db.select().from(schema.tournaments).where(eq(schema.tournaments.id, args.tournamentId)).limit(1))[0];
    const user = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
    const membership = (await db.select().from(schema.scoreGroupMembers).where(eq(schema.scoreGroupMembers.userId, args.userId)).limit(1))[0];
    if (!tournament || tournament.status !== "registration") return { ok: true, message: "ثبت‌نام این دوره بسته است" };
    if (!user || !membership) return { ok: true, message: "برای ثبت‌نام باید عضو یک گروه باشید" };
    const gameAvatar = (await db.select().from(schema.playerGameAvatars).where(eq(schema.playerGameAvatars.userId, user.id)).limit(1))[0];
    if (!gameAvatar) return { ok: true, message: "پیش از ثبت‌نام، آواتار بازیکن خود را در اتاق سرگرمی بسازید" };
    if (user.coins < tournament.entryFee) return { ok: true, message: "سکه کافی برای ورودی گروه ندارید" };
    const existing = (await db.select().from(schema.tournamentRegistrations).where(and(eq(schema.tournamentRegistrations.tournamentId, tournament.id), eq(schema.tournamentRegistrations.groupId, membership.groupId))).limit(1))[0];
    if (existing) return { ok: true, message: "گروه شما قبلاً ثبت‌نام کرده است" };
    await db.insert(schema.tournamentRegistrations).values({ tournamentId: tournament.id, groupId: membership.groupId, registeredByUserId: user.id });
    await db.update(schema.users).set({ coins: user.coins - tournament.entryFee }).where(eq(schema.users.id, user.id));
    await db.update(schema.tournaments).set({ prizePool: tournament.prizePool + tournament.entryFee }).where(eq(schema.tournaments.id, tournament.id));
    await db.insert(schema.transactions).values({ userId: user.id, amount: -tournament.entryFee, kind: "tournament_entry", note: `ورودی گروه در ${tournament.title}` });
    ctx.invalidateQueries(); return { ok: true, message: "گروه ثبت‌نام شد و ورودی به جایزه اضافه شد" };
  } }),

  adminStartTournament: defineAction({ request: z.object({ userId: z.number(), tournamentId: z.number() }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
    const db = ctx.db<typeof schema>(); const admin = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
    const tournament = (await db.select().from(schema.tournaments).where(eq(schema.tournaments.id, args.tournamentId)).limit(1))[0];
    if (!admin?.isAdmin || !DEMO_PHONES.has(admin.phone) || !tournament || tournament.status !== "registration") return { ok: true, message: "شروع این دوره مجاز نیست" };
    const registrations = await db.select().from(schema.tournamentRegistrations).where(eq(schema.tournamentRegistrations.tournamentId, tournament.id));
    if (registrations.length < 2) return { ok: true, message: "حداقل دو گروه باید ثبت‌نام کنند" };
    const existingMatches = await db.select().from(schema.tournamentMatches).where(eq(schema.tournamentMatches.tournamentId, tournament.id));
    if (!existingMatches.length) {
      for (let home = 0; home < registrations.length; home += 1) for (let away = home + 1; away < registrations.length; away += 1) {
        const homeRegistration = registrations[home]; const awayRegistration = registrations[away];
        if (homeRegistration && awayRegistration) await db.insert(schema.tournamentMatches).values({ tournamentId: tournament.id, homeGroupId: homeRegistration.groupId, awayGroupId: awayRegistration.groupId });
      }
    }
    await db.update(schema.tournaments).set({ status: "live" }).where(eq(schema.tournaments.id, tournament.id));
    ctx.invalidateQueries(); return { ok: true, message: "مسابقات دوره‌ای ساخته و تورنمنت شروع شد" };
  } }),

  adminStartTournamentMatch: defineAction({ request: z.object({ userId: z.number(), matchId: z.number() }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
    const db = ctx.db<typeof schema>(); const admin = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
    const match = (await db.select().from(schema.tournamentMatches).where(eq(schema.tournamentMatches.id, args.matchId)).limit(1))[0];
    if (!admin?.isAdmin || !DEMO_PHONES.has(admin.phone) || !match || match.status !== "scheduled") return { ok: true, message: "شروع این مسابقه مجاز نیست" };
    const tournament = (await db.select().from(schema.tournaments).where(eq(schema.tournaments.id, match.tournamentId)).limit(1))[0];
    if (!tournament || tournament.status !== "live") return { ok: true, message: "تورنمنت فعال نیست" };
    const anotherLive = (await db.select().from(schema.tournamentMatches).where(and(eq(schema.tournamentMatches.tournamentId, tournament.id), eq(schema.tournamentMatches.status, "live"))).limit(1))[0];
    if (anotherLive) return { ok: true, message: "ابتدا نتیجه مسابقه زنده را ثبت کنید" };
    const hostMember = (await db.select().from(schema.scoreGroupMembers).where(eq(schema.scoreGroupMembers.groupId, match.homeGroupId)).limit(1))[0];
    if (!hostMember) return { ok: true, message: "گروه میزبان عضو فعال ندارد" };
    const room = (await db.insert(schema.gameRooms).values({ gameType: tournament.gameType, hostId: hostMember.userId, status: "live", stake: 0 }).returning({ id: schema.gameRooms.id }))[0];
    if (!room) return { ok: true, message: "اتاق مسابقه ساخته نشد" };
    await db.update(schema.tournamentMatches).set({ status: "live", gameRoomId: room.id }).where(eq(schema.tournamentMatches.id, match.id));
    ctx.invalidateQueries(); return { ok: true, message: "مسابقه زنده شد؛ بازیکنان و تماشاچی‌ها می‌توانند وارد شوند" };
  } }),

  adminFinishTournamentMatch: defineAction({ request: z.object({ userId: z.number(), matchId: z.number(), winnerGroupId: z.number() }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
    const db = ctx.db<typeof schema>(); const admin = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
    const match = (await db.select().from(schema.tournamentMatches).where(eq(schema.tournamentMatches.id, args.matchId)).limit(1))[0];
    if (!admin?.isAdmin || !DEMO_PHONES.has(admin.phone) || !match || match.status !== "live" || (args.winnerGroupId !== match.homeGroupId && args.winnerGroupId !== match.awayGroupId)) return { ok: true, message: "ثبت این نتیجه مجاز نیست" };
    await db.update(schema.tournamentMatches).set({ status: "finished", winnerGroupId: args.winnerGroupId }).where(eq(schema.tournamentMatches.id, match.id));
    const winnerMember = (await db.select().from(schema.scoreGroupMembers).where(eq(schema.scoreGroupMembers.groupId, args.winnerGroupId)).limit(1))[0];
    let giftMessage = "";
    if (match.gameRoomId && winnerMember) {
      await db.update(schema.gameRooms).set({ status: "finished", winnerId: winnerMember.userId }).where(eq(schema.gameRooms.id, match.gameRoomId));
      const gifts = await settleGiftEscrow(ctx, match.gameRoomId, winnerMember.userId);
      giftMessage = gifts.count ? `؛ ${gifts.payout} سکه هدیه بعد از کسر ${gifts.fee} سکه کارمزد به برنده رسید` : "";
    }
    ctx.invalidateQueries(); return { ok: true, message: `نتیجه ثبت شد؛ گروه برنده ۳ امتیاز تورنمنت گرفت${giftMessage}` };
  } }),

  adminFinishTournament: defineAction({ request: z.object({ userId: z.number(), tournamentId: z.number(), championGroupId: z.number() }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
    const db = ctx.db<typeof schema>(); const admin = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
    const tournament = (await db.select().from(schema.tournaments).where(eq(schema.tournaments.id, args.tournamentId)).limit(1))[0];
    if (!admin?.isAdmin || !DEMO_PHONES.has(admin.phone) || !tournament || tournament.status !== "live") return { ok: true, message: "پایان این دوره مجاز نیست" };
    const matches = await db.select().from(schema.tournamentMatches).where(eq(schema.tournamentMatches.tournamentId, tournament.id));
    if (!matches.length || matches.some((match) => match.status !== "finished")) return { ok: true, message: "ابتدا نتیجه همه مسابقات را ثبت کنید" };
    const registered = (await db.select().from(schema.tournamentRegistrations).where(and(eq(schema.tournamentRegistrations.tournamentId, tournament.id), eq(schema.tournamentRegistrations.groupId, args.championGroupId))).limit(1))[0];
    if (!registered) return { ok: true, message: "قهرمان باید از گروه‌های ثبت‌نام‌شده باشد" };
    const members = await db.select().from(schema.scoreGroupMembers).where(eq(schema.scoreGroupMembers.groupId, args.championGroupId));
    if (!members.length) return { ok: true, message: "گروه قهرمان عضو ندارد" };
    const baseShare = Math.floor(tournament.prizePool / members.length); const remainder = tournament.prizePool - baseShare * members.length;
    for (let index = 0; index < members.length; index += 1) { const member = members[index]; if (!member) continue; const player = (await db.select().from(schema.users).where(eq(schema.users.id, member.userId)).limit(1))[0]; if (!player) continue; const share = baseShare + (index === 0 ? remainder : 0); await db.update(schema.users).set({ coins: player.coins + share }).where(eq(schema.users.id, player.id)); await db.insert(schema.transactions).values({ userId: player.id, amount: share, kind: "tournament_prize", note: `سهم جایزه ${tournament.title}` }); }
    await db.update(schema.tournaments).set({ status: "finished", championGroupId: args.championGroupId, finishedAt: new Date() }).where(eq(schema.tournaments.id, tournament.id));
    ctx.invalidateQueries(); return { ok: true, message: "دوره پایان یافت؛ جایزه بین اعضای گروه قهرمان تقسیم شد" };
  } }),

  setSecretChat: defineAction({ request: z.object({ userId: z.number(), conversationId: z.number(), enabled: z.boolean(), timerMinutes: z.union([z.literal(1), z.literal(5), z.literal(30), z.literal(60)]) }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); const conv = (await db.select().from(schema.conversations).where(eq(schema.conversations.id, args.conversationId)).limit(1))[0]; const member = (await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, args.conversationId), eq(schema.memberships.userId, args.userId))).limit(1))[0]; if (!conv || !member || conv.kind !== "private") return { ok: true, message: "اتاق محرمانه فقط از گفتگوی خصوصی باز می‌شود" }; await db.update(schema.conversations).set({ confidential: args.enabled, secretTimerMinutes: args.timerMinutes }).where(eq(schema.conversations.id, conv.id)); ctx.invalidateQueries(); return { ok: true, message: args.enabled ? `اتاق محرمانه با حذف خودکار ${args.timerMinutes} دقیقه‌ای فعال شد` : "به گفتگوی خصوصی برگشتید" }; } }),

  manageConversation: defineAction({ request: z.object({ userId: z.number(), conversationId: z.number(), action: z.enum(["toggle_confidential", "toggle_mute", "toggle_block", "clear_messages", "clear_media"]) }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); const conv = (await db.select().from(schema.conversations).where(eq(schema.conversations.id, args.conversationId)).limit(1))[0]; const member = (await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, args.conversationId), eq(schema.memberships.userId, args.userId))).limit(1))[0]; if (!conv || !member) return { ok: true, message: "دسترسی به گفتگو ندارید" }; if (args.action === "toggle_confidential") { if (conv.kind !== "private") return { ok: true, message: "حالت محرمانه فقط برای چت خصوصی است" }; await db.update(schema.conversations).set({ confidential: !conv.confidential }).where(eq(schema.conversations.id, conv.id)); }
      if (args.action === "toggle_mute") await db.update(schema.memberships).set({ muted: !member.muted }).where(eq(schema.memberships.id, member.id));
      if (args.action === "toggle_block") await db.update(schema.memberships).set({ blocked: !member.blocked }).where(eq(schema.memberships.id, member.id));
      if (args.action === "clear_messages") await db.delete(schema.messages).where(and(eq(schema.messages.conversationId, conv.id), eq(schema.messages.senderId, args.userId), or(eq(schema.messages.type, "text"), eq(schema.messages.type, "system"))));
      if (args.action === "clear_media") await db.delete(schema.messages).where(and(eq(schema.messages.conversationId, conv.id), eq(schema.messages.senderId, args.userId), or(eq(schema.messages.type, "voice"), eq(schema.messages.type, "image"), eq(schema.messages.type, "video"))));
      ctx.invalidateQueries(); const labels = { toggle_confidential: "حالت محرمانه تغییر کرد", toggle_mute: "وضعیت اعلان تغییر کرد", toggle_block: "وضعیت بلاک تغییر کرد", clear_messages: "پیام‌های شما پاک شد", clear_media: "رسانه‌های شما پاک شد" }; return { ok: true, message: labels[args.action] }; } }),

  updateConversation: defineAction({
    request: z.object({
      userId: z.number(),
      conversationId: z.number(),
      name: z.string().min(2).max(50),
      rules: z.string().max(300),
      channelActivity: z.string().max(80).optional(),
      image: z.object({ dataBase64: z.string().min(1), mimeType: z.enum(["image/jpeg", "image/png", "image/webp"]), filename: z.string().max(100) }).optional(),
    }),
    response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const conv = (await db.select().from(schema.conversations).where(eq(schema.conversations.id, args.conversationId)).limit(1))[0];
      const member = (await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, args.conversationId), eq(schema.memberships.userId, args.userId))).limit(1))[0];
      const allowed = conv ? conv.ownerId === args.userId || (conv.kind === "channel" ? member?.role === "superadmin" : member?.role === "supervisor") : false;
      if (!conv || !member || !allowed) return { ok: true, message: "دسترسی مدیریت این فضا را ندارید" };
      if (conv.kind === "channel" && (!args.channelActivity || args.channelActivity.trim().length < 2)) return { ok: true, message: "حوزه فعالیت کانال را وارد کنید" };
      let imageBlobKey = conv.imageBlobKey;
      if (args.image) {
        const binary = Uint8Array.from(atob(args.image.dataBase64), (char) => char.charCodeAt(0));
        if (binary.byteLength > 5 * 1024 * 1024) return { ok: true, message: "حجم عکس باید کمتر از ۵ مگابایت باشد" };
        imageBlobKey = `conversations/${conv.id}/${Date.now()}-${args.image.filename.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
        await ctx.blobs.put(imageBlobKey, binary, { contentType: args.image.mimeType });
      }
      await db.update(schema.conversations).set({ name: args.name.trim(), description: args.rules.trim(), imageBlobKey, channelActivity: conv.kind === "channel" ? args.channelActivity?.trim() ?? conv.channelActivity : conv.channelActivity }).where(eq(schema.conversations.id, conv.id));
      ctx.invalidateQueries();
      return { ok: true, message: conv.kind === "channel" ? "اطلاعات و عکس کانال ذخیره شد" : "اطلاعات و عکس گروه ذخیره شد" };
    },
  }),

  setMemberRole: defineAction({
    request: z.object({ userId: z.number(), conversationId: z.number(), memberId: z.number(), role: z.enum(["supervisor", "moderator", "superadmin", "admin", "member"]) }), response: okSchema,
    async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
      const db = ctx.db<typeof schema>();
      const conv = (await db.select().from(schema.conversations).where(eq(schema.conversations.id, args.conversationId)).limit(1))[0];
      const actor = (await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, args.conversationId), eq(schema.memberships.userId, args.userId))).limit(1))[0];
      const target = (await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, args.conversationId), eq(schema.memberships.userId, args.memberId))).limit(1))[0];
      const canAssign = conv?.kind === "channel" ? actor?.role === "owner" || actor?.role === "superadmin" : actor?.role === "owner" || actor?.role === "supervisor";
      if (!conv || !actor || !target || target.role === "owner" || args.memberId === args.userId || !canAssign) return { ok: true, message: "این تغییر مجاز نیست" };
      if (conv.kind === "channel" && actor.role === "superadmin" && (args.role === "superadmin" || target.role === "superadmin")) return { ok: true, message: "فقط مدیر کانال می‌تواند سوپر ادمین را تغییر دهد" };
      if (conv.kind === "group" && args.role === "supervisor") {
        const rows = await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, conv.id), eq(schema.memberships.role, "supervisor")));
        if (rows.length >= 2 && target.role !== "supervisor") return { ok: true, message: "حداکثر ۲ سرپرست مجاز است" };
      }
      if (conv.kind === "group" && args.role === "moderator") {
        const rows = await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, conv.id), eq(schema.memberships.role, "moderator")));
        if (rows.length >= 5 && target.role !== "moderator") return { ok: true, message: "حداکثر ۵ ناظر مجاز است" };
      }
      if (conv.kind === "channel" && args.role === "superadmin") {
        const rows = await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, conv.id), eq(schema.memberships.role, "superadmin")));
        if (rows.length >= 2 && target.role !== "superadmin") return { ok: true, message: "حداکثر ۲ سوپر ادمین مجاز است" };
      }
      if (conv.kind === "channel" && args.role === "admin") {
        const rows = await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, conv.id), eq(schema.memberships.role, "admin")));
        if (rows.length >= 6 && target.role !== "admin") return { ok: true, message: "حداکثر ۶ ادمین مجاز است" };
      }
      const nextRole = conv.kind === "channel" && args.role !== "superadmin" && args.role !== "admin" && args.role !== "member" ? "member" : args.role;
      await db.update(schema.memberships).set({ role: nextRole }).where(eq(schema.memberships.id, target.id));
      ctx.invalidateQueries();
      return { ok: true, message: nextRole === "supervisor" ? "نقش سرپرست ثبت شد" : nextRole === "moderator" ? "نقش ناظر ثبت شد" : nextRole === "superadmin" ? "نقش سوپر ادمین ثبت شد" : nextRole === "admin" ? "نقش ادمین ثبت شد" : "نقش عضو ثبت شد" };
    },
  }),

  addChannelComment: defineAction({ request: z.object({ userId: z.number(), postId: z.number(), text: z.string().min(1).max(160) }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); const post = (await db.select().from(schema.channelPosts).where(eq(schema.channelPosts.id, args.postId)).limit(1))[0]; const member = post ? (await db.select().from(schema.memberships).where(and(eq(schema.memberships.conversationId, post.conversationId), eq(schema.memberships.userId, args.userId))).limit(1))[0] : undefined; if (!post || !member || member.blocked) return { ok: true, message: "برای نظر یا استیکر ابتدا عضو کانال شوید" }; await db.insert(schema.channelComments).values({ postId: post.id, userId: args.userId, text: args.text }); await db.update(schema.channelPosts).set({ comments: post.comments + 1 }).where(eq(schema.channelPosts.id, post.id)); ctx.invalidateQueries(); return { ok: true, message: args.text.length <= 4 ? "استیکر ثبت شد" : "نظر ثبت شد" }; } }),

  reportUser: defineAction({ request: z.object({ reporterId: z.number(), subject: z.string().min(3).max(160) }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); await db.insert(schema.reports).values(args); ctx.invalidateQueries(); return { ok: true, message: "گزارش ثبت شد" }; } }),

  moderatorAction: defineAction({ request: z.object({ userId: z.number(), action: z.enum(["close_report", "toggle_public_chat"]), targetId: z.number().int().positive() }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); const actor = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0]; if (!actor || actor.accessRole !== "admin" || !DEMO_PHONES.has(actor.phone)) return { ok: true, message: "این اقدام فقط برای ادمین مجاز است" }; if (args.action === "close_report") { const report = (await db.select().from(schema.reports).where(eq(schema.reports.id, args.targetId)).limit(1))[0]; if (!report) return { ok: true, message: "گزارش پیدا نشد" }; await db.update(schema.reports).set({ status: "closed" }).where(eq(schema.reports.id, report.id)); await db.insert(schema.moderationAudit).values({ adminId: actor.id, action: "close_report", targetType: "report", targetId: report.id, summary: `بستن گزارش شماره ${report.id} توسط ادمین` }); ctx.invalidateQueries(); return { ok: true, message: "گزارش بسته شد" }; } const conversation = (await db.select().from(schema.conversations).where(eq(schema.conversations.id, args.targetId)).limit(1))[0]; if (!conversation) return { ok: true, message: "گفتگو پیدا نشد" }; if (conversation.kind === "private" || conversation.confidential) { await db.insert(schema.moderationAudit).values({ adminId: actor.id, action: "denied_access", targetType: "conversation", targetId: conversation.id, summary: "تلاش ردشده ادمین برای دسترسی به گفتگوی خصوصی یا محرمانه" }); ctx.invalidateQueries(); return { ok: true, message: "ادمین به گفتگوی خصوصی یا محرمانه دسترسی ندارد" }; } await db.update(schema.conversations).set({ isActive: !conversation.isActive }).where(eq(schema.conversations.id, conversation.id)); await db.insert(schema.moderationAudit).values({ adminId: actor.id, action: "toggle_chat", targetType: "conversation", targetId: conversation.id, summary: `${conversation.isActive ? "تعلیق" : "بازگشایی"} ${conversation.kind === "channel" ? "کانال" : "گروه"} توسط ادمین` }); ctx.invalidateQueries(); return { ok: true, message: conversation.isActive ? "فضا تعلیق شد" : "فضا دوباره فعال شد" }; } }),

  adminLogin: defineAction({ request: z.object({ userId: z.number(), panel: z.enum(["admin", "management"]) }), response: z.object({ ok: z.boolean(), message: z.string() }), async handler(ctx, args) { const db = ctx.db<typeof schema>(); const user = (await db.select().from(schema.users).where(and(eq(schema.users.id, args.userId), eq(schema.users.isTest, true))).limit(1))[0]; if (!user || !DEMO_PHONES.has(user.phone) || user.accessRole !== args.panel) { if (user?.accessRole === "admin") await db.insert(schema.moderationAudit).values({ adminId: user.id, action: "denied_access", targetType: "system", summary: `تلاش ردشده برای ورود به پنل ${args.panel === "management" ? "مدیریت کل" : "ادمین"}` }); ctx.invalidateQueries(); return { ok: false, message: args.panel === "management" ? "این پنل فقط برای مدیریت کل است" : "این پنل فقط برای ادمین است" }; } await db.insert(schema.moderationAudit).values({ adminId: user.id, action: "login", targetType: "system", summary: args.panel === "management" ? "ورود به پنل مدیریت کل" : "ورود به پنل ادمین" }); ctx.invalidateQueries(); return { ok: true, message: args.panel === "management" ? "پنل مدیریت فعال شد" : "پنل ادمین فعال شد" }; } }),

  adminModerate: defineAction({ request: z.object({ userId: z.number(), action: z.enum(["view_chat", "delete_message", "toggle_chat"]), targetId: z.number().int().positive() }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> {
    const db = ctx.db<typeof schema>();
    const admin = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0];
    if (!admin || admin.accessRole !== "management" || !DEMO_PHONES.has(admin.phone)) { if (admin?.accessRole === "admin") await db.insert(schema.moderationAudit).values({ adminId: admin.id, action: "denied_access", targetType: "system", targetId: args.targetId, summary: "تلاش ردشده ادمین برای اجرای اقدام ویژه مدیریت کل" }); ctx.invalidateQueries(); return { ok: true, message: "این اقدام فقط در سطح مدیریت کل مجاز است" }; }
    if (args.action === "view_chat") {
      const conv = (await db.select().from(schema.conversations).where(eq(schema.conversations.id, args.targetId)).limit(1))[0];
      if (!conv) return { ok: true, message: "گفتگو پیدا نشد" };
      const reviewKind = conv.kind === "private" ? (conv.confidential ? "چت محرمانه" : "چت خصوصی") : conv.kind === "channel" ? "کانال" : "گروه";
      await db.insert(schema.moderationAudit).values({ adminId: admin.id, action: "view_chat", targetType: "conversation", targetId: conv.id, summary: `بازبینی ${reviewKind}: ${conv.name}` });
      ctx.invalidateQueries(); return { ok: true, message: "بازبینی در سابقه نظارت ثبت شد" };
    }
    if (args.action === "delete_message") {
      const message = (await db.select().from(schema.messages).where(eq(schema.messages.id, args.targetId)).limit(1))[0];
      if (!message) return { ok: true, message: "پیام پیدا نشد" };
      await db.delete(schema.messages).where(eq(schema.messages.id, message.id));
      await db.insert(schema.moderationAudit).values({ adminId: admin.id, action: "delete_message", targetType: "message", targetId: message.id, summary: `حذف پیام شماره ${message.id} از گفتگوی ${message.conversationId}` });
      ctx.invalidateQueries(); return { ok: true, message: "پیام حذف و در سابقه نظارت ثبت شد" };
    }
    const conv = (await db.select().from(schema.conversations).where(eq(schema.conversations.id, args.targetId)).limit(1))[0];
    if (!conv) return { ok: true, message: "گفتگو پیدا نشد" };
    await db.update(schema.conversations).set({ isActive: !conv.isActive }).where(eq(schema.conversations.id, conv.id));
    await db.insert(schema.moderationAudit).values({ adminId: admin.id, action: "toggle_chat", targetType: "conversation", targetId: conv.id, summary: `${conv.isActive ? "تعلیق" : "بازگشایی"} گفتگو: ${conv.name}` });
    ctx.invalidateQueries(); return { ok: true, message: conv.isActive ? "گفتگو برای اعضا تعلیق شد" : "گفتگو دوباره فعال شد" };
  } }),

  adminUpdate: defineAction({ request: z.object({ userId: z.number(), kind: z.enum(["toggle_user", "close_report", "notice", "settings"]), targetId: z.number().optional(), title: z.string().optional(), body: z.string().optional(), minAge: z.number().int().min(18).max(30).optional(), dailyGift: z.number().int().min(1).max(200).optional(), dailyHangoutTime: z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/).optional() }), response: okSchema, async handler(ctx, args): Promise<z.infer<typeof okSchema>> { const db = ctx.db<typeof schema>(); const admin = (await db.select().from(schema.users).where(eq(schema.users.id, args.userId)).limit(1))[0]; if (!admin || admin.accessRole !== "management" || !DEMO_PHONES.has(admin.phone)) { if (admin?.accessRole === "admin") await db.insert(schema.moderationAudit).values({ adminId: admin.id, action: "denied_access", targetType: "system", targetId: args.targetId, summary: "تلاش ردشده ادمین برای اجرای اقدام ویژه مدیریت کل" }); ctx.invalidateQueries(); return { ok: true, message: "این اقدام فقط در سطح مدیریت کل مجاز است" }; } let summary = "تغییر مدیریتی"; let auditTarget: "user" | "report" | "notice" | "settings" = "settings"; if (args.kind === "toggle_user" && args.targetId) { const target = (await db.select().from(schema.users).where(eq(schema.users.id, args.targetId)).limit(1))[0]; if (target) { await db.update(schema.users).set({ isActive: !target.isActive }).where(eq(schema.users.id, target.id)); summary = `${target.isActive ? "مسدودسازی" : "فعال‌سازی"} کاربر ${target.name}`; auditTarget = "user"; } }
      if (args.kind === "close_report" && args.targetId) { await db.update(schema.reports).set({ status: "closed" }).where(eq(schema.reports.id, args.targetId)); summary = `بستن گزارش شماره ${args.targetId}`; auditTarget = "report"; }
      if (args.kind === "notice" && args.title && args.body) { await db.insert(schema.notices).values({ title: args.title, body: args.body, pinned: true }); summary = "انتشار اطلاعیه مدیریت"; auditTarget = "notice"; }
      if (args.kind === "settings") { await db.update(schema.settings).set({ minAge: args.minAge ?? 18, dailyGift: args.dailyGift ?? 25, dailyHangoutTime: args.dailyHangoutTime ?? "21:00" }).where(eq(schema.settings.id, 1)); summary = "به‌روزرسانی تنظیمات عمومی و ساعت دورهمی"; auditTarget = "settings"; }
      await db.insert(schema.moderationAudit).values({ adminId: admin.id, action: args.kind, targetType: auditTarget, targetId: args.targetId ?? null, summary });
      ctx.invalidateQueries(); return { ok: true, message: "تغییر مدیریتی ذخیره و ثبت شد" }; } }),
} satisfies ActionsModule;
