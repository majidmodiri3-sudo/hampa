import { index, integer, sqliteTable, text, unique } from "drizzle-orm/sqlite-core";

export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  phone: text("phone").notNull().unique(),
  name: text("name").notNull(),
  age: integer("age").notNull().default(18),
  gender: text("gender").notNull().default("نامشخص"),
  maritalStatus: text("marital_status", { enum: ["مجرد", "متأهل", "نامشخص"] }).notNull().default("نامشخص"),
  bio: text("bio").notNull().default(""),
  city: text("city").notNull().default(""),
  interests: text("interests").notNull().default("[]"),
  coins: integer("coins").notNull().default(500),
  xp: integer("xp").notNull().default(0),
  wins: integer("wins").notNull().default(0),
  isTest: integer("is_test", { mode: "boolean" }).notNull().default(false),
  isAdmin: integer("is_admin", { mode: "boolean" }).notNull().default(false),
  accessRole: text("access_role", { enum: ["user", "admin", "management"] }).notNull().default("user"),
  isActive: integer("is_active", { mode: "boolean" }).notNull().default(true),
  twoFactorEnabled: integer("two_factor_enabled", { mode: "boolean" }).notNull().default(false),
  lastGiftDay: text("last_gift_day"),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});

export const profileStories = sqliteTable("profile_stories", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  mediaType: text("media_type", { enum: ["image", "video"] }).notNull(),
  mediaBlobKey: text("media_blob_key").notNull(),
  caption: text("caption").notNull().default(""),
  expiresAt: integer("expires_at", { mode: "timestamp_ms" }).notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [index("profile_stories_user_expiry_idx").on(t.userId, t.expiresAt)]);

export const profileStoryViews = sqliteTable("profile_story_views", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  storyId: integer("story_id").notNull().references(() => profileStories.id, { onDelete: "cascade" }),
  viewerId: integer("viewer_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  viewedAt: integer("viewed_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [unique().on(t.storyId, t.viewerId)]);

export const dailyStories = sqliteTable("daily_stories", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  storyDay: text("story_day").notNull(),
  mediaType: text("media_type", { enum: ["image", "video"] }).notNull(),
  mediaBlobKey: text("media_blob_key").notNull(),
  caption: text("caption").notNull().default(""),
  expiresAt: integer("expires_at", { mode: "timestamp_ms" }).notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [unique("daily_stories_user_day_unique").on(t.userId, t.storyDay), index("daily_stories_expiry_idx").on(t.expiresAt)]);

export const dailyStoryViews = sqliteTable("daily_story_views", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  storyId: integer("story_id").notNull().references(() => dailyStories.id, { onDelete: "cascade" }),
  viewerId: integer("viewer_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  viewedAt: integer("viewed_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [unique("daily_story_views_story_viewer_unique").on(t.storyId, t.viewerId)]);

export const publicStories = sqliteTable("public_stories", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  mediaType: text("media_type", { enum: ["image", "video"] }).notNull(),
  mediaBlobKey: text("media_blob_key").notNull(),
  caption: text("caption").notNull().default(""),
  expiresAt: integer("expires_at", { mode: "timestamp_ms" }).notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [index("public_stories_expiry_idx").on(t.expiresAt)]);

export const publicStoryLikes = sqliteTable("public_story_likes", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  storyId: integer("story_id").notNull().references(() => publicStories.id, { onDelete: "cascade" }),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [unique("public_story_likes_story_user_unique").on(t.storyId, t.userId)]);

export const publicStoryComments = sqliteTable("public_story_comments", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  storyId: integer("story_id").notNull().references(() => publicStories.id, { onDelete: "cascade" }),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  text: text("text").notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [index("public_story_comments_story_idx").on(t.storyId, t.id)]);

export const userFollows = sqliteTable("user_follows", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  followerId: integer("follower_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  followedId: integer("followed_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [unique("user_follows_pair_unique").on(t.followerId, t.followedId)]);

export const playerGameAvatars = sqliteTable("player_game_avatars", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id).unique(),
  face: text("face", { enum: ["round", "sharp", "soft"] }).notNull().default("round"),
  hair: text("hair", { enum: ["short", "wave", "crest", "hood"] }).notNull().default("short"),
  outfit: text("outfit", { enum: ["ranger", "royal", "shadow", "sport"] }).notNull().default("ranger"),
  accent: text("accent", { enum: ["emerald", "cherry", "gold", "ocean"] }).notNull().default("emerald"),
  emblem: text("emblem", { enum: ["star", "shield", "bolt", "crown"] }).notNull().default("star"),
  updatedAt: integer("updated_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});

export const connectionRequests = sqliteTable("connection_requests", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  senderId: integer("sender_id").notNull().references(() => users.id),
  receiverId: integer("receiver_id").notNull().references(() => users.id),
  status: text("status", { enum: ["pending", "accepted", "rejected"] }).notNull().default("pending"),
  message: text("message").notNull().default(""),
  imageBlobKey: text("image_blob_key"),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [unique().on(t.senderId, t.receiverId)]);

export const conversations = sqliteTable("conversations", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  kind: text("kind", { enum: ["private", "group", "channel", "game"] }).notNull(),
  name: text("name").notNull(),
  ownerId: integer("owner_id").notNull().references(() => users.id),
  description: text("description").notNull().default(""),
  imageBlobKey: text("image_blob_key"),
  channelActivity: text("channel_activity").notNull().default(""),
  confidential: integer("confidential", { mode: "boolean" }).notNull().default(false),
  secretTimerMinutes: integer("secret_timer_minutes").notNull().default(5),
  isActive: integer("is_active", { mode: "boolean" }).notNull().default(true),
  groupFund: integer("group_fund").notNull().default(0),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});

export const memberships = sqliteTable("memberships", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  conversationId: integer("conversation_id").notNull().references(() => conversations.id),
  userId: integer("user_id").notNull().references(() => users.id),
  role: text("role", { enum: ["owner", "supervisor", "moderator", "superadmin", "admin", "member"] }).notNull().default("member"),
  following: integer("following", { mode: "boolean" }).notNull().default(false),
  muted: integer("muted", { mode: "boolean" }).notNull().default(false),
  blocked: integer("blocked", { mode: "boolean" }).notNull().default(false),
}, (t) => [unique().on(t.conversationId, t.userId)]);

export const messages = sqliteTable("messages", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  conversationId: integer("conversation_id").notNull().references(() => conversations.id),
  senderId: integer("sender_id").notNull().references(() => users.id),
  type: text("type", { enum: ["text", "voice", "image", "video", "system"] }).notNull().default("text"),
  content: text("content").notNull().default(""),
  replyToId: integer("reply_to_id"),
  expiresAt: integer("expires_at", { mode: "timestamp_ms" }),
  editedAt: integer("edited_at", { mode: "timestamp_ms" }),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});

export const messageReactions = sqliteTable("message_reactions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  messageId: integer("message_id").notNull().references(() => messages.id, { onDelete: "cascade" }),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  emoji: text("emoji").notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [
  unique().on(t.messageId, t.userId),
  index("message_reactions_message_idx").on(t.messageId),
]);

export const channelPosts = sqliteTable("channel_posts", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  conversationId: integer("conversation_id").notNull().references(() => conversations.id),
  authorId: integer("author_id").notNull().references(() => users.id),
  text: text("text").notNull(),
  mediaType: text("media_type", { enum: ["voice", "image", "video"] }),
  mediaBlobKey: text("media_blob_key"),
  replyToId: integer("reply_to_id"),
  likes: integer("likes").notNull().default(0),
  comments: integer("comments").notNull().default(0),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});

export const channelComments = sqliteTable("channel_comments", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  postId: integer("post_id").notNull().references(() => channelPosts.id),
  userId: integer("user_id").notNull().references(() => users.id),
  text: text("text").notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});

export const scheduledGroupGames = sqliteTable("scheduled_group_games", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  title: text("title").notNull(),
  gameType: text("game_type", { enum: ["مافیا", "حکم", "پوکر", "۲۱", "کوئیز", "منچ", "مارپله"] }).notNull(),
  groupId: integer("group_id").references(() => conversations.id),
  hostId: integer("host_id").notNull().references(() => users.id),
  startsAt: integer("starts_at", { mode: "timestamp_ms" }).notNull(),
  status: text("status", { enum: ["scheduled", "live", "finished"] }).notNull().default("scheduled"),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [index("scheduled_group_games_starts_idx").on(t.startsAt)]);

export const scheduledGameResponses = sqliteTable("scheduled_game_responses", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  scheduledGameId: integer("scheduled_game_id").notNull().references(() => scheduledGroupGames.id, { onDelete: "cascade" }),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  response: text("response", { enum: ["play", "watch"] }).notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [unique().on(t.scheduledGameId, t.userId)]);

export const gameRooms = sqliteTable("game_rooms", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  gameType: text("game_type").notNull(),
  hostId: integer("host_id").notNull().references(() => users.id),
  status: text("status", { enum: ["live", "finished"] }).notNull().default("live"),
  stake: integer("stake").notNull().default(0),
  winnerId: integer("winner_id").references(() => users.id),
  spectators: integer("spectators").notNull().default(0),
  turnNumber: integer("turn_number").notNull().default(1),
  hostChance: integer("host_chance").notNull().default(50),
  commentary: text("commentary").notNull().default("داور مجازی برای شروع دور آماده است."),
  lastEvent: text("last_event").notNull().default("شروع میز"),
  hostMood: text("host_mood", { enum: ["focused", "celebrate", "worried"] }).notNull().default("focused"),
  guestMood: text("guest_mood", { enum: ["focused", "celebrate", "worried"] }).notNull().default("focused"),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});

export const gameCheers = sqliteTable("game_cheers", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  gameRoomId: integer("game_room_id").notNull().references(() => gameRooms.id, { onDelete: "cascade" }),
  senderId: integer("sender_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  reaction: text("reaction", { enum: ["👏", "🔥", "❤️", "🎉"] }).notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [index("game_cheers_room_idx").on(t.gameRoomId, t.id)]);

export const gameSessions = sqliteTable("game_sessions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id),
  gameType: text("game_type", { enum: ["مافیا", "حکم", "پوکر", "۲۱", "کوئیز", "منچ", "مارپله"] }).notNull(),
  stake: integer("stake").notNull().default(0),
  status: text("status", { enum: ["active", "finished"] }).notNull().default("active"),
  stateJson: text("state_json").notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
  updatedAt: integer("updated_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [index("game_sessions_user_status_idx").on(t.userId, t.status)]);

export const gameSpectators = sqliteTable("game_spectators", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  gameRoomId: integer("game_room_id").notNull().references(() => gameRooms.id),
  userId: integer("user_id").notNull().references(() => users.id),
  favoriteUserId: integer("favorite_user_id").references(() => users.id),
  favoriteTeam: text("favorite_team"),
  joinedAt: integer("joined_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [unique().on(t.gameRoomId, t.userId)]);

export const bets = sqliteTable("bets", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  gameRoomId: integer("game_room_id").notNull().references(() => gameRooms.id),
  userId: integer("user_id").notNull().references(() => users.id),
  targetUserId: integer("target_user_id").notNull().references(() => users.id),
  amount: integer("amount").notNull(),
  status: text("status", { enum: ["open", "won", "lost"] }).notNull().default("open"),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});

export const liveVoiceClips = sqliteTable("live_voice_clips", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  gameRoomId: integer("game_room_id").notNull().references(() => gameRooms.id),
  senderId: integer("sender_id").notNull().references(() => users.id),
  senderRole: text("sender_role", { enum: ["player", "spectator"] }).notNull(),
  audience: text("audience", { enum: ["player_room", "spectator_room", "reward_announcement"] }).notNull().default("spectator_room"),
  blobKey: text("blob_key").notNull(),
  mimeType: text("mime_type").notNull(),
  durationMs: integer("duration_ms").notNull().default(0),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [index("live_voice_clips_room_idx").on(t.gameRoomId, t.id)]);

export const spectatorGifts = sqliteTable("spectator_gifts", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  gameRoomId: integer("game_room_id").notNull().references(() => gameRooms.id),
  spectatorId: integer("spectator_id").notNull().references(() => users.id),
  amount: integer("amount").notNull().default(0),
  status: text("status", { enum: ["escrow", "released", "refunded"] }).notNull().default("escrow"),
  platformFee: integer("platform_fee").notNull().default(0),
  paidAmount: integer("paid_amount").notNull().default(0),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
  settledAt: integer("settled_at", { mode: "timestamp_ms" }),
}, (t) => [
  unique().on(t.gameRoomId, t.spectatorId),
  index("spectator_gifts_room_idx").on(t.gameRoomId),
]);

export const battleCries = sqliteTable("battle_cries", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  text: text("text").notNull(),
  expiresAt: integer("expires_at", { mode: "timestamp_ms" }).notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [index("battle_cries_expiry_idx").on(t.expiresAt)]);

export const quickDuels = sqliteTable("quick_duels", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  questionKey: text("question_key").notNull(),
  correctOption: integer("correct_option").notNull(),
  startedAt: integer("started_at", { mode: "timestamp_ms" }).notNull(),
  answeredAt: integer("answered_at", { mode: "timestamp_ms" }),
  won: integer("won", { mode: "boolean" }),
  reward: integer("reward").notNull().default(0),
}, (t) => [index("quick_duels_user_idx").on(t.userId, t.id)]);

export const dailyWheelSpins = sqliteTable("daily_wheel_spins", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  spinDay: text("spin_day").notNull(),
  reward: integer("reward").notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [unique("daily_wheel_spins_user_day_unique").on(t.userId, t.spinDay)]);

export const detectiveAttempts = sqliteTable("detective_attempts", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  caseKey: text("case_key").notNull(),
  accused: text("accused").notNull(),
  correct: integer("correct", { mode: "boolean" }).notNull(),
  reward: integer("reward").notNull().default(0),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [index("detective_attempts_user_case_idx").on(t.userId, t.caseKey)]);

export const ambassadorProfiles = sqliteTable("ambassador_profiles", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  inviteCode: text("invite_code").notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [unique("ambassador_profiles_user_unique").on(t.userId), unique("ambassador_profiles_code_unique").on(t.inviteCode)]);

export const ambassadorReferrals = sqliteTable("ambassador_referrals", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  inviterId: integer("inviter_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  inviteeId: integer("invitee_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  inviteCode: text("invite_code").notNull(),
  reward: integer("reward").notNull().default(100),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [unique("ambassador_referrals_invitee_unique").on(t.inviteeId), index("ambassador_referrals_inviter_idx").on(t.inviterId, t.id)]);

export const financialSafePins = sqliteTable("financial_safe_pins", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  pinHash: text("pin_hash").notNull(),
  failedAttempts: integer("failed_attempts").notNull().default(0),
  lockedUntil: integer("locked_until", { mode: "timestamp_ms" }),
  updatedAt: integer("updated_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [unique("financial_safe_pins_user_unique").on(t.userId)]);

export const transactions = sqliteTable("transactions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id),
  amount: integer("amount").notNull(),
  kind: text("kind").notNull(),
  note: text("note").notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});

export const notices = sqliteTable("notices", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  title: text("title").notNull(),
  body: text("body").notNull(),
  pinned: integer("pinned", { mode: "boolean" }).notNull().default(false),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});

export const reports = sqliteTable("reports", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  reporterId: integer("reporter_id").notNull().references(() => users.id),
  subject: text("subject").notNull(),
  status: text("status", { enum: ["open", "closed"] }).notNull().default("open"),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});

export const settings = sqliteTable("settings", {
  id: integer("id").primaryKey(),
  minAge: integer("min_age").notNull().default(18),
  dailyGift: integer("daily_gift").notNull().default(25),
  gameCommission: integer("game_commission").notNull().default(30),
  dailyHangoutTime: text("daily_hangout_time").notNull().default("21:00"),
});

export const moderationAudit = sqliteTable("moderation_audit", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  adminId: integer("admin_id").notNull().references(() => users.id),
  action: text("action", { enum: ["login", "view_chat", "delete_message", "toggle_chat", "toggle_user", "close_report", "notice", "settings", "denied_access"] }).notNull(),
  targetType: text("target_type", { enum: ["system", "conversation", "message", "user", "report", "notice", "settings", "wallet", "security"] }).notNull(),
  targetId: integer("target_id"),
  summary: text("summary").notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [index("moderation_audit_created_idx").on(t.createdAt)]);

export const scoreGroups = sqliteTable("score_groups", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull().unique(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
});

export const scoreGroupMembers = sqliteTable("score_group_members", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  groupId: integer("group_id").notNull().references(() => scoreGroups.id),
  userId: integer("user_id").notNull().references(() => users.id),
}, (t) => [unique().on(t.userId)]);

export const tournaments = sqliteTable("tournaments", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  title: text("title").notNull(),
  gameType: text("game_type", { enum: ["مافیا", "حکم", "پوکر", "۲۱", "کوئیز", "منچ", "مارپله"] }).notNull().default("حکم"),
  entryFee: integer("entry_fee").notNull().default(50),
  prizePool: integer("prize_pool").notNull().default(0),
  status: text("status", { enum: ["registration", "live", "finished"] }).notNull().default("registration"),
  championGroupId: integer("champion_group_id").references(() => scoreGroups.id),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
  finishedAt: integer("finished_at", { mode: "timestamp_ms" }),
});

export const tournamentRegistrations = sqliteTable("tournament_registrations", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  tournamentId: integer("tournament_id").notNull().references(() => tournaments.id),
  groupId: integer("group_id").notNull().references(() => scoreGroups.id),
  registeredByUserId: integer("registered_by_user_id").notNull().references(() => users.id),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [unique().on(t.tournamentId, t.groupId)]);

export const tournamentMatches = sqliteTable("tournament_matches", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  tournamentId: integer("tournament_id").notNull().references(() => tournaments.id),
  homeGroupId: integer("home_group_id").notNull().references(() => scoreGroups.id),
  awayGroupId: integer("away_group_id").notNull().references(() => scoreGroups.id),
  status: text("status", { enum: ["scheduled", "live", "finished"] }).notNull().default("scheduled"),
  winnerGroupId: integer("winner_group_id").references(() => scoreGroups.id),
  gameRoomId: integer("game_room_id").references(() => gameRooms.id),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [index("tournament_matches_tournament_idx").on(t.tournamentId)]);

export const scoreEvents = sqliteTable("score_events", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: integer("user_id").notNull().references(() => users.id),
  sourceType: text("source_type", { enum: ["game", "bet"] }).notNull(),
  sourceId: integer("source_id").notNull(),
  outcome: text("outcome", { enum: ["win", "loss"] }).notNull(),
  points: integer("points").notNull(),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull().$defaultFn(() => new Date()),
}, (t) => [
  unique().on(t.userId, t.sourceType, t.sourceId),
  index("score_events_user_idx").on(t.userId),
]);
