// server/standalone-ctx.ts
//
// Builds a Hatch-compatible `Ctx` so this space can run outside the Hatch
// runtime (plain `bun` on any machine).
//
// Replacements for the managed runtime pieces:
//   ctx.db     -> local libsql (SQLite) file at <DATA_DIR>/app.db, migrated
//                 automatically from ./drizzle on every boot.
//                 Set TURSO_URL (+TURSO_AUTH_TOKEN) to use a hosted libsql
//                 database instead of the local file.
//   ctx.blobs  -> local disk storage at <DATA_DIR>/blobs, served over /blobs/*
//   ctx.inference -> neutral stub (no AI key here). `advanceLiveDirector`
//                 still works but returns a neutral commentary instead of an
//                 AI-generated one.
//   ctx.invalidateQueries / ctx.emit -> no-ops (single server, the client
//                 refetches on its own after each mutation)
//   ctx.agent / ctx.tool / executePrivileged -> throw a clear error if hit
//                 (this space's actions never use them)

import { mkdirSync } from "node:fs";
import { join, resolve, normalize, sep } from "node:path";
import { createClient, type Client } from "@libsql/client";
import { drizzle, type LibSQLDatabase } from "drizzle-orm/libsql";
import { migrate } from "drizzle-orm/libsql/migrator";
import type { BlobClient, BlobMetadata, BlobPutData, Ctx } from "@hatch/space-sdk";
import * as schema from "./src/schema.ts";

export const PROJECT_ROOT = resolve(join(import.meta.dir, ".."));
export const DATA_DIR = resolve(process.env.HAMSAFAR_DATA_DIR ?? join(PROJECT_ROOT, "data"));
const BLOB_DIR = join(DATA_DIR, "blobs");
const DB_PATH = join(DATA_DIR, "app.db");

// Neutral fallback for the one AI call in this app (`advanceLiveDirector`).
// It must satisfy whatever zod schema the caller passes, so we validate it
// and throw a clear error if a future schema needs real inference.
const NEUTRAL_DIRECTOR_DECISION = {
  commentary: "ادامه مسابقه با روند عادی و بدون حاشیه",
  event: "شروع دور بعد",
  hostChance: 50,
  hostMood: "focused",
  guestMood: "focused",
} as const;

function unsupported(what: string): never {
  throw new Error(`${what} در حالت مستقل پشتیبانی نمی‌شود`);
}

async function toBytes(data: BlobPutData): Promise<Uint8Array> {
  if (typeof data === "string") return new TextEncoder().encode(data);
  if (data instanceof Uint8Array) return data;
  if (data instanceof ArrayBuffer) return new Uint8Array(data);
  if (ArrayBuffer.isView(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  if (data instanceof Blob) return new Uint8Array(await data.arrayBuffer());
  throw new Error("unsupported blob data type");
}

/** Resolve a blob key to a disk path, or null when the key is unsafe. */
export function blobFilePath(key: string): string | null {
  const safe = normalize(key).replace(/^(\.\.(\/|\\|$))+/, "");
  if (!safe || safe.includes("..") || safe.startsWith(sep)) return null;
  return join(BLOB_DIR, safe);
}

async function readMeta(path: string): Promise<{ contentType?: string } | null> {
  try {
    return (await Bun.file(path + ".__meta.json").json()) as { contentType?: string };
  } catch {
    return null;
  }
}

export async function createStandaloneCtx() {
  mkdirSync(BLOB_DIR, { recursive: true });

  // Local SQLite file by default. Optionally, point at a hosted libsql/Turso
  // database instead (untested path — needs a Turso account):
  //   TURSO_URL=libsql://....turso.io TURSO_AUTH_TOKEN=... bun run start
  const remoteUrl = process.env.TURSO_URL;
  const client: Client = remoteUrl
    ? createClient({ url: remoteUrl, authToken: process.env.TURSO_AUTH_TOKEN })
    : createClient({ url: `file:${DB_PATH}` });
  const db: LibSQLDatabase<typeof schema> = drizzle(client, { schema });
  await migrate(db, { migrationsFolder: join(PROJECT_ROOT, "drizzle") });

  const blobs: BlobClient = {
    async put(key, data, options) {
      const path = blobFilePath(key);
      if (!path) throw new Error(`bad blob key: ${key}`);
      const bytes = await toBytes(data);
      mkdirSync(join(path, ".."), { recursive: true });
      await Bun.write(path, bytes);
      await Bun.write(path + ".__meta.json", JSON.stringify({ contentType: options?.contentType ?? "application/octet-stream" }));
    },
    async getUrl(key) {
      if (!blobFilePath(key)) throw new Error(`bad blob key: ${key}`);
      return `/blobs/${key.split("/").map(encodeURIComponent).join("/")}`;
    },
    async delete(key) {
      const path = blobFilePath(key);
      if (!path) return;
      const f = Bun.file(path);
      if (await f.exists()) await Bun.$`rm -f ${path} ${path}.__meta.json`.quiet();
    },
    async head(key): Promise<BlobMetadata | null> {
      const path = blobFilePath(key);
      if (!path) return null;
      const f = Bun.file(path);
      if (!(await f.exists())) return null;
      const meta = await readMeta(path);
      return {
        key,
        contentType: meta?.contentType ?? "application/octet-stream",
        size: f.size,
        sizeBytes: f.size,
        etag: "",
        visibility: "private",
        createdAtMs: 0,
        updatedAtMs: 0,
        public: false,
      };
    },
    async list(prefix = ""): Promise<BlobMetadata[]> {
      const out: BlobMetadata[] = [];
      const glob = new Bun.Glob("**/*");
      for await (const rel of glob.scan({ cwd: BLOB_DIR, onlyFiles: true })) {
        if (rel.endsWith(".__meta.json") || (prefix && !rel.startsWith(prefix))) continue;
        const meta = await blobs.head(rel);
        if (meta) out.push(meta);
      }
      return out;
    },
  };

  const throwProxy = new Proxy(
    {},
    {
      get: () => () => {
        throw new Error("این قابلیت (agent/tool) در حالت مستقل پشتیبانی نمی‌شود");
      },
    },
  );

  const ctx = {
    slug: "hamsafar-standalone",
    invocationId: `standalone-${Date.now()}`,
    spaceDir: PROJECT_ROOT,
    db: (() => db) as Ctx["db"],
    blobs,
    invalidateQueries: () => {},
    emit: () => {},
    inference: {
      complete: async (_prompt: string, options: { schema: { parse: (v: unknown) => unknown } }) => {
        try {
          return options.schema.parse(NEUTRAL_DIRECTOR_DECISION);
        } catch {
          unsupported("هوش مصنوعی (inference)");
        }
      },
    },
    agent: throwProxy,
    tool: throwProxy,
    executePrivileged: async () => unsupported("executePrivileged"),
  } as unknown as Ctx;

  return { ctx, db, client, blobDir: BLOB_DIR, dataDir: DATA_DIR, dbPath: DB_PATH };
}
