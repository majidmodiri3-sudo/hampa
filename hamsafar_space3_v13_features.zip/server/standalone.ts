// server/standalone.ts
//
// Standalone HTTP server for همسفر (space-3).
//
//   bun run build   # build server bundle + client bundle (once)
//   bun run start   # migrate DB, then serve on PORT (default 4173)
//
// Routes:
//   POST /actions        -> {"action","args","actionCallId?"}  (the exact
//                           protocol the bundled web client speaks)
//   GET  /blobs/*        -> files stored via ctx.blobs
//   GET  /*              -> the built web client (client/dist)

import { join } from "node:path";
import { Actions } from "./dist/actions.js";
import { isAction } from "@hatch/space-sdk";
import { createStandaloneCtx, blobFilePath, PROJECT_ROOT, DATA_DIR } from "./standalone-ctx.ts";

const PORT = Number(process.env.PORT ?? 4173);
// On Replit the server must listen on all interfaces: set HAMSAFAR_BIND=0.0.0.0
// (export it on its own line BEFORE starting the server). Defaults to
// localhost for local runs.
const HOSTNAME = process.env.HAMSAFAR_BIND ?? "127.0.0.1";
const { ctx } = await createStandaloneCtx();
const CLIENT_DIR = join(PROJECT_ROOT, "client", "dist");

async function serveStatic(pathname: string): Promise<Response | null> {
  let rel = decodeURIComponent(pathname);
  if (rel === "/") rel = "/index.html";
  if (rel.includes("..")) return null;
  const file = Bun.file(join(CLIENT_DIR, rel));
  if (await file.exists()) return new Response(file);
  return null;
}

const server = Bun.serve({
  port: PORT,
  hostname: HOSTNAME,
  async fetch(req) {
    const url = new URL(req.url);

    if (url.pathname === "/actions") {
      if (req.method !== "POST") return Response.json({ error: "method not allowed" }, { status: 405 });
      let body: { action?: string; args?: unknown };
      try {
        body = (await req.json()) as { action?: string; args?: unknown };
      } catch {
        return Response.json({ error: "invalid json body" }, { status: 400 });
      }
      const def = (Actions as unknown as Record<string, unknown>)[body?.action ?? ""];
      if (!def || !isAction(def)) {
        return Response.json({ error: `unknown action: ${String(body?.action)}` }, { status: 404 });
      }
      let args: unknown;
      try {
        args = def.request.parse(body.args ?? {});
      } catch (e) {
        return Response.json({ error: `bad args: ${e instanceof Error ? e.message : String(e)}` }, { status: 400 });
      }
      try {
        const data = await def.handler(ctx, args as never);
        const checked = def.response.parse(data);
        return Response.json({ data: checked });
      } catch (e) {
        return Response.json({ error: e instanceof Error ? e.message : String(e) }, { status: 500 });
      }
    }

    if (url.pathname.startsWith("/blobs/")) {
      const key = decodeURIComponent(url.pathname.slice("/blobs/".length));
      const path = blobFilePath(key);
      if (!path) return new Response("bad blob key", { status: 400 });
      const file = Bun.file(path);
      if (!(await file.exists())) return new Response("not found", { status: 404 });
      let contentType = "application/octet-stream";
      try {
        const meta = (await Bun.file(path + ".__meta.json").json()) as { contentType?: string };
        if (meta?.contentType) contentType = meta.contentType;
      } catch {
        /* keep default */
      }
      return new Response(file, { headers: { "content-type": contentType } });
    }

    const direct = await serveStatic(url.pathname);
    if (direct) return direct;
    const index = Bun.file(join(CLIENT_DIR, "index.html"));
    if (await index.exists()) return new Response(index);
    return new Response("client not built yet — run: bun run build:client", {
      status: 503,
      headers: { "content-type": "text/plain; charset=utf-8" },
    });
  },
});

console.log(`hamsafar standalone running: http://localhost:${server.port}`);
console.log(`data dir: ${DATA_DIR}`);
